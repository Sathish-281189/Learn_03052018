https://go.tinymce.com/blog/angular-2-and-tinymce/
https://embed.plnkr.co/hnB0R3/

Array Methods : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/ (IMPORTANT)
Filter: https://codeburst.io/create-a-search-pipe-to-dynamically-filter-results-with-angular-4-21fd3a5bec5c
Directory Structure:

1.Components
	-	ts,html,css,spec
	(Or)
1. MODULE_NAME
	-	MODULE_NAME.module.ts
	-	Components
		-	ts,html,css,spec
2. Shared
	-	Header
	-	Footer
	-	Alert
	-	Loader
	-	Models (class objects)
	-	Services
		-	httpService (get, post, put, delete, uploadFile, downloadFile, setHeaders, setFileHeaders) - Common
		-	responseHandlerService (onSuccess, onError/onCatch) - Common
		
Common Issues
1. CORS : Cross Origin Resource Sharing
	Refer
		-	https://stackoverflow.com/questions/36768418/how-to-make-cors-enabled-http-requests-in-angular-2
		-	http://restlet.com/company/blog/2015/12/15/understanding-and-using-cors/
	
	-	Cross Origin Resource Sharing (CORS) allows us to use Web applications within browsers when domains aren’t the same. For example, a site with domain test.org wants to execute AJAX requests to a Web application with domain mydomain.org using HTTP.
		>>	SIMPLE REQUESTS : This use case applies if we use HTTP GET, HEAD and POST methods. In the case of POST methods, only content types with the following values are supported: text/plain, application/x-www-form-urlencoded and multipart/form-data.
		>>	PREFLIGHTED REQUESTS: When the ‘simple requests’ use case doesn’t apply, a first request (with the HTTP OPTIONS method) is made to check what can be done in the context of cross-domain requests.

ENIVIRONMENT VARIABLE:
	Refer: https://stackoverflow.com/questions/8768549/node-js-doesnt-recognize-system-path
	SET PATH=C:\Program Files\Nodejs;%PATH%

Angular CLI

	-	https://cli.angular.io/
	-	https://github.com/angular/angular-cli

Angular Setup:

	Install NodeJs & Npm
	To check the "node" installation properly : node -v
	To check the "npm" installation properly : npm -v
	npm cache clean
	
Proxy Settings: 

	To find proxy in chrome  chrome://net-internals/#

	Open an command prompt or terminal session and run the following commands to configure npm to work with your web proxy. The commands use proxy.company.com as the address and 8080 as the port.

	npm config set proxy http://proxy.company.com:8080
	npm config set https-proxy http://proxy.company.com:8080
	Set Regisrty & strict-ssl
	
	eg:
	npm config set proxy http://proxy.cognizant.com:6050
	
	npm config set proxy http://proxy.cognizant.com:6050
	npm config set https-proxy http://proxy.cognizant.com:6050
	npm config set registry "http://registry.npmjs.org"
	npm config set strict-ssl false
	
	npm config set proxy http://proxy.cognizant.com:6050
	npm config set https-proxy http://proxy.cognizant.com:6050 

Git Proxy: 
	
	Refer: https://stackoverflow.com/questions/783811/getting-git-to-work-with-a-proxy-server
	
	eg: git config --global http.proxy http://proxyuser:proxypwd@proxy.server.com:8080
		git config --global http.proxy http://proxy.cognizant.com:6050
	If you decide at any time to reset this proxy and work without proxy:

	Command to use:

	git config --global --unset http.proxy
	Finally, to check the currently set proxy:

	git config --global --get http.proxy
	
Optional: 
	npm install -g node-gyp
	npm install --global --production windows-build-tools

Steps to Create Project:
	
	1. npm install -g @angular/cli		// To check the cli installed properly : ng -v
	2. ng new PROJECT-NAME
	3. cd PROJECT-NAME
	4. npm install
	5. ng serve --open

	Navigate to http://localhost:4200/. The app will automatically reload if you change any of the source files.
	You can configure the default HTTP host and port used by the development server with two command-line options :
	ng serve --host 0.0.0.0 --port 4201
	
COMMUNICATING BETWEEN COMPONENTS WITH OBSERVABLE & SUBJECT: (IMPORTANT)
Refer : http://jasonwatmore.com/post/2016/12/01/angular-2-communicating-between-components-with-observable-subject

Observable.subscribe():
	The observable subscribe method is used to subscribe to messages that are sent to an observable.
Subject.next():
	The subject next method is used to send messages to an observable which are then sent to all subscribers of that observable.

ROUTER EVENTS:

https://toddmotto.com/dynamic-page-titles-angular-2-router-events

Generating Components, Directives, Pipes and Services:

You can use the ng generate (or just ng g) command to generate Angular components:

You can find all possible blueprints in the table below:

Component	-	ng g component my-new-component
Directive	-	ng g directive my-new-directive
Pipe		-	ng g pipe my-new-pipe
Service		-	ng g service my-new-service
Class		-	ng g class my-new-class
Guard		-	ng g guard my-new-guard
Interface	-	ng g interface my-new-interface
Enum		-	ng g enum my-new-enum
Module		-	ng g module my-module


Updating Angular CLI:

To update Angular CLI to a new version, you must update both the global package and your project's local package.

Global package:
	npm uninstall -g @angular/cli
	npm cache clean
	# if npm version is > 5 then use `npm cache verify` to avoid errors (or to avoid using --force)
	npm install -g @angular/cli@latest

Local project package:
	rm -rf node_modules dist
	# use rmdir /S/Q node_modules dist in Windows Command Prompt; use rm -r -fo node_modules,dist in Windows PowerShell
	npm install --save-dev @angular/cli@latest
	npm install

@Component:
	@Component is a decorator function that specifies the Angular metadata for the component.


Angular Tutorial:

	-	https://angular-2-training-book.rangle.io/handout/cli/creating-components.html
	-	https://stackoverflow.com/questions/43483848/angular-4-error-property-includes-is-missing-in-type-any
	-	https://code.angularjs.org/1.1.5/docs/
	-	http://jilles.me/ng-repeat-in-angular2-ng-for/
	-	https://angular.io/guide/quickstart
	-	https://www.tutorialspoint.com/angular2/index.htm
	-	https://www.barbarianmeetscoding.com/blog/2016/03/25/getting-started-with-angular-2-step-by-step-1-your-first-component/
	-	http://thejackalofjavascript.com/getting-started-with-angular-2-0/
	-	https://www.udemy.com/angular-2-tutorial-for-beginners/
	-	http://www.angular2.com/	
	
	-	https://medium.com/@evertonrobertoauler/angular-4-universal-app-with-angular-cli-db8b53bba07d
	-	https://medium.com/@evertonrobertoauler/angular-5-universal-with-transfer-state-using-angular-cli-19fe1e1d352c
	
Angular Universal
	-	https://scotch.io/courses/getting-started-with-angular-2
	-	https://scotch.io/tutorials/server-side-rendering-in-angular-2-with-angular-universal
	

	In order to update the angular-cli package installed globally in your system, you need to run:
	npm uninstall -g angular-cli
	npm cache clean
	npm install -g @angular/cli@latest
	

Ng-translate

Installation
	-	First you need to install the npm module:
	-	https://github.com/ngx-translate/core
	-	npm install @ngx-translate/core --save

Refer
	-	https://scotch.io/tutorials/simple-language-translation-in-angular-2-part-1
	-	https://embed.plnkr.co/BnCRsCfB1ZIMoQ4QT6Lg/

Example: 
	-	https://embed.plnkr.co/?show=preview
	-	https://embed.plnkr.co/?show=preview


npm config edit

INSTALLATION

How to setup Node.js and Npm behind a corporate web proxy

Refer: 
	-	https://jjasonclark.com/how-to-setup-node-behind-web-proxy/
	-	https://github.com/angular/angular-cli/issues/2161
	-	https://github.com/npm/npm/issues/2119 (Python error)

To use another port - ng serve --port 3030



https://stackoverflow.com/questions/26989401/nodejs-npm-proxy-error-when-installing-grunt
https://github.com/npm/npm/issues/7945
https://github.com/npm/npm/issues/3559
https://github.com/angular/angular-cli/issues/2161


Local Storage:
https://stackoverflow.com/questions/32486871/angularjs-use-local-storage



Cordova:
https://cordova.apache.org/
https://www.becompany.ch/en/blog/2016/09/19/angular2-rss-reader
https://www.becompany.ch/en/blog/2016/10/19/creating-apache-cordova-app-with-angular2




