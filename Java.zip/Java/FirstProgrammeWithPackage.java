package com.jbt;
 
public class FirstProgrammeWithPackage {
	public static void main(String args[]) {
		System.out.println("Hello JBT!");
	}
}