package com.jbt;
public class HelloWorld {
	int i;	// Class Variable - (State)
	// Method - (Behavior)
	public static void main(String args[]) {
		System.out.println("Hello World..!");
	}

}

class AnotherClass {
}