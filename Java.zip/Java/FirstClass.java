public class FirstClass {
	public int i;
	protected int j;
	private int k;

}