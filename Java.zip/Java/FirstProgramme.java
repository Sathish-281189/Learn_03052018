public class FirstProgramme {
	public static void main(String args[]) {
		System.out.println("Hello JBT!");
		
		int x = 10;
		// Java Unary Operator Example: 1
		System.out.println("\nExample: 1");
		System.out.println(x++); // 10 (11)
		System.out.println(++x); // 12
		System.out.println(x--); // 12 (11)
		System.out.println(--x); // 10
		
		// Java Unary Operator Example: 2
		System.out.println("\nExample: 2");
		int a = 10;
		int b = 10;
		// System.out.println(a++ + ++a); // 10+12 = 22
		// System.out.println(b++ + b++); // 10+11 = 21

		// Java Left Shift Operator Example: 3
		System.out.println("\nExample: 3");
		System.out.println(10<<2); // 10*2^2 = 10*4 = 40
		System.out.println(10<<3); // 10*2^3 = 10*8 = 80
		System.out.println(20<<2); // 20*2^2 = 20*4 = 80
		System.out.println(15<<4); // 15*2^4 = 15*16 = 240
		
		// Java Assignment Operator Example: 4
		System.out.println("\nExample: 4");
		a+=b;
		b-=4;
		System.out.println(a);
		System.out.println(b);
		
		// Java Java If-else Statement Example: 5
		System.out.println("\nExample: 5");
		if(a%2 == 0) {
			System.out.println("Even number");
		} else {
			System.out.println("Odd number");
		}
		
		// Java Switch Statement Example: 6
		System.out.println("\nExample: 6");
		switch(a) {
			case 5: {
				System.out.println("case 5");
				break;
			}
			case 10: System.out.println("case 10"); break;
			case 15: System.out.println("case 15"); break;
			case 20: System.out.println("case 20"); break;
			default: System.out.println("Default"); break;
		}
		
		// Loops in Java
		System.out.println("\nExample: 7");
		for(int i = 1; i <= 10; i++) {
			// if(i == 5) break; - // can break for loop
			System.out.println(i);
		}
		// For Each
		int arr[] = {12,23,44,56,78};
		for(int j: arr) {
			if(j == 44) break;
			System.out.println(j);
		}
		// Java Labeled For Loop
		// We can have name of each for loop. To do so, we use label before the for loop. It is useful if we have nested for loop so that we can break/continue specific for loop.
		// Normally, break and continue keywords breaks/continues the inner most for loop only.
		System.out.println("\nExample: 7.3");
		FirstLoop:
			for(a = 1; a <= 3; a++) {
				SecondLoop:
				for(b = 1; b <= 3; b++) {
					if(a == 2 && b == 2) {
						break FirstLoop;
						// break SecondLoop;
					}
					System.out.println(a + "------" + b);
				}
			}
		// Java while / do-while Loop
		System.out.println("\nExample: 8");
		int count = 11;
		do {
			System.out.println("--------"+ count);
			count++;
		} while (count <= 10);
		
		System.out.println("\nExample:  Fibonacci series");
		int num1 = -1;
		int num2 = 1;
		int num3;
		for(int fib = 1; fib <=10; fib++) {
			num3 = num1 + num2;
			System.out.println(num3); // 0 1 1 2 3
			num1 = num2; // 2
			num2 = num3; // 3
		}
	}
}