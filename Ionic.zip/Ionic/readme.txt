IONIC

- To develop mobile(hybrid) apps with almost native look and feel.
- https://scotch.io/tutorials/build-a-mobile-app-with-angular-2-and-ionic-2
- http://www.dotnetcurry.com/javascript/1355/ionic-2-tutorial-with-angular-typescript

Dependencies:
1. Node.js
2. Apache Cordova - npm install -g cordova
3. Ionic - npm install -g ionic


ibms
461378
463732