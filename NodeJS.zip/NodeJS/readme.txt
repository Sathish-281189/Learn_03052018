Node.js is an open source server framework.
Node.js allows you to run JavaScript on the server.
Node.js = Runtime Environment + JavaScript Library


References:

http://codehandbook.org/web-app-using-node-js-and-mysql/
http://adrianmejia.com/blog/2014/10/01/creating-a-restful-api-tutorial-with-nodejs-and-mongodb/
https://scotch.io/tutorials/creating-a-single-page-todo-app-with-node-and-angular
https://github.com/scotch-io/node-todo


INSTALLATION:

Steps:
1. Go to Project directory
2. npm init
3. npm install express --save
4. npm install mongodb --save
5. npm install body-parser --save
