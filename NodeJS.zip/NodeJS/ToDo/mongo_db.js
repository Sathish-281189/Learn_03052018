var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://localhost:3000/mydb';
// Connection
MongoClient.connect(url, function(err, db){
	if(err) {
		throw err;
	}
	console.log("Datbase Created Successfully!!!");
	db.close();
});

