console.log("Hello World!");
var http = require('http');
/*
// Its Working
http.createServer(function (request, response) {
	// Send the HTTP header 
	// HTTP Status: 200 : OK
	// Content Type: text/plain (Or) text/html
	response.writeHead(200, {'Content-Type': 'text/html'});
	response.write('Hello World!<br>');
	response.write('----'+request.url);
	// Send the response body as "Hello World"
	response.end();
}).listen(3000);	// working - 3000, 3030, 4200
*/
// File System module - Read Files
var fs = require('fs');
http.createServer(function (request, response) {
	// To readFile
	fs.readFile('index.html', function(err, data) {
		response.writeHead(200, {'Content-Type': 'text/html'});
		response.write(data);
		response.end();
	});
}).listen(3030);
// Console will print the message
console.log('Server running at `');