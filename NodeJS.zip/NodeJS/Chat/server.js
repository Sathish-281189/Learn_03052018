console.log("Hello World!");
var http = require('http');
var AWS = require('aws-sdk'); // Access key ID - AKIAIWXMT6WE7A34YE3Q; Secret access key - A37fd3Fx1i0ytrNHIW14VvCsfRv/4UUSrgRt4XMA;

// Load your AWS credentials and try to instantiate the object.
AWS.config.loadFromPath('config.json');

// Its Working
http.createServer(function (request, response) {
	// Send the HTTP header 
	// HTTP Status: 200 : OK
	// Content Type: text/plain (Or) text/html
	response.writeHead(200, {'Content-Type': 'text/html'});
	response.write('Hello World!<br>');
	//response.write('----'+request.url);
	// Send the response body as "Hello World"
	response.end();
}).listen(3000);	// working - 3000, 3030, 4200
