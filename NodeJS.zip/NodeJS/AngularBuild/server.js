// 1. https://stackoverflow.com/questions/16579404/url-rewriting-with-expressjs
// 2. https://stackoverflow.com/questions/11569181/serve-static-files-on-a-dynamic-route-using-express
// 3. https://expressjs.com/en/starter/static-files.html
// 4. https://stackoverflow.com/questions/44344793/how-to-run-node-express-server-and-angular-on-the-same-port
// 5. https://gist.github.com/tagr/170627486377551831de
var http	= require('http');
var express	= require('express');
var path	= require('path');
var app		= express();
console.log(path.join(__dirname, 'dist'));
console.log(__dirname + "/dist");
console.log(__dirname);
/*
// Not Working
app.get('/test', function(req, res){
	res.sendFile('index.html', {root: __dirname + "/dist"});
});
*/

// Working fine
// 1. Express looks up the files relative to the static directory, so the name of the static directory is not part of the URL.
app.use(express.static(path.join(__dirname, 'dist'))); // (Or) app.use(express.static(__dirname + "/dist"));
/*
Now, you can load the files that are in the public directory:
http://localhost:3000/images/kitten.jpg
http://localhost:3000/css/style.css
http://localhost:3000/js/app.js
http://localhost:3000/images/bg.png
http://localhost:3000/hello.html
*/

// 2. To create a virtual path prefix (where the path does not actually exist in the file system) for files that are served by the express.static function, specify a mount path for the static directory, as shown below:
app.use('/admin', express.static(path.join(__dirname, 'admin')));  // (Or) app.use('/admin', express.static(__dirname + "/admin"));
app.use('/public', express.static(path.join(__dirname, 'public')));
/*
Now, you can load the files that are in the public directory from the /static path prefix.
http://localhost:3000/static/images/kitten.jpg
http://localhost:3000/static/css/style.css
http://localhost:3000/static/js/app.js
http://localhost:3000/static/images/bg.png
http://localhost:3000/static/hello.html
*/
app.listen(3030);


// Console will print the message
console.log('Server running at http://localhost:3030/');