var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://192.168.0.5/mydb';
// Connection
MongoClient.connect(url, function(err, db){
	if(err) {
		throw err;
	}
	console.log("Datbase Created Successfully!!!");
	db.close();
});

