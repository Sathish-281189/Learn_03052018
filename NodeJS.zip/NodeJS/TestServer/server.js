var http	= require('http');
var express	= require('express');
var app		= express();
const PORT	= 3000;

console.log(__dirname);
app.use(express.static(__dirname + "/dist"));

app.listen(PORT, () => {
	// Console will print the message
	console.log('Server running at http://localhost:3000/');
});