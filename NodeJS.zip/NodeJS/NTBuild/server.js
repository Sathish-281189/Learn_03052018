var http	= require('http');
var express	= require('express');
var path	= require('path');
var app		= express();

// Working fine
app.use(express.static(__dirname)); // (Or) app.use(express.static(__dirname + "/dist"));
app.use('/admin', express.static(path.join(__dirname, 'admin')));  // (Or) app.use('/admin', express.static(__dirname + "/admin"));
app.listen(3030);

// Console will print the message
console.log('Server running at http://localhost:3030/');