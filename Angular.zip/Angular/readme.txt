http://tutorials.jenkov.com/angularjs/dependency-injection.html

angular.element(document).ready(function () {
});

angular.element($window).bind('resize', function(){
});

angular.element($window).bind('orientationchange', function () {

});

You can listen in your controllers defined in routes i.e. SomeController and SomeRouteController for  $viewContentLoaded event. $viewContentLoaded is emitted every time the ngView content is reloaded and should provide similar functionality as the document.ready when routing in angularjs:
function SomeController($scope) {
   $scope.$on('$viewContentLoaded', function() {window.scrollTo(0,90);});
}

// Custom Directive

https://weblogs.asp.net/dwahlin/creating-custom-angularjs-directives-part-2-isolate-scope
http://blogs.quovantis.com/scope-in-custom-directives-angularjs/