/******************* app.js ***********************/
var regexp = /^[a-zA-Z0-9àâäèéêëîïôœùûüÿçÀÂÄÈÉÊËÎÏÔŒÙÛÜŸÇ\s]+$/;
console.log("-----------------"+regexp);
//create the module and name it scotchApp
var TMSApp = angular.module('TMSApp', ['ngRoute','ngSlider', 'ui.sortable', 'ngScrollable', 'infiniteScroll', 'ngAnimate', 'uiSlider', 'ui.bootstrap','ui.bootstrap','TMSApp.services','AngularGM','TMSApp.pdfservices','TMSApp.mapservices','TMSApp.searchservices','TMSApp.filterservices','mb-scrollbar','widgetbox','TMSApp.widgetservices','TMSApp.DealerviewPopup','TMSApp.PermissionPopup','TMSApp.AdditionalvehiclPopup','TMSApp.customerDetail','TMSApp.LoadDynamicTemplate', 'ngStorage', 'ng.deviceDetector']);

// If we implements any security roles our application then that role should be added here.
var allRoles = ['C360_CUSTOMER_ADMIN_VIEWER', 'C360_NON_CUSTOMER_ADMIN_VIEWER', 'C360_TELEMATICS_VIEWER', 'C360_SOCIAL_MENTION_WIDGET', 'C360_SCORING_WIDGET', 'C360_SURVEY_WIDGET', 'C360_CAMPAIGN_WIDGET', 'C360_TELEMATICS_UPDATER', 'C360_CUSTOMER_ADMIN_UPDATER', 'C360_CUSTOMER_UPDATER', 'C360_TOYOTA_INQUIRY_DEALER', 'C360_PD_TOYOTA_INQUIRY_DEALER', 'C360_LEXUS_INQUIRY_DEALER', 'C360_LEXUS_UPDATE_DEALER'];

// Global Variable
var customer_id, canceller;
var field_focus = '';

TMSApp.service('customerService', function() {
	var customerDetails = [];
	var setCusotmer = function(newObj) {
		customerDetails.push(newObj);
	}
	var getCustomer = function() {
		return customerDetails
	};
	return {
		setCusotmer: setCusotmer,
		getCustomer: getCustomer
	};
});


TMSApp.config(['$routeProvider' , '$httpProvider', function($routeProvider, $httpProvider) {
	//initialize get if not there
	if (!$httpProvider.defaults.headers.get) {
		$httpProvider.defaults.headers.get = {};    
	}    
	//disable IE ajax request caching
	$httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
	$httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
	$httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
	$routeProvider
		// route for the home page
		.when('/', {
			templateUrl : 'views/Home.html',
			controller  : 'dashboardcustomerctrlr'
		})
		// route for the contact page
		.when('/Customerprofile', {
			templateUrl : 'views/Customerprofile.html',
			controller  : 'customerprofileController'
		});
}]);

TMSApp.controller('mainController', function($scope,$rootScope) {
    $scope.currentSTab = 'Dashboard';
    
});

TMSApp.controller('socialController', function($scope) {
	$scope.isselected('Social');
});

TMSApp.controller('customerprofileController',['$scope','$rootScope','$window','searchDialog','customerService','pdfDialog','$http','$timeout','$q','$templateCache','SecurityService','PermissionPopup', 'AuthenticationService', '$localStorage', 'deviceDetector', 'EmailWidgetService', function($scope,$rootScope,$window,createDialog,customerService,pdfDialog,$http,$timeout,$q,$templateCache,SecurityService,PermissionPopup, AuthenticationService,$localStorage, deviceDetector, EmailWidgetService) {
	console.log("---------customerprofileController---------------- : "+userId);
	/* $scope.deviceDetector = deviceDetector;
	console.log($scope.deviceDetector); */
	
	/***************************** Begin : Disclaimer Popup *****************************/
	$rootScope.disclaimerDetailPopupView = false;
	$scope.disclaimerPopup = function(){
		var pop_ht = $(window).height() - 40;
		PermissionPopup({
			id: 'termsOfUse',
			templateUrl:'views/TermsOfUsePopup.html',
			title: '',
			modalClass: "popup_container",
			css: { top: "20px", left:"20%", width: "800px", maxHeight: pop_ht+"px", "overflow" :"auto"},
			backdropCancel: false,
			escapeKeyCancel: false,
			backdropClass: "ownerpopup-backdrop white-bg",
			success: {fn: function() {
				AuthenticationService.setCookie("cookie_disclaimer");
				$timeout(function() { $rootScope.isDisclaimerAgreed = true; }, 100);
				$scope.customerConnection();
			}},
			cancel: {fn: function() {
				$scope.DisclaimerDetailPopup('close');
			}}
		});
	}
	$scope.DisclaimerDetailPopup = function(value) {
		$rootScope.disclaimerDetailPopupView = (value == 'open')? true:false;
	}
	if(!AuthenticationService.isCookieExist("cookie_disclaimer")) {
		$scope.disclaimerPopup();
	} else {
		$timeout(function() {
			$rootScope.isDisclaimerAgreed = true;
			console.log("------$rootScope.isDisclaimerAgreed------------"+$rootScope.isDisclaimerAgreed);
		}, 100);
	}
	/***************************** End : Disclaimer Popup *****************************/
	
	/**************************** Begin : Get Customer Role ****************************/
	SecurityService.getCustomerRoleInfo().then(function(data){
		$rootScope.customerRole = [];
		$rootScope.roleType		= '';		
		var us_roles	= data.usRoles;
		var tdpr_roles	= data.tdprRoles;
		
		if((us_roles != null && us_roles.length > 0) && (tdpr_roles != null && tdpr_roles.length > 0)) {
			$rootScope.roleType = 'US_TDPR';
		} else if(us_roles != null && us_roles.length > 0) {
			$rootScope.roleType = 'US';
		} else if(tdpr_roles != null && tdpr_roles.length > 0) {
			$rootScope.roleType = 'TDPR';
		}
		console.log($rootScope.roleType);		
		$(allRoles).each(function(index,role) {
			if(us_roles != null && us_roles.length > 0) {	// US Roles
				if(us_roles.indexOf(role) !== -1) {
					$rootScope.customerRole.push(role);
				}
			}
			if(tdpr_roles != null && tdpr_roles.length > 0) {	// TDPR Roles
				if(tdpr_roles.indexOf(role) !== -1) {
					if($rootScope.customerRole.indexOf(role) == -1) {	//	To remove duplicate value
						$rootScope.customerRole.push(role);
					}
				}
			}
		});
		// Set User Session 
		if(data.sessionValue == "false") {
			console.log("-----reset---------");
			$localStorage.$reset(); //delete all our data from localStorage
			AuthenticationService.setCookie("cookie_userId");
		}
		//$rootScope.customerRole = ['C360_NON_CUSTOMER_ADMIN_VIEWER']; // JTDKB20U373282709
		//$rootScope.customerRole.push('C360_CUSTOMER_ADMIN_UPDATER');
		//$rootScope.customerRole.push('C360_TELEMATICS_UPDATER');
		$rootScope.customerRole.push('C360_SOCIAL_MENTION_WIDGET');
		$rootScope.customerRole.push('C360_SURVEY_WIDGET');
		$rootScope.customerRole.push('C360_SCORING_WIDGET');
		$rootScope.customerRole.push('C360_CAMPAIGN_WIDGET');
		// The higher priority role should take precedence. When both admin and non admin are there , admin should take precedence
		if($rootScope.customerRole.indexOf('C360_CUSTOMER_ADMIN_VIEWER') !== -1 && $rootScope.customerRole.indexOf('C360_NON_CUSTOMER_ADMIN_VIEWER') !== -1) {
			var index = $rootScope.customerRole.indexOf('C360_NON_CUSTOMER_ADMIN_VIEWER');
			$rootScope.customerRole.splice(index, 1);  
		}
		console.log($rootScope.customerRole);
		/*
		 * Excutes on Window load
		 */
		// Load Customer Profile via url from "CUSTOMER CENTRAL"
		$scope.customerConnection();
		// Load Customer Profile on clicking customer/vin from "C360" Solr Search result
		$scope.loadCustomerProfileDetails();
		// Load Dealer Profile on clicking dealer from "C360" Solr Search result
		$scope.loadDealerProfileDetails();
	});
	/***************************** End : Get Customer Role ****************************/
	/*
	// Set CPA Link
	$timeout(function() {
		$rootScope.ecpcURL = angular.element("#ecpcURL").text();
		$rootScope.customerVehicleLink = angular.element("#customerVehicleLink").text();
	}, 500);
	*/
	// Begin : Detect IE browser
	var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
	if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
		$('body').addClass('ie');
	}
	// End : Detect IE browser
	
	/*********************** Begin : Window & body evnets *****************************/
	angular.element($window).bind('resize', function(){
		setScrollViewport();
		setSearchContainer();
		setPrintContainer();
		setMergePurgeContainer();
		setRecentSearchContainer();
	});
	angular.element($window).bind('keydown', function(e){
		if(e.which === 27) {
			if(canceller !== undefined) {
				canceller.resolve("Request Cancelled");
			}
		}
	});
	angular.element('body').bind('click', function(event){
		// Prevent the click action which made on Popup container
		if($('.popup_container').length) {
			var container = $(".popup_container");
			if (!container.is(event.target)) {
				return true;
			}
		}
		// To close dropdown when clicking outside
		if($('#searchResults').length) {
			var container = $(".new-dropdown");
			if (!container.is(event.target) && container.has(event.target).length === 0) {
				$scope.dropdownFlag = false;
			}
		}
		// Advance Search Form
		var search_cont	= $(".advance_search");
		if ((!search_cont.is(event.target) && search_cont.has(event.target).length === 0)) {
			if($scope.advanceSearchFormFlag) {
				$scope.openAdvanceSearch();
			}
		}
		// Merge Purge
		var merge_btn	= $(".merge_purge");
		if ((!merge_btn.is(event.target) && merge_btn.has(event.target).length === 0) && (event.target.id != 'address_cancel' && event.target.id != 'address_update')) {
			if($rootScope.mergePurgeViewFlag) {
				$rootScope.mergePurgeViewFlag = false; 
			}
		}
		if($('#editProfileView').length || $scope.advanceSearchFormFlag) {
			var container = $(".dropdown-wrapper");
			if (!container.is(event.target) && container.has(event.target).length === 0) {
				$('.dropdown-list').hide();
			}
		}
		// Email Widget
		var email_cont	= $(".email_container");
		if ((!email_cont.is(event.target) && email_cont.has(event.target).length === 0)) {
			if($rootScope.emailDropdownFlag) {
				$rootScope.emailDropdownFlag = false; 
			}
		}
		// Recent Search
		var recentsearch_cont	= $(".recent-search");
		if ((!recentsearch_cont.is(event.target) && recentsearch_cont.has(event.target).length === 0)) {
			$rootScope.recentSearchViewFlag = false; 
		}
		// To close Advance filter when clicking outside
		if($('.filter-area').length) {
			var container = $(".filter-container");
			if (!container.is(event.target) && container.has(event.target).length === 0) {
				$rootScope.emailFilterFlag = false;
			}
		}
	});
	/*********************** End : Window & body evnets *****************************/
	
	$rootScope.hasAccess = function(module) {
		return SecurityService.checkAccess(module);
	}
	// Begin : Variable Initialisation
    /* var customerObject, customer_id; */
	$scope.defaultInitialization = function() {
		console.log("-defaultInitialization------");
		// Scope variables
		$scope.c360status1				= false;	// if FALSE "Customer Search" Page is visible else "C360 Profile Or Dashboard" Page
		$scope.c360status2				= true;		// if TRUE "Customer Search" Page is visible else "C360 Profile Or Dashboard" Page
		$scope.searched					= false;
		$scope.dropdownFlag				= false;
		$scope.advanceSearchFormFlag	= false;
		$scope.advanceSearchResultFlag	= false;
		$scope.solarSearchResultFlag	= false;
		//$scope.goBackFlag				= false;
		$scope.dealerSolrSearch			= false;
		$scope.dealerDetailFlag			= false;
		$scope.dealerSearchResultFlag	= false;
		$rootScope.mergePurgeViewFlag	= false;
		$scope.startIndex				= 0;
		$scope.endIndex					= 10;
		// Rootscope Variables
		$rootScope.VehicleMakeModel		= '';
		$rootScope.nocustomer 			= false;
		$rootScope.vinView				= false;
		$rootScope.editProfileView		= false;
		$rootScope.selectedVin			= '';
		//$rootScope.searchResultData	= '';
		// Delete previously searched customer details
		if($rootScope.Newcustomer != undefined) {
			delete $rootScope.customerId;
			delete $rootScope.Newcustomer;
			$rootScope.ownerEffectiveDate = '';
		}
		$rootScope.weeks = ['Monday','Tueday','Wednesday','Thursday','Friday','Saturday','Sunday'];
	}
	$scope.defaultInitialization();
	// End : Variable Initialisation
    $templateCache.remove('views/Customerprofile.html')
    
    var login_id = userId;
	$timeout(function(){
		$rootScope.$broadcast('loginid', login_id)
	},300);
    console.log('User Id : '+userId);
    /* Main Menu Tab */
    $scope.tab = 1;
    $scope.setTab = function (tabId) {
        $scope.tab = tabId;
    };
    $scope.isSet = function (tabId) {
       return $scope.tab === tabId;
    };
	/* Search Menu Tab */
	var setSearchMenuByRole = setInterval(function(){
		if($rootScope.customerRole != undefined && $rootScope.customerRole.length > 0) {
			$scope.searchTab = (SecurityService.checkAccess('admin_view'))? 1 : 2;
			$scope.isVin	 = (SecurityService.checkAccess('admin_view'))? 'No' : 'Yes';
			clearInterval(setSearchMenuByRole);
		}
	}, 100);
	$scope.searchPlaceholder = ['Search by Last/First Name or Customer ID or Phone or Email ID', 'Search by minimum of three digits', 'Search by Dealer name or Code'];
	$scope.setSearchMenu = function(tabId) {
		$scope.isVin	 = (tabId == 2)? 'Yes':'No';
		$scope.searchTab = tabId;
		$timeout(function(){
			$('#focussearch').val('');
    	},10)
		if($rootScope.searchResultData != undefined) {
			$rootScope.searchResultData.errorMsg	= '';
			$rootScope.searchResultData.errorCodes	= '';
		}
	}
	$scope.isSearchMenu = function (tabId) {
		return $scope.searchTab === tabId;
	};
	$scope.$on('showCustomerProfile', function(events){
		$timeout(function(){
			$scope.c360status1	= true;
			$scope.c360status2	= false;
		},300);
	});
	$scope.$on('showMainProfilePage', function(events){
		$timeout(function(){
			$scope.c360status1	= false;
			$scope.c360status2	= true;
		},300);
	});
	$scope.$on('showMainMenuTab', function(events, tabId){
		$timeout(function(){
			$scope.setTab(tabId);
		},300);
	});
	$scope.setVehicleTab = function(event) {
		console.log('---------------vehicle Tab clicked---------------');
		if(event !== undefined) {
			if($(event.target).hasClass('active')) return false;
		}
		$('.loader_outer, .loader_inner').show();
		$rootScope.VehicleMakeModel	= '';
		if(($rootScope.vehicles != undefined && $rootScope.vehicles.length !=0) || ($rootScope.disposedVehicles != undefined && $rootScope.disposedVehicles.length !=0)) {
			if($rootScope.vehicles.length != 0)
				$rootScope.VehiclesClicked = $rootScope.vehicles;
			else
				$rootScope.VehiclesClicked = $rootScope.disposedVehicles;
			var vehicle = $rootScope.VehiclesClicked[0].vin;
			var modelyear = $rootScope.VehiclesClicked[0].modelYear;
			var modelname = $rootScope.VehiclesClicked[0].model;
			var brand = $rootScope.VehiclesClicked[0].brand;
			$timeout(function(){
				$rootScope.$broadcast('VehicleClicked', vehicle,modelyear,modelname,brand);
				setScrollViewport();
			},300);
		} else {
			if($rootScope.vehicles == undefined || $rootScope.disposedVehicles == undefined) {
				$scope.setTab(3); // Set to Dashboard
			}
			$('.loader_outer, .loader_inner').hide();
		}
	};
	$scope.showHousehold = function(event){
		if($(event.target).hasClass('active')) return false;
		$('.loader_outer, .loader_inner').show();
		$timeout(function(){
			$rootScope.$broadcast('HouseholdClicked');
			setScrollViewport();
		},300);   
	};
	$scope.showDashboardTab = function(event){
		if($(event.target).hasClass('active')) return false;
		EmailWidgetService.resetEmailWidgetData('Widget');
		$('.loader_outer, .loader_inner').show();
		$timeout(function(){
			$('.loader_outer, .loader_inner').hide();
			setScrollViewport();
		},300);
	};
	$scope.setCategoryTab = function(){
		if(SecurityService.checkAccess('survey_viewer'))
			$rootScope.$broadcast('SurveyDetails',1);
		else if(SecurityService.checkAccess('email_viewer'))
			$rootScope.$broadcast('SurveyDetails',2);
		else
			$rootScope.$broadcast('SurveyDetails',3);
		$timeout(function(){ setScrollViewport(); }, 300);
	};
	$scope.getEmailCampaignDetails = function() {
		$rootScope.$broadcast('GetEmailCampaignDetails');
	}
	$scope.openSearchbox=function(){
        //$rootScope.$broadcast("mapstatuschange", 'true');
        createDialog({
            id: 'searchDialog',
            templateUrl:'views/searchbar.html',
            //title: 'Family members',
            backdrop: true,
            success: {label: 'Success', fn: function() {console.log('Inline modal closed');}}
        });
    };
    $scope.clearSearch = function() {
        $scope.searchText = null;
    }
	$scope.searchid = false;
    $scope.outsideClicked = function(){
        if($scope.searchid == true){
            $scope.searchid = false;
        }
    };
    $scope.networkConnection=false;
	/*************************** Begin : Customer Solr Search *******************************/
    $scope.getCustomer = function(val) {
		$("#focussearch").addClass('inline_loader');
		var query_string = val.toUpperCase();
		if($.trim(query_string).length < 3) {
			$("#focussearch").removeClass('inline_loader');
			return false;
		}
		var f_name, l_name, name, highlight_name;
		return $http.get('getsuggestedcustomers.do?custQuery='+encodeURIComponent(query_string)+'&isVin='+$scope.isVin+'&distributor='+$rootScope.roleType+'&showMoreValue=N').then(function(response) {
			$timeout(function(){ 
				$("#focussearch").removeClass('inline_loader');
			},300)
			var custom_object = []
			var result = response.data;
			// No respone
			if(result == '') return custom_object;
			// Service Unavailable
			if(result.errorCode != undefined && result.errorCode == 500) {
				if(SecurityService.checkAccess('admin_view')) {
					custom_object.push({'errorCode': 500, 'errorMessage': 'Service temporarily Unavailable. Use advance Search.' })
					return custom_object;
				} else {
					$scope.networkConnection = true;
					return false;
				}
			}
			// Search with results
			customer_data = result.response.docs;
			for(var i = 0; i < customer_data.length; i++){
				if(customer_data[i].customer_type == 'PERSON' || customer_data[i].customer_type == 'BUSINESS') {
					//var f_name, l_name, name, highlight_name;
					f_name = l_name = name = highlight_name = '';
					if(customer_data[i].customer_type == 'PERSON'){
						if(customer_data[i].hasOwnProperty('first_nm')) {
							f_name	= customer_data[i].first_nm;
						}
						l_name	= customer_data[i].last_nm;
						name	= f_name.concat(' ',l_name);
					} else {
						name	= customer_data[i].organization_nm;
					}
					highlight_name = name;
					var custId	= customer_data[i].customer_id;
					var address = customer_data[i].mail_adr_address_line_1;
					var address2 = customer_data[i].mail_adr_address_line_2;
					var state	= customer_data[i].mail_addr_state;
					var city	= customer_data[i].mail_addr_city;
					var postal	= customer_data[i].mail_adr_postal_cd;
					var email	= customer_data[i].pr_eml_email_address;
					var phone	= customer_data[i].pr_phn_phone_no;
					// Begin: To highlight searched text
					var query_array = $.trim(query_string).split(" ");
					angular.forEach(query_array, function(value, key) {
						var isSpan = '<'+value;
						if(customer_data[i].customer_type == 'PERSON'){
							if(f_name.indexOf(value) != -1 && f_name.indexOf(isSpan) == -1) {
								f_name = f_name.replace(value, '<span style="color:red;">'+value+'</span>');
							}
							if(l_name.indexOf(value) != -1 && l_name.indexOf(isSpan) == -1) {
								l_name = l_name.replace(value, '<span style="color:red;">'+value+'</span>');
							}
							highlight_name = f_name.concat(' ',l_name);
						} else {
							if(name != undefined && name.indexOf(value) != -1 && name.indexOf(isSpan) == -1) {
								highlight_name = highlight_name.replace(value, '<span style="color:red;">'+value+'</span>');
							}
						}
						if(address != undefined && address.indexOf(value) != -1 && address.indexOf(isSpan) == -1) {
							address = address.replace(value, '<span style="color:red;">'+value+'</span>');
						}
						if(address2 != undefined && address2.indexOf(value) != -1 && address2.indexOf(isSpan) == -1) {
							address2 = address2.replace(value, '<span style="color:red;">'+value+'</span>');
						}
						if(state != undefined && state.indexOf(value) != -1 && state.indexOf(isSpan) == -1) {
							state = state.replace(value, '<span style="color:red;">'+value+'</span>');
						}
						if(city != undefined && city.indexOf(value) != -1 && city.indexOf(isSpan) == -1) {
							city = city.replace(value, '<span style="color:red;">'+value+'</span>');
						}
						if(postal != undefined && postal.indexOf(value) != -1 && postal.indexOf(isSpan) == -1) {
							postal = postal.replace(value, '<span style="color:red;">'+value+'</span>');
						}
						if(email != undefined && email.indexOf(value.toLowerCase()) != -1 && email.indexOf(isSpan.toLowerCase()) == -1 && email.indexOf('<span') == -1) {
							email = email.replace(value.toLowerCase(), '<span style="color:red;">'+value.toLowerCase()+'</span>');
						}
						if(phone != undefined && phone.indexOf(value) != -1 && phone.indexOf(isSpan) == -1) {
							phone = phone.replace(value, '<span style="color:red;">'+value+'</span>');
						}
						if(custId != undefined && custId.indexOf(value) != -1 && custId.indexOf(isSpan) == -1) {
							custId = custId.replace(value, '<span style="color:red;">'+value+'</span>');
						}
					});
					// Ends: To highlight searched text
					custom_object.push({ 'name': name, 'highlight_name': highlight_name, 'mail_adr_address_line_1': address, 'mail_adr_address_line_2': address2, 'mail_addr_state': state, 'mail_addr_city': city, 'mail_adr_postal_cd': postal, 'customer_id': customer_data[i].customer_id, 'highlight_customer_id': custId, 'pr_eml_email_address': email, 'pr_phn_phone_no': phone });
				}
				// Vin Make model year
				if(custom_object[i] == undefined) {
					custom_object.push({'name':customer_data[i].vin});
				}
				if(!SecurityService.checkAccess('admin_view')) {
					custom_object[i].name = (customer_data[i].vin != undefined)? customer_data[i].vin: '';
				}
				custom_object[i].isVin		= $scope.isVin;
				custom_object[i].vin		= (customer_data[i].vin != undefined)? customer_data[i].vin: '';
				custom_object[i].make		= (customer_data[i].make != undefined)? customer_data[i].make: '';
				custom_object[i].model		= (customer_data[i].model != undefined)? customer_data[i].model: '';
				custom_object[i].year		= (customer_data[i].model_year != undefined)? customer_data[i].model_year: '';
				custom_object[i].isAdmin	= SecurityService.checkAccess('admin_view');
				custom_object[i].distributor= (customer_data[i].distributor != undefined)? customer_data[i].distributor:'';
				custom_object[i].roleType	= $rootScope.roleType;
			}
			if(custom_object.length == 1 && custom_object[0].customer_id != undefined && ($scope.isVin == 'Yes' || custom_object[0].vin != '')) {
				$http.get('getcust.do?customerId='+custom_object[0].customer_id).then(function(response) {
					f_name = l_name = name = '';
					var result = response.data.response.docs;
					if(result[0] != undefined) {
						if(SecurityService.checkAccess('admin_view')) {
							if(result[0].customer_type == 'PERSON'){
								if(result[0].hasOwnProperty('first_nm')) {
									f_name	= result[0].first_nm;
								}
								l_name	= result[0].last_nm;
								name	= f_name.concat(' ',l_name);
							} else {
								name	= result[0].organization_nm;
							}
						} else {
							name = custom_object[0].vin;
						}
						custom_object[0].name						= name;
						custom_object[0].highlight_name				= name;
						custom_object[0].mail_adr_address_line_1	= result[0].mail_adr_address_line_1;
						custom_object[0].mail_adr_address_line_2	= result[0].mail_adr_address_line_2;
						custom_object[0].mail_addr_state			= result[0].mail_addr_state;
						custom_object[0].mail_addr_city				= result[0].mail_addr_city;
						custom_object[0].mail_adr_postal_cd			= result[0].mail_adr_postal_cd;
						custom_object[0].pr_eml_email_address		= result[0].pr_eml_email_address;
						custom_object[0].pr_phn_phone_no			= result[0].pr_phn_phone_no;
					}
				});
			}
			return custom_object;
		}).catch(function(response){
			console.log("caught the error");
			$scope.networkConnection=true;
		});   
	};
	$rootScope.getShowMoreCustomer = function() {
		$('.loader_outer, .loader_inner').show();
		var val = $('#focussearch').val();
		if($scope.searchTab == 3) {	// Dealer
			var url = 'getdealerinfo.do?str='+encodeURIComponent(val)+'&showMoreValue=Y';
		} else { // Customer & VIN
			var url = 'getsuggestedcustomers.do?custQuery='+encodeURIComponent(val)+'&isVin='+$scope.isVin+'&distributor='+$rootScope.roleType+'&showMoreValue=Y';
		}
		$http.get(url).then(function(response) {
			$scope.defaultInitialization(); // Reset Variables
			$('.loader_outer, .loader_inner').hide();
			$rootScope.searchResultData	= response.data.response.docs;
			console.log($rootScope.searchResultData);
			if($rootScope.searchResultData.length > 0) {
				if($scope.searchTab == 3) {	// Dealer
					$scope.dealerSearchResultFlag	= true;
					$scope.dealerSolrSearch = true;
				} else { // Customer & VIN
					$scope.solarSearchResultFlag	= true;
				}
				$scope.searchResultCnt	= $rootScope.searchResultData.length;
				setTimeout(function() {
					$("#searchResults").animate({"scrollTop": "0px"}, 500);
					setSearchContainer();
				}, 500);
			} else {
				$scope.searchResultCnt = 0;
			}
		});
	}	
	$scope.getRedirectUrl = function(values) {
		var redirectUrl = '';
		if(values.customer_id != undefined && values.customer_id != '' && SecurityService.checkAccess('admin_view')) {
			redirectUrl = 'cid='+values.customer_id;
		}
		if(values.vin != undefined && values.vin != '') {
			if(redirectUrl != '')
				redirectUrl += '&cvin='+values.vin;
			else
				redirectUrl = 'cvin='+values.vin;
		}
		return redirectUrl;
	}
	$scope.redirect = function(param1, param2, type) {	// param1 - CustomerId/DealerCode, param2 - Vin/Brand, type - Customer/Dealer
		if(type == 'Customer') {
			var customObj	= { customer_id:param1, vin:param2 };
			var url			= $scope.getRedirectUrl(customObj);
		} else {
			var url	= 'dealerCd='+param1;
			if(param2 != '') url += '&brand='+param2;
		}
		$timeout(function(){ window.location = "profile.do?"+url; }, 300);
	}
	$scope.getCustomerInfoBySolarSearch = function(object) {
		console.log(object);
		// assign value to local storage
		$localStorage.customerOrDealerData	= object;
		// Get Redirect URL
		var redirectUrl = $scope.getRedirectUrl(object);
		// Redirect
		$timeout(function(){ window.location = "profile.do?"+redirectUrl; }, 300);
	}
	$scope.onCustomSelect = function(values){
		if(values.errorCode != undefined && values.errorCode == 500) {
			$timeout(function(){ $('#focussearch').val(''); }, 30)
			return false;
		}
		// assign value to local storage
		$localStorage.customerOrDealerData	= values;
		// Get Redirect URL
		var redirectUrl = $scope.getRedirectUrl(values);
		// Redirect
		$timeout(function() { window.location = "profile.do?"+redirectUrl; }, 300);
	}
	$scope.onSelect = function(values){
		console.log(values);
		if(values.errorCode != undefined && values.errorCode == 500) {
			$timeout(function(){ $('#focussearch').val(''); }, 30)
			return false;
		}
		var login_id = userId;
		$('.loader_outer, .loader_inner').show();
		$timeout(function(){ $('#focussearch').blur(); },10)
		$timeout(function(){ $rootScope.$broadcast('loginid', login_id) },300);
		$scope.defaultInitialization(); // Reset Variables
		$scope.c360status1	= true;
		$scope.c360status2	= false;
		if(values.customer_id != undefined && values.customer_id != '') {
			var cust_id = values.customer_id;
			var EmailId = values.pr_eml_email_address;
			$timeout(function(){ $rootScope.$broadcast('Email', EmailId);  }, 100);
			$timeout(function(){ $rootScope.$broadcast('customerid', cust_id); }, 900);
			if(values.vin != undefined && values.vin != '') {
				$scope.setTab(1); // to set Vehicle Tab
				/*
				var modelYear = (values.model_year != undefined)? values.model_year : (values.year != undefined)? values.year : '';
				$timeout(function(){ $rootScope.$broadcast('VehicleClicked', values.vin, values.modelYear, values.model, values.make); }, 1000);
				*/
				if(values.model_year != undefined) {
					$timeout(function(){ $rootScope.$broadcast('VehicleClicked', values.vin, values.model_year, values.model, values.make); }, 1000);
				} else if(values.year != undefined) {
					$timeout(function(){ $rootScope.$broadcast('VehicleClicked', values.vin, values.year, values.model, values.make); }, 1000);
				}
				// If C360_NON_CUSTOMER_ADMIN_VIEWER, Add To Recent search history
				if(SecurityService.checkAccess('non_admin')) {
					$scope.addToRecentSearchHistory('Vin', values.vin, values);
				}
			} else {
				$scope.setTab(1); // to set Vehicle Tab
				var getCustomerDetailsOnLoad = setInterval(function(){
					if($rootScope.Newcustomer != undefined) {
						$scope.setVehicleTab();
						clearInterval(getCustomerDetailsOnLoad);
					}
				}, 100);
			}
		} else {
			$rootScope.vinView = true;
			$timeout(function(){ $rootScope.$broadcast('customerid', '', values.vin); }, 900);
			if(values.model_year != undefined) {
				$timeout(function(){ $rootScope.$broadcast('VehicleClicked', values.vin, values.model_year, values.model, values.make); }, 1000);
			} else if(values.year != undefined) {
				$timeout(function(){ $rootScope.$broadcast('VehicleClicked', values.vin, values.year, values.model, values.make); }, 1000);
			}
			$scope.setTab(1); // to set Vehicle Tab
			// Orphan Vin - Add To Recent search history
			$scope.addToRecentSearchHistory('Vin', values.vin, values);
		}
		$timeout(function(){ setScrollViewport(); }, 1000);
	}
	$scope.loadCustomerProfileDetails = function() {
		console.log("----loadCustomerProfileDetails---------");
		// Get parameters
		var id	= getParameterByName('cid');
		var vin	= getParameterByName('cvin');
		if(id == null && vin == null) return false;
		// Load Customer Profile
		console.log($localStorage);
		if($localStorage.customerOrDealerData != undefined) {
			console.log("----loadCustomerProfileDetails------if-----");
			var values = $localStorage.customerOrDealerData;
			console.log(values);
			delete $localStorage.customerOrDealerData;
			// To dispay searched customer NAME/VIN in Searchbar Text Field
			if(values.name != undefined) {
				$scope.searchText = values.name;
			} else if(values.first_nm != undefined) {
				$scope.searchText = values.first_nm+' '+values.last_nm;
			} else if(values.vin != undefined) {
				$scope.searchText = values.vin;
			}
			$scope.onSelect(values);
		} else {
			console.log("----loadCustomerProfileDetails------else-----"+id+"------"+vin+"--------"+SecurityService.checkAccess('admin_view'));
			$scope.defaultInitialization(); // Reset Variables
			if(SecurityService.checkAccess('admin_view') && (id != null && id != '')) {
				$scope.$broadcast('showCustomerProfile');
				$timeout(function(){ $rootScope.$broadcast('customerid', id); }, 900);
				if(vin == null || vin == '') {
					var getCustomerDetailsOnLoad = setInterval(function(){
						if($rootScope.Newcustomer != undefined) {
							// To dispay in Search Text Field
							if($rootScope.Newcustomer.customerType == 'BUSINESS'){
								$scope.searchText = angular.copy($rootScope.Newcustomer.organizationName).toUpperCase();
							} else {
								$scope.searchText = angular.copy($rootScope.Newcustomer.customerFirstName+' '+$rootScope.Newcustomer.customerLastName).toUpperCase();
							}
							// Set recent vehicle
							$scope.setVehicleTab();
							clearInterval(getCustomerDetailsOnLoad);
						}
					}, 100);
				}
			}
			if(vin != null && vin != '') {
				if(id == null || id == '') {
					$rootScope.vinView = true;
					$timeout(function(){ $rootScope.$broadcast('customerid', '', vin); }, 900);
					$scope.addToRecentSearchHistory('Vin', vin, '');
					$scope.searchText = angular.copy(vin).toUpperCase(); // To dispay in Search Text Field
				} else {
					var getCustomerDetailsOnLoad = setInterval(function(){
						if($rootScope.Newcustomer != undefined) {
							console.log("------unit testing--------");
							// To dispay in Search Text Field
							if($rootScope.Newcustomer.customerType == 'BUSINESS'){
								$scope.searchText = angular.copy($rootScope.Newcustomer.organizationName).toUpperCase();
							} else {
								$scope.searchText = angular.copy($rootScope.Newcustomer.customerFirstName+' '+$rootScope.Newcustomer.customerLastName).toUpperCase();
							}
							clearInterval(getCustomerDetailsOnLoad);
						}
					}, 100);
				}
				$scope.$broadcast('showCustomerProfile');
				$timeout(function(){ $rootScope.$broadcast('VehicleClicked', vin, '', '', ''); }, 1000);
			}
		}
	}
	
	/*************************** End : Customer Solr Search *********************************/
	
	/***************************** Begin : Dealer Solr Search Module ************************/
	$scope.getDealer = function(val) {
		$("#focussearch").addClass('inline_loader');
		var query_string = val.toUpperCase();
		if($.trim(query_string).length < 3) {
			$("#focussearch").removeClass('inline_loader');
			return false;
		}
		var name, highlight_name, dealer_code, highlight_dealer_code;
		var dealer_data = [];
		return $http.get('getdealerinfo.do?str='+encodeURIComponent(query_string)+'&showMoreValue=N').then(function(response) {
			$timeout(function(){ $("#focussearch").removeClass('inline_loader'); },300)
			var result = response.data;
			// No respone
			if(result == '') return dealer_data;
			// Service Unavailable
			if(result.errorCode != undefined && result.errorCode == 500) {
				if(SecurityService.checkAccess('admin_view')) {
					dealer_data.push({'errorCode': 500, 'errorMessage': 'Service temporarily Unavailable. Use advance dealer Search.' })
					return dealer_data;
				} else {
					$scope.networkConnection = true;
					return false;
				}
			}
			dealer_data = result.response.docs;
			// Begin: To highlight searched text
			for(var i = 0; i<dealer_data.length; i++){
				dealer_data[i].dealer_nm = dealer_data[i].dealer_nm.toUpperCase();
				dealer_code		= dealer_data[i].dealer_cd;
				name 			= dealer_data[i].dealer_nm;
				highlight_name	= name;
				if(name != undefined && name.indexOf(query_string) != -1) {
					highlight_name = highlight_name.replace(query_string, '<span style="color:red;">'+query_string+'</span>');
				}
				dealer_data[i].highlight_name = highlight_name;
				if(dealer_code != undefined && dealer_code.indexOf(query_string) != -1) {
					dealer_code = dealer_code.replace(query_string, '<span style="color:red;">'+query_string+'</span>');
				}
				dealer_data[i].highlight_dealer_code = dealer_code;
			}
			return dealer_data;
		}).catch(function(response){
			$scope.networkConnection = true;
		});
	}
	$scope.onCustomDealerSelect = function(values, brand){
		if(values.dealer_cd != undefined) {
			var queryString = 'dealerCd='+values.dealer_cd;
		} else if(values.dealerCode != undefined) {
			var queryString = 'dealerCd='+values.dealerCode;
		}
		if(brand != undefined) {
			queryString += '&brand='+brand;
		}
		$timeout(function(){ window.location = "profile.do?"+queryString; }, 300);
	}
	$scope.onDealerSelect = function(value, type, brand){ // type: 1 - Solr, 2 - Advance Search
		console.log(value+"---------"+type+"--------------"+brand);
		$timeout(function() { $('.loader_outer, .loader_inner').show(); }, 100);
		var dealerCd = (value.dealer_cd != undefined)? value.dealer_cd:(value.dealerCode != undefined)? value.dealerCode : value;
		// Reset Variables
		$scope.c360status1	= false;
		$scope.c360status2	= true;	
		//$scope.goBackFlag = (type != undefined && type == 2)? true : false;
		if(brand != undefined && brand != null) {
			var url = 'getDelearResults.do?param=dealerCode&brand='+brand+'&paramValue='+dealerCd;
		} else {
			var url = 'getDelearDetails.do?dealerCd='+dealerCd;
		}
		$http.get(url).then(function(response){
			$timeout(function() { $('.loader_outer, .loader_inner').hide(); }, 100);
			$rootScope.dealerInfoDetail = response.data;
			if($rootScope.dealerInfoDetail.dealerInfo != undefined) {
				$scope.searchText = $rootScope.dealerInfoDetail.dealerInfo.dealerName.toUpperCase();
			}
			$scope.dealerDetailFlag			= true;
			$scope.advanceSearchFormFlag	= false;
			$scope.dealerSearchResultFlag	= false;
		});
	}
	$scope.loadDealerProfileDetails = function() {
		var dealerCd = getParameterByName('dealerCd');
		var brand	 = getParameterByName('brand');
		if(dealerCd != null && dealerCd != '') {
			$timeout(function() { 
				$scope.onDealerSelect(dealerCd, 1, brand);
				$scope.searchTab = 3;
			}, 100);
		}
	}
	/*
	$scope.goBack = function() {
		$scope.goBackFlag 				= false;
		$scope.dealerDetailFlag			= false;
		$scope.dealerSearchResultFlag	= true;
	}
	*/
	/***************************** End : Dealer Solr Search Module ***************************/
	
	$scope.myFunc = function(values){
		var login_id = userId;
		$rootScope.$broadcast('loginid',login_id);
		customer_id = values;
		$scope.searched = true;
		$timeout(function(){
			$rootScope.$broadcast('customerid', values)
		},300)
		$scope.c360status1	= true;
		$scope.c360status2	= false;
		$scope.searchid		= false;
	}
	$scope.predicate="-stDate"
   
	var feed = socialData
	var campaign = marketingData
	var images = widget_Images
	var vehicle = vehicledata

	$scope.getC360status1=function(){
		return $scope.c360status1;
	};
	$scope.getC360status2=function(){
		return $scope.c360status2;
	};
	$scope.isVinView=function(){
		return $rootScope.vinView;
	};
	
	/********************** Begin : Advance Search (Customer & Dealer) Module ******************/
	/*
	$scope.dropdownFlag				= false;
	$scope.advanceSearchFormFlag	= false;
	$scope.advanceSearchResultFlag	= false;
	*/
	$scope.formLabel =	{ "firstNm" : "First Name", "lastNm" : "Last Name", "middleInitial" : "Middle Initial", "vin" : "VIN", "email" : "Email", "phoneNo" : "Phone", "organizationNm" : "Organization", "address" : "Address", "city" : "City", "state" : "State", "zipcode" : "Zipcode", "customerID" : "Customer ID", "dealerName" : "Dealer Name", "dealerCode" : "Dealer Code", "region" : "Region", "areaOffice" : "Area Office" };
	// Initialise Form Data
	$scope.initializeFormData = function() {
		console.log("--------------initializeFormData--------------");
		$scope.formData =	{ "firstNm" : "", "fnameExact" : "No", "lastNm" : "", "lnameExact" :"No", "middleInitial" : "", "vin" : "", "email" : "", "phoneNo" : "", "organizationNm" : "", "address" : "", "city" : "", "state" : "", "zipcode" : "", "customerID" : "", "distributor" : $rootScope.roleType };
		$scope.dealerBrand = "Toyota";
		$scope.dealerFormData =	{ "dealerName" : "", "dealerCode" : "", "city" : "", "state" :"", "zipcode" : "", "region" : "", "areaOffice" : "" };
		$scope.statesDDL = { "" :"Select", "AA" :"AA", "AE" :"AE", "AK" :"AK", "AL" :"AL", "AP" :"AP", "AR" :"AR", "AS" :"AS", "AZ" :"AZ", "CA" :"CA", "CO" :"CO", "CT" :"CT", "DC" :"DC", "DE" :"DE", "FL" :"FL", "GA" :"GA", "GU" :"GU", "HI" :"HI", "IA" :"IA", "ID" :"ID", "IL" :"IL", "IN" :"IN", "KS" :"KS", "KY" :"KY", "LA" :"LA", "MA" :"MA", "MD" :"MD", "ME" :"ME", "MI" :"MI", "MN" :"MN", "MO" :"MO", "MP" :"MP", "MS" :"MS", "MT" :"MT", "NC" :"NC", "ND" :"ND", "NE" :"NE", "NH" :"NH", "NJ" :"NJ", "NM" :"NM", "NV" :"NV", "NY" :"NY", "OH" :"OH", "OK" :"OK", "OR" :"OR", "PA" :"PA", "PR" :"PR", "PW" :"PW", "RI" :"RI", "SC" :"SC", "SD" :"SD", "TN" :"TN", "TX" :"TX", "UT" :"UT", "VA" :"VA", "VI" :"VI", "VT" :"VT", "WA" :"WA", "WI" :"WI", "WV" :"WV", "WY" :"WY" };
		$scope.regionDDL = { "":"Select", "BOSTON":"BOSTON", "CENTRAL ATLANTIC":"CENTRAL ATLANTIC", "CHICAGO":"CHICAGO", "CINCINNATI":"CINCINNATI", "DENVER":"DENVER", "GULF STATES":"GULF STATES", "KANSAS CITY":"KANSAS CITY", "LOS ANGELES":"LOS ANGELES", "NEW YORK":"NEW YORK", "PORTLAND":"PORTLAND", "SAN FRANCISCO":"SAN FRANCISCO", "SOUTHEAST":"SOUTHEAST" };
		$scope.areaDDL = { "":"Select", "CENTRAL":"CENTRAL", "SOUTHERN":"SOUTHERN", "WESTERN":"WESTERN", "EASTERN":"EASTERN" };
	}
	$scope.initializeFormData();
	
	// Open Advance Search Form
	$scope.openAdvanceSearch = function() {
		console.log($scope.dealerFormData);
		if(!$scope.advanceSearchResultFlag && !$scope.dealerSearchResultFlag) {
			$scope.initializeFormData();
		}
		$scope.adsort = "[firstname, lastname]"; // default sort order
		$scope.advanceSearchFormFlag = !$scope.advanceSearchFormFlag;
	};
	// Reset Advance Search Formdata
	$scope.resetSearch = function() {
		$scope.initializeFormData();
		$('span.err_msg').css('opacity', 0); 
		$('.blue_focus').removeClass('blue_focus');
		$('.required').hide();
		$('#state_label, #region_label, #area_office_label').val('Select');
		$("#advancedSearch .dropdown-list li").removeClass('selected');
		$rootScope.searchResultData.errorMsg	= '';
		$rootScope.searchResultData.errorCodes	= '';
		if($scope.advanceSearchResultFlag) $scope.advanceSearchResultFlag = false;
		if($scope.dealerSearchResultFlag) $scope.dealerSearchResultFlag = false;
	}
	$scope.setDealerBrand = function() {
		$scope.dealerFormData.region = '';
		$scope.dealerFormData.areaOffice = '';
		$('#region_label, #area_office_label').val('Select');
		$scope.dealerBrand	= (angular.element("input[name=brand]:checked").val() == 1)? 'Toyota': 'Lexus';
	}
	// Customer Advance Search Submit Action
	$scope.submitAdvanceSearchForm = function(mode) { // as - Advance Search, cc - Customer Connection VIN search
		$('.blue_focus').removeClass('blue_focus');
		$('#errorMsg, .required').hide();
		$('#focussearch').val('');
		canceller = $q.defer();
		$rootScope.nocustomer	= false;
		$scope.startIndex		= 0;
		$scope.endIndex			= 10;
		var submitFlag			= true;
		var data				= $scope.formData;
		console.log(data);
		$scope.postData	= angular.copy($scope.formData);
		$rootScope.searchResultData =  {};
		$scope.searchResultCnt = 0;
		if($('#advancedSearchForm').length) {
			if(!$scope.isAlphabet('firstNm')) submitFlag = false;
			if(!$scope.isAlphabet('middleInitial')) submitFlag = false;
			if(!$scope.isAlphabet('lastNm')) submitFlag = false;
			if(!$scope.validateVin()) submitFlag = false;
			if(!$scope.validatePhone()) submitFlag = false;
			if(!$scope.validateEmail()) submitFlag = false;
			if(!$scope.validateCity()) submitFlag = false;
			if(!$scope.validateState()) submitFlag = false;
			if(!$scope.isNumeric('customerID')) submitFlag = false;
			if(!$scope.isNumeric('zipcode')) submitFlag = false;
			// Begin: Minimum required fields validation
			if(!$scope.isEmpty('customerID') || !$scope.isEmpty('vin') || !$scope.isEmpty('phoneNo') || !$scope.isEmpty('email') || !$scope.isEmpty('organizationNm')) {
				if(!$scope.isEmpty('middleInitial') && $scope.isEmpty('firstNm') && $scope.isEmpty('lastNm')) {
					$('#firstNm, #lastNm').addClass('blue_focus');
					submitFlag = false;
				}
			} else {
				if(!$scope.isEmpty('firstNm') || !$scope.isEmpty('lastNm') || !$scope.isEmpty('middleInitial')) {
					if($scope.isEmpty('firstNm') || $scope.isEmpty('lastNm')) {
						$('#firstNm, #lastNm').addClass('blue_focus');
						submitFlag = false;
					}
				} else if($scope.isEmpty('firstNm') && $scope.isEmpty('lastNm')) {
					if(!$scope.isEmpty('zipcode') && $scope.isEmpty('address')) {
						$('#address, #zipcode').addClass('blue_focus');
							submitFlag = false;
					} else if($scope.isEmpty('address') && (!$scope.isEmpty('city') || !$scope.isEmpty('state'))) {
						$('#address, #city, #state_label').addClass('blue_focus');
							submitFlag = false;
					} else if(!$scope.isEmpty('address') && $scope.isEmpty('zipcode')) {
							if($scope.isEmpty('city') || $scope.isEmpty('state')) {
								$('#address, #city, #state_label').addClass('blue_focus');
								submitFlag = false;
							}
					}
				}
			}
			if($('.blue_focus').length > 0) {
				$rootScope.searchResultData.errorMsg = 'The minimum required search fields are not present. Please enter the minimum required search fields.';
				$('.blue_focus').each(function(){
					$(this).parents("div.mandatory").find('b span.required').show();
				});
			}
			// End: Minimum required fields validation
		}
		if(submitFlag) {
			$('.loader_outer, .loader_inner').show();
			$http({ method: "POST", url: 'getSearchDetails.do', data: data, timeout: canceller.promise }).then(function(response) {
				$scope.defaultInitialization(); // Reset Variables
				$('.loader_outer, .loader_inner').hide();
				$rootScope.searchResultData		= response.data;
				//$rootScope.searchResultData		= {"searchResult":[{"customerId":"122982496","firstname":"RAKULPREET","middleInitial":null,"lastname":"SINGH","address1":null,"address2":null,"street":null,"city":null,"state":null,"nameSuffix":null,"zip":null,"zipShort":null,"countryCode":null,"area":null,"phoneNo":null,"altCountryCode":null,"altArea":null,"altPhone":null,"email":"sam@gmail.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[{"vehicleId":null,"vin":"4TARN81A9RZ184664","modelYear":"1994","make":"TOYOTA","model":"4X2 TRUCK","modelCode":null,"role":"OWNER","expirationDate":null,"purchaseDate":"2017-10-24"}],"vehicleCount":1,"firstVin":"4TARN81A9RZ184664","salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"10/24/2017","profileLastUpdatedSource":"C360 Profile","profileLastUpdatedUser":"136390","customerType":"PERSON"}],"errorCodes":null,"errorMsg":null,"warnings":null,"pkIds":null};
				$rootScope.searchResultData		= {"searchResult":[{"customerId":"62456868","firstname":"JACOB","middleInitial":"I","lastname":"HENRY","address1":"16075 RANCHO DEL LAGO","address2":null,"street":null,"city":"MORENO VALLEY","state":"CA","nameSuffix":null,"zip":"92551-1604","zipShort":"92551","countryCode":null,"area":"951","phoneNo":"9247744","altCountryCode":null,"altArea":"951","altPhone":"6011200","email":"mohenry87@aol.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[{"vehicleId":null,"vin":"JTLZE4FE1CJ028704","modelYear":"2012","make":"SCION","model":"XB","modelCode":null,"role":"OWNER","expirationDate":null,"purchaseDate":"2012-12-18"}],"vehicleCount":1,"firstVin":"JTLZE4FE1CJ028704","salutation":"MR","fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"01/11/2013","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"95725812","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"3066 ISLAND CLUB LN","address2":null,"street":null,"city":"INDIANAPOLIS","state":"IN","nameSuffix":null,"zip":"46214-4161","zipShort":"46214","countryCode":null,"area":null,"phoneNo":null,"altCountryCode":null,"altArea":null,"altPhone":null,"email":"jhenrr52@hotmail.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"01/17/2014","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"35120396","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"115 LINDBERGH ST","address2":null,"street":null,"city":"WINSTON SALEM","state":"NC","nameSuffix":null,"zip":"27104-3621","zipShort":"27104","countryCode":null,"area":"704","phoneNo":"4589109","altCountryCode":null,"altArea":"477","altPhone":"6190000","email":"jacob_henry59@yahoo.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[{"vehicleId":null,"vin":"JTDKN3DU6D5629196","modelYear":"2013","make":"TOYOTA","model":"PRIUS","modelCode":null,"role":"OWNER","expirationDate":null,"purchaseDate":"2013-05-25"}],"vehicleCount":1,"firstVin":"JTDKN3DU6D5629196","salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"11/19/2013","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"54896682","firstname":"JACOB","middleInitial":"N","lastname":"HENRY","address1":"3740 W LYNN DR","address2":null,"street":null,"city":"WASILLA","state":"AK","nameSuffix":null,"zip":"99654-0949","zipShort":"99654","countryCode":null,"area":"907","phoneNo":"3577134","altCountryCode":null,"altArea":"907","altPhone":"5617458","email":"jakehenry49@gmail.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[{"vehicleId":null,"vin":"5TFHY5F19CX231449","modelYear":"2012","make":"TOYOTA","model":"TUNDRA 4X4","modelCode":null,"role":"DRIVER","expirationDate":null,"purchaseDate":"2013-04-28"}],"vehicleCount":1,"firstVin":"5TFHY5F19CX231449","salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"12/18/2013","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"91769991","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"2953 CENTRAL DR APT 207","address2":null,"street":null,"city":"CASPER","state":"WY","nameSuffix":null,"zip":"82604-3079","zipShort":"82604","countryCode":null,"area":"307","phoneNo":"2779673","altCountryCode":null,"altArea":null,"altPhone":null,"email":"jakehenry17@gmail.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"11/17/2013","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"6323333","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"20728 HIGHLAND HALL DR","address2":null,"street":null,"city":"WASHINGTON","state":"DC","nameSuffix":null,"zip":"20088","zipShort":"20088","countryCode":null,"area":null,"phoneNo":null,"altCountryCode":null,"altArea":null,"altPhone":null,"email":null,"socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":"MR","fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"03/25/2007","profileLastUpdatedSource":"INITIAL LOAD","profileLastUpdatedUser":null,"customerType":"PERSON"},{"customerId":"96371865","firstname":"JACOB","middleInitial":"C","lastname":"HENRY","address1":"12007 N LAMAR BLVD APT 521","address2":null,"street":null,"city":"AUSTIN","state":"TX","nameSuffix":null,"zip":"78753-1713","zipShort":"78753","countryCode":null,"area":"361","phoneNo":"9604944","altCountryCode":null,"altArea":null,"altPhone":null,"email":"henryjac@gmail.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[{"vehicleId":null,"vin":"5TFRM5F19CX044762","modelYear":"2012","make":"TOYOTA","model":"TUNDRA 4X2","modelCode":null,"role":"OWNER","expirationDate":null,"purchaseDate":"2014-01-09"}],"vehicleCount":1,"firstVin":"5TFRM5F19CX044762","salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"01/17/2014","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"105338213","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"38857 2ND ST E","address2":null,"street":null,"city":"PALMDALE","state":"CA","nameSuffix":null,"zip":"93550-3201","zipShort":"93550","countryCode":null,"area":null,"phoneNo":null,"altCountryCode":null,"altArea":null,"altPhone":null,"email":"jacobhandy55@yahoo.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"02/01/2015","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"21393752","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"42 W 200 S","address2":null,"street":null,"city":"EPHRAIM","state":"UT","nameSuffix":null,"zip":"84627-1343","zipShort":"84627","countryCode":null,"area":"435","phoneNo":"2010669","altCountryCode":null,"altArea":null,"altPhone":null,"email":"jacob.henry@ssanpete.org","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[{"vehicleId":null,"vin":"JTEBU14RX58034706","modelYear":"2005","make":"TOYOTA","model":"4RUNNER","modelCode":null,"role":"OWNER","expirationDate":null,"purchaseDate":"2005-01-31"}],"vehicleCount":1,"firstVin":"JTEBU14RX58034706","salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"04/18/2013","profileLastUpdatedSource":"EMD","profileLastUpdatedUser":"HARTE HANKS","customerType":"PERSON"},{"customerId":"91644936","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"124 HAZEL ST","address2":null,"street":null,"city":"KITTANNING","state":"PA","nameSuffix":null,"zip":"16201-1226","zipShort":"16201","countryCode":null,"area":null,"phoneNo":null,"altCountryCode":null,"altArea":null,"altPhone":null,"email":"biggiehenry@alltel.net","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"11/17/2013","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"92929710","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"938 GLASTONBURY CIR APT B","address2":null,"street":null,"city":"RIDGELAND","state":"MS","nameSuffix":null,"zip":"39157-1211","zipShort":"39157","countryCode":null,"area":null,"phoneNo":null,"altCountryCode":null,"altArea":null,"altPhone":null,"email":"rhstitan36@yahoo.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"12/20/2013","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"97798437","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":null,"address2":null,"street":null,"city":null,"state":null,"nameSuffix":null,"zip":null,"zipShort":null,"countryCode":null,"area":null,"phoneNo":null,"altCountryCode":null,"altArea":null,"altPhone":null,"email":"jrhenry24@yahoo.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"02/17/2014","profileLastUpdatedSource":"MKTG-HARTE HANKS","profileLastUpdatedUser":"EMD 16050","customerType":"PERSON"},{"customerId":"60117449","firstname":"JACOB","middleInitial":"D","lastname":"HENRY","address1":"1506 SW FINDLAY ST","address2":null,"street":null,"city":"SEATTLE","state":"WA","nameSuffix":null,"zip":"98106-1527","zipShort":"98106","countryCode":null,"area":"808","phoneNo":"2773480","altCountryCode":null,"altArea":"907","altPhone":"4875344","email":"jacob.henry808@gmail.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"04/21/2014","profileLastUpdatedSource":"DIRECT RO","profileLastUpdatedUser":"50012","customerType":"PERSON"},{"customerId":"7461787","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"3876 MEADOW BRIDGE RD","address2":null,"street":null,"city":"SALISBURY","state":"MD","nameSuffix":null,"zip":"21804-1351","zipShort":"21804","countryCode":null,"area":"410","phoneNo":"5462914","altCountryCode":null,"altArea":null,"altPhone":null,"email":null,"socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":"MR","fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"03/25/2007","profileLastUpdatedSource":"INITIAL LOAD","profileLastUpdatedUser":null,"customerType":"PERSON"},{"customerId":"13611515","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"PO BOX 5631","address2":null,"street":null,"city":"FORT PIERCE","state":"FL","nameSuffix":null,"zip":"34954-5631","zipShort":"34954","countryCode":null,"area":"772","phoneNo":"4662637","altCountryCode":null,"altArea":null,"altPhone":null,"email":null,"socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":"MR","fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"03/18/2009","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"42606500","firstname":"JACOB","middleInitial":"S","lastname":"HENRY","address1":"79849 DELIGHT VALLEY SCHOOL RD","address2":null,"street":null,"city":"COTTAGE GROVE","state":"OR","nameSuffix":null,"zip":"97424-9528","zipShort":"97424","countryCode":null,"area":"541","phoneNo":"9426400","altCountryCode":null,"altArea":null,"altPhone":null,"email":"jsh6681@yahoo.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[{"vehicleId":null,"vin":"5TEUX42N96Z212515","modelYear":"2006","make":"TOYOTA","model":"TACOMA","modelCode":null,"role":"DRIVER","expirationDate":null,"purchaseDate":"2009-12-29"}],"vehicleCount":1,"firstVin":"5TEUX42N96Z212515","salutation":"MR","fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"01/17/2010","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - NON CORE","customerType":"PERSON"},{"customerId":"99796841","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":null,"address2":null,"street":null,"city":null,"state":null,"nameSuffix":null,"zip":null,"zipShort":null,"countryCode":null,"area":null,"phoneNo":null,"altCountryCode":null,"altArea":null,"altPhone":null,"email":"jacob.henry74@blinn.buc.edu","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"04/10/2014","profileLastUpdatedSource":"MKTG-HARTE HANKS","profileLastUpdatedUser":"EMD 16050","customerType":"PERSON"},{"customerId":"9183962","firstname":"JACOBS","middleInitial":null,"lastname":"HENRY","address1":"RR 1 BOX 357-1","address2":null,"street":null,"city":"HAMLET","state":"NC","nameSuffix":null,"zip":"28345-9363","zipShort":"28345","countryCode":null,"area":"910","phoneNo":"5826578","altCountryCode":null,"altArea":null,"altPhone":null,"email":null,"socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":"MR","fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"03/25/2007","profileLastUpdatedSource":"INITIAL LOAD","profileLastUpdatedUser":null,"customerType":"PERSON"},{"customerId":"100138886","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"2040 NEUHAUS DR","address2":null,"street":null,"city":"FORT WAYNE","state":"IN","nameSuffix":null,"zip":"46808-1796","zipShort":"46808","countryCode":null,"area":"260","phoneNo":"4317561","altCountryCode":null,"altArea":null,"altPhone":null,"email":"jhenry@upstatemetal.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"05/22/2014","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"95807090","firstname":"JACOB","middleInitial":"T","lastname":"HENRY","address1":"4848 BUCKBOARD WAY","address2":null,"street":null,"city":"RICHMOND","state":"CA","nameSuffix":null,"zip":"94803-3801","zipShort":"94803","countryCode":null,"area":"510","phoneNo":"2967811","altCountryCode":null,"altArea":"925","altPhone":"2967811","email":"jthenry377@gmail.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"11/24/2014","profileLastUpdatedSource":"DIRECT RO","profileLastUpdatedUser":"04189","customerType":"PERSON"},{"customerId":"44630305","firstname":"JACOB","middleInitial":"A","lastname":"HENRY","address1":"9925 BUNKUM RD","address2":null,"street":null,"city":"FAIRVIEW HEIGHTS","state":"IL","nameSuffix":null,"zip":"62208-1230","zipShort":"62208","countryCode":null,"area":"618","phoneNo":"3940540","altCountryCode":null,"altArea":"678","altPhone":"4811465","email":"jacob.henry@me.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[{"vehicleId":null,"vin":"JTDKN3DU1A0021580","modelYear":"2010","make":"TOYOTA","model":"PRIUS","modelCode":null,"role":"OWNER","expirationDate":null,"purchaseDate":"2013-12-31"}],"vehicleCount":1,"firstVin":"JTDKN3DU1A0021580","salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"11/14/2014","profileLastUpdatedSource":"DIRECT RO","profileLastUpdatedUser":"12071","customerType":"PERSON"},{"customerId":"106682724","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":null,"address2":null,"street":null,"city":null,"state":null,"nameSuffix":null,"zip":null,"zipShort":null,"countryCode":null,"area":"618","phoneNo":"3353704","altCountryCode":null,"altArea":null,"altPhone":null,"email":"jacob_692005@hotmail.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"03/29/2015","profileLastUpdatedSource":"EMD","profileLastUpdatedUser":"HARTE HANKS","customerType":"PERSON"},{"customerId":"97511587","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"3819 CLAY LICK ROAD","address2":null,"street":null,"city":"ENGLEWOOD","state":"CO","nameSuffix":null,"zip":"80112","zipShort":"80112","countryCode":null,"area":"720","phoneNo":"8414054","altCountryCode":null,"altArea":null,"altPhone":null,"email":"jacoblhenry@einrot.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"02/19/2014","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"103419101","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"5141 CHARLSTON RD","address2":null,"street":null,"city":"PLEASANT GARDEN","state":"NC","nameSuffix":null,"zip":"27313-9231","zipShort":"27313","countryCode":null,"area":"336","phoneNo":"6745430","altCountryCode":null,"altArea":null,"altPhone":null,"email":"henry0608@gmail.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[{"vehicleId":null,"vin":"2T1BURHE4EC147369","modelYear":"2014","make":"TOYOTA","model":"COROLLA","modelCode":null,"role":"OWNER","expirationDate":null,"purchaseDate":"2014-08-07"}],"vehicleCount":1,"firstVin":"2T1BURHE4EC147369","salutation":"MR","fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"08/26/2014","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"115128305","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"2160 W MULBERRY DR","address2":null,"street":null,"city":"CHANDLER","state":"AZ","nameSuffix":null,"zip":"85286-6774","zipShort":"85286","countryCode":null,"area":"480","phoneNo":"6294678","altCountryCode":null,"altArea":null,"altPhone":null,"email":"jase133@cox.net","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[{"vehicleId":null,"vin":"4T1BF1FK9FU996739","modelYear":"2015","make":"TOYOTA","model":"CAMRY","modelCode":null,"role":"OWNER","expirationDate":null,"purchaseDate":"2015-08-21"},{"vehicleId":null,"vin":"JT2BG28K8X0319588","modelYear":"1999","make":"TOYOTA","model":"CAMRY","modelCode":null,"role":"OWNER","expirationDate":null,"purchaseDate":"1999-03-12"}],"vehicleCount":2,"firstVin":"4T1BF1FK9FU996739","salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"08/28/2015","profileLastUpdatedSource":"SURVEY - PLS","profileLastUpdatedUser":null,"customerType":"PERSON"},{"customerId":"96730805","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"125 E PHELPS ST","address2":null,"street":null,"city":"GROVELAND","state":"FL","nameSuffix":null,"zip":"34736-2247","zipShort":"34736","countryCode":null,"area":null,"phoneNo":null,"altCountryCode":null,"altArea":null,"altPhone":null,"email":"jhenry3590@embarq.com","socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[],"vehicleCount":0,"firstVin":null,"salutation":null,"fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"02/18/2014","profileLastUpdatedSource":"HYGIENE","profileLastUpdatedUser":"EXPERIAN - CORE","customerType":"PERSON"},{"customerId":"30193438","firstname":"JACOB","middleInitial":null,"lastname":"HENRY","address1":"8201 CAMINO MEDIA","address2":null,"street":null,"city":"BAKERSFIELD","state":"CA","nameSuffix":null,"zip":"93311-2002","zipShort":"93311","countryCode":null,"area":"661","phoneNo":"5885526","altCountryCode":null,"altArea":"661","altPhone":"2134792","email":null,"socialMediaHandle":null,"organizationname":null,"vehicleLiteTOList":[{"vehicleId":null,"vin":"JTEZT14R930007154","modelYear":"2003","make":"TOYOTA","model":"4RUNNER SR5","modelCode":null,"role":"OWNER","expirationDate":null,"purchaseDate":"2005-01-14"}],"vehicleCount":1,"firstVin":"JTEZT14R930007154","salutation":"MR","fax":null,"make":null,"model":null,"modelYear":null,"flag":null,"distributor":"US","profileLastUpdated":"03/25/2007","profileLastUpdatedSource":"INITIAL LOAD","profileLastUpdatedUser":null,"customerType":"PERSON"}],"errorCodes":null,"errorMsg":null,"warnings":null,"pkIds":null};
				console.log($rootScope.searchResultData);
				if($rootScope.searchResultData.searchResult != null) {
					$scope.advanceSearchResultFlag	= true;
					$scope.searchResultCnt	= $rootScope.searchResultData.searchResult.length;
					$scope.searchPagination('');
					setTimeout(function() { setSearchContainer(); }, 500);
					if($rootScope.searchResultData.warnings != null && $rootScope.searchResultData.warnings.length && $rootScope.searchResultData.warnings[0].indexOf('A VIN only search was completed since no results were found which matched the submitted search criteria') !== -1) {
						$scope.warningMessagePopup();
					}
				} else {
					$scope.searchResultCnt	= 0;
					$scope.advanceSearchFormFlag	= (mode == 'cc')? false:true;
					$scope.advanceSearchResultFlag	= (mode == 'cc')? true:false;
					if($rootScope.searchResultData.warnings != null && $rootScope.searchResultData.warnings.length && $rootScope.searchResultData.warnings.indexOf('The incoming VIN is valid.') !== -1) {
						$rootScope.vinView	= true;
						$scope.c360status1	= true;
						$scope.c360status2	= false;
						$scope.advanceSearchFormFlag	= false;
						$scope.advanceSearchResultFlag	= false;
						$rootScope.searchResultData.errorMsg = '';
						console.log($rootScope.searchResultData);
						$timeout(function(){
							$rootScope.$broadcast('VehicleClicked', data.vin, '', '', '');
							var tempData = {"vin":data.vin, "make":"", "model":"", "year": ""};
							$scope.addToRecentSearchHistory('Vin', data.vin, tempData);
						}, 1000);
						$scope.setTab(1); // to set Vehicle Tab
					} else if($rootScope.searchResultData.warnings != null && $rootScope.searchResultData.warnings.length >0) {
						$rootScope.searchResultData.errorMsg = $rootScope.searchResultData.warnings[0];
					} else if($rootScope.searchResultData.errorCodes == null && $rootScope.searchResultData.warnings == null && $rootScope.searchResultData.errorMsg == null) {
						$rootScope.searchResultData.errorMsg = "An unexpected error occurred. Please try again.";
					}
				}
			}, function (response) {
				$('.loader_outer, .loader_inner').hide();
			});
		}
	};
	// Dealer Advance Search Submit Action
	$scope.submitAdvanceDealerSearchForm = function() {
		$('#errorMsg, .required').hide();
		$('#focussearch').val('');
		canceller = $q.defer();
		$scope.startIndex		= 0;
		$scope.endIndex			= 10;
		$scope.searchResultCnt	= 0;
		$scope.searchFieldCnt	= 0;
		$rootScope.nocustomer	= false;
		$scope.hasData 			= false;
		$rootScope.searchResultData =  {};
		var submitFlag			= true;
		$scope.postData	= angular.copy($scope.dealerFormData);
		angular.forEach($scope.dealerFormData, function(value, key) {
			if(value != '') {
				$scope.hasData = true;
				if(key != 'city') $scope.searchFieldCnt++;
			}
		});
		if($scope.hasData == false || $scope.searchFieldCnt > 1) {
			$rootScope.searchResultData.errorMsg = 'Please Enter the Dealer Name Or Dealer Code Or City & State Or State Or Zipcode';
			submitFlag = false;
		} else if($scope.dealerFormData.city != '' && $scope.dealerFormData.state == '') {
			$rootScope.searchResultData.errorMsg = 'Please select state for the City';
			submitFlag = false;
		} else {
			var brand	= (angular.element("input[name=brand]:checked").val() == 1)? 'Toyota': 'Lexus';
			if($scope.dealerFormData.dealerCode != '') {
				if(!$scope.isNumeric('dealer_code')) {
					$rootScope.searchResultData.errorMsg = 'Invalid Characters entered in Dealer Code';
					submitFlag = false;
				} else {
					// Redirect
					$scope.redirect($scope.dealerFormData.dealerCode, brand, 'Dealer');
					return true;
				}
			}
			else if($scope.dealerFormData.dealerName != '') {
				if(!$scope.isAlphaNumeric('dealer_name')) {
					$rootScope.searchResultData.errorMsg = 'Invalid Characters entered in Dealer Name';
					submitFlag = false;
				}
				var queryString = 'param=dealerName&brand='+brand+'&paramValue='+$scope.dealerFormData.dealerName;
			} else if($scope.dealerFormData.city != '' && $scope.dealerFormData.state != '') {
				if(!$scope.isAlphaNumeric('city')) {
					$rootScope.searchResultData.errorMsg = 'Invalid Characters entered in City';
					submitFlag = false;
				}
				var queryString = 'param=cityState&brand='+brand+'&paramValue='+$scope.dealerFormData.city+'&paramSecondValue='+$scope.dealerFormData.state;
			} else if($scope.dealerFormData.state != '') {
				var queryString = 'param=state&brand='+brand+'&paramValue='+$scope.dealerFormData.state;
			} else if($scope.dealerFormData.zipcode != '') {
				if(!$scope.isNumeric('zipcode')) {
					$rootScope.searchResultData.errorMsg = 'Please enter a valid Zipcode';
					submitFlag = false;
				}
				var queryString = 'param=zipcode&brand='+brand+'&paramValue='+$scope.dealerFormData.zipcode;
			} else if($scope.dealerFormData.region != '' || $scope.dealerFormData.areaOffice != '') {
				if(brand == 'Toyota') {
					var queryString = 'param=region&brand='+brand+'&paramValue='+$scope.dealerFormData.region;
				} else {
					var queryString = 'param=region&brand='+brand+'&paramValue='+$scope.dealerFormData.areaOffice;
				}
			}
		}
		if(submitFlag) {
			$('.loader_outer, .loader_inner').show();
			$http.get('getDelearResults.do?'+queryString).then(function(response){
				$('.loader_outer, .loader_inner').hide();
				$scope.defaultInitialization(); // Reset Variables
				$scope.dealerSolrSearch 		= false;
				$rootScope.searchResultData		= response.data;
				$scope.searchResultCnt			= $rootScope.searchResultData.length;
				if($scope.searchResultCnt == 0) {
					$scope.dealerSearchResultFlag	= false;
					$scope.advanceSearchFormFlag	= true;
					$rootScope.searchResultData.errorMsg = 'No Dealer(s) Found.';
				} else {
					$scope.dealerSearchResultFlag	= true;
					$scope.advanceSearchFormFlag	= false;
					$rootScope.searchResultData.errorMsg = '';
				}
				setTimeout(function() {
					$("#searchResults").animate({"scrollTop": "0px"}, 500);
					setSearchContainer();
				}, 500);
			});
		}
	}
	// Re-run search
	$scope.revisedSearch = function(key) {
		$scope.formData = $scope.postData;
		$scope.formData[key] = '';
		$scope.submitAdvanceSearchForm('as');
	}
	// Advance search - Get Customer & VIN Info
	$scope.getCustomerAndVehicleInfo = function(custObj,vehicle) {
		var temp_object = {};
		temp_object.customer_id	= (custObj.customerId != undefined)? custObj.customerId : '';
		temp_object.first_nm	= (custObj.firstname != undefined)? custObj.firstname : '';
		temp_object.last_nm		= (custObj.lastname != undefined)? custObj.lastname : '';
		temp_object.vin			= (vehicle != '' && vehicle != undefined)? vehicle.vin : '';
		temp_object.year		= (vehicle != '' && vehicle != undefined)? vehicle.modelYear : '';
		temp_object.model		= (vehicle != '' && vehicle != undefined)? vehicle.model : '';
		temp_object.make		= (vehicle != '' && vehicle != undefined)? vehicle.make : '';
		temp_object.pr_eml_email_address	= '';
		// assign value to local storage
		$localStorage.customerOrDealerData	= temp_object;
		// Get Redirect URL
		var redirectUrl = $scope.getRedirectUrl(temp_object);
		// Redirect
		$timeout(function(){ window.location = "profile.do?"+redirectUrl; }, 300);
	}
	$scope.addToMergeList = function(custObj) {
		console.log(custObj);
		var tempData = { "customerId": custObj.customerId, "salutation": custObj.salutation, "customerFirstName": custObj.firstname, "customerMiddleName": custObj.middleInitial, "customerLastName": custObj.lastname, "nameSuffix": custObj.nameSuffix, "organizationName": custObj.organizationname, "distributor": custObj.distributor, "profileLastUpdated": custObj.profileLastUpdated, "profileLastUpdatedSource": custObj.profileLastUpdatedSource, "profileLastUpdatedUser": custObj.profileLastUpdatedUser };
		// Customer Type
		tempData.customerType = (custObj.organizationname)? "BUSINESS":"PERSON";
		// Address
		tempData.address = { "addressLine1": custObj.address1, "addressLine2": custObj.address2, "city": custObj.city, "state": custObj.state, "zipCode": custObj.zip };
		// Email
		tempData.email = [{ "emailAddress": custObj.email}];
		// Phone
		tempData.phone = [{ "phoneNumber": (custObj.area != null)? (custObj.area+custObj.phoneNo) : custObj.phoneNo}, { "phoneNumber": null}];
		// Vehicle
		tempData.vehicles = [];
		angular.forEach(custObj.vehicleLiteTOList, function(value, key) {
			tempData.vehicles.push({'modelYear': value.modelYear, 'brand': value.make, 'model': value.model, 'vin': value.vin, 'purchaseDate': value.vin});
		});
		console.log(tempData);
		$rootScope.$broadcast('AddToMergeList', tempData);
	}
	// Ends
	/********************** End : Advance Search (Customer & Dealer) Module ******************/
	
	/***************************** Begin : Customer Connection *******************************/
	$scope.customerConnectionVinSearch = function (value) {
		$http.get('getsuggestedcustomers.do?custQuery='+encodeURIComponent(value)+'&isVin=No').then(function(result) {
			if(result.data.response.docs.length > 0) {
				$rootScope.nocustomer = false;
				var data = result.data.response.docs[0];
				$scope.onSelect(data);
			} else {
				$rootScope.nocustomer = true;
			}
		});
	}
	$scope.customerConnection = function() {
		if(AuthenticationService.isCookieExist("cookie_disclaimer")) {
			// Get parameters
			var cc_custId	= getParameterByName('customerId');
			var cc_vin 		= getParameterByName('vin');
			if(cc_custId == null && cc_vin == null) return false;
			// Load Customer Profile
			if(cc_custId != null && cc_custId != '' && SecurityService.checkAccess('admin_view')) {
				$scope.defaultInitialization(); // Reset Variables
				$scope.isCustomerConnectionSearch = true;
				$scope.c360status1	= true;
				$scope.c360status2	= false;
				$timeout(function(){
					$rootScope.$broadcast('customerid', cc_custId);
					var getCustomerDetailsOnLoad = setInterval(function(){
						if($rootScope.Newcustomer != undefined) {
							$scope.setVehicleTab();
							clearInterval(getCustomerDetailsOnLoad);
						}
					}, 100);
				}, 500);
			} else if(cc_vin != null && cc_vin != '') {
				$scope.defaultInitialization(); // Reset Variables
				$scope.isCustomerConnectionSearch = true;
				if(SecurityService.checkAccess('non_admin')) { // if C360_NON_CUSTOMER_ADMIN_VIEWER
					$scope.customerConnectionVinSearch(cc_vin);
				} else {
					$scope.initializeFormData();
					$scope.formData.vin = cc_vin;
					$timeout(function() { $scope.submitAdvanceSearchForm('cc'); },500);
				}
				
			}
		}
	}
	/***************************** End : Customer Connection *******************************/
	
	/*************************** Begin: Recent search History *****************************/
	$rootScope.recentSearchViewFlag = false;
	$rootScope.recentSearchHistory	= [];
	$rootScope.recentlySearchedIds	= [];
	$scope.addToRecentSearchHistory = function(searchType, identifier, resultObj) {		// identifier - customerId or Vin
		console.log("---------addToRecentSearchHistory---------------");
		var tempVinData			= '';
		var tempCustomerData	= '';
		if(AuthenticationService.isCookieExist("cookie_userId")) {
			if($localStorage.recentlySearchedIds != undefined) {
				$rootScope.recentlySearchedIds = $localStorage.recentlySearchedIds;
				$rootScope.recentSearchHistory = $localStorage.recentSearchHistory;
			}
			// Get Searched Time
			var dateObj		= new Date();
			var time		= (("0" + dateObj.getHours()).slice(-2))+":"+(("0" + dateObj.getMinutes()).slice(-2));
			var timestamp	= dateObj.getTime();
			// Check
			var index 		= $rootScope.recentlySearchedIds.indexOf(identifier);
			if(index < 0) { // New Search
				if(searchType == 'Customer') {
					var tempCustomerData	= { "customerId":resultObj.customerId, "salutation":resultObj.salutation, "customerFirstName":resultObj.customerFirstName, "customerMiddleName":resultObj.customerMiddleName, "customerLastName":resultObj.customerLastName, "nameSuffix":resultObj.nameSuffix, "organizationName":resultObj.organizationName, "customerType":resultObj.customerType, "distributor":resultObj.distributor, "address":resultObj.address, "email":resultObj.email, "phone":resultObj.phone };
				} else {
					var tempVinData	= {"vin":resultObj.vin, "make":resultObj.make, "model":resultObj.model, "year": (resultObj.model_year != undefined)? resultObj.model_year:resultObj.year};
				}
				var tempHistory	= {"searchType":searchType, "customerHistory":tempCustomerData, "vinHistory": tempVinData, "time":time, "timestamp":timestamp};
				// assign to scope variable
				$rootScope.recentlySearchedIds.push(identifier);
				$rootScope.recentSearchHistory.push(tempHistory);
				// store value in localStorage
				$localStorage.recentlySearchedIds	= $rootScope.recentlySearchedIds;
				$localStorage.recentSearchHistory	= $rootScope.recentSearchHistory;
			} else {
				// Already Searched Customer or Vin - So, update recently searched time
				$localStorage.recentSearchHistory[index].time		=	time;
				$localStorage.recentSearchHistory[index].timestamp	=	timestamp;
			}
		}
	}
	$scope.getRecentSearchData = function() {
		$('.recent-search-container .ngscroll-container').css('marginTop','0');
		$rootScope.recentSearchIndex	= 10;
		$rootScope.recentSearchViewFlag = !$rootScope.recentSearchViewFlag;
		if(AuthenticationService.isCookieExist("cookie_userId")) {
			if($localStorage.recentSearchHistory != undefined) {
				// Get details from local storage and assign to scope variable
				$rootScope.recentlySearchedIds 	= angular.copy($localStorage.recentlySearchedIds).reverse();
				$rootScope.recentSearchHistory 	= angular.copy($localStorage.recentSearchHistory).reverse();
			}
		} else {
			$scope.clearRecentSearchHistory();
		}
		setRecentSearchContainer();
	}
	$scope.clearRecentSearchHistory = function() {
		if($localStorage.recentlySearchedIds != undefined) {
			delete $localStorage.recentlySearchedIds;
			delete $localStorage.recentSearchHistory;
		}
		$rootScope.recentlySearchedIds = [];
		$rootScope.recentSearchHistory = [];
	}
	$scope.loadMoreRecentHistory = function() {
		$timeout(function() {
			$rootScope.recentSearchIndex = $rootScope.recentSearchIndex + 10;
		}, 100);
	}
	/**************************** End: Recent search History ******************************/
	
	$scope.searchPagination = function(nav) {
		if(nav == 'Next') {
			$scope.startIndex	= $scope.startIndex + 10;
			$scope.endIndex		= $scope.endIndex + 10;
			$scope.endIndex		= ($scope.endIndex > $scope.searchResultCnt)? $scope.searchResultCnt : $scope.endIndex;
		} else if(nav == 'Prev') {
			$scope.startIndex	= $scope.startIndex - 10;
			if($scope.endIndex == $scope.searchResultCnt && ($scope.searchResultCnt%10 != 0)) {
				$scope.endIndex = $scope.endIndex - ($scope.searchResultCnt%10);
			} else {
				$scope.endIndex = $scope.endIndex - 10;
			}
		} else {
			$scope.endIndex = ($scope.endIndex > $scope.searchResultCnt)? $scope.searchResultCnt : $scope.endIndex;
		}	
		if(nav != '') {
			/*var scrollPos	= $("#searchResults .header").outerHeight(true);*/
			$("#searchResults").animate({"scrollTop": "0px"}, 500);
		}
	}
	$scope.warningMessagePopup = function(){
		PermissionPopup({
			id: 'disclaimerDialog',
			templateUrl:'views/warningMessagePopup.html',
			title: '',
			backdrop: true
		});
	}
	$scope.isEmpty = function(id) {
		var element = angular.element('#'+id);
		var value	= $.trim(element.val());
		return (angular.isUndefined(value) || value == null || value == '');
	}
	$scope.isAlphaNumeric = function(id){
		var regEx = /^[aA-zZ0-9\s]+$/i;
		var element = angular.element('#'+id);
		var value	= $.trim(element.val());
		if (value != '' && !regEx.test(value)) return false;
		return true;
	}
	$scope.isAlphabet = function(id) {
		var element = angular.element('#'+id);
		var value	= $.trim(element.val());
		var regEx	= /^[aA-zZ\s]+$/i;
		if (value != '' && !regEx.test(value)) {
			if(id == 'middleInitial') {
				element.next('span').text('Invalid Character').css('opacity', 1); return false;
			} else {
				element.next('span').text('Invalid Characters').css('opacity', 1); return false;
			}
		} else {
			if(id == 'middleInitial') {
				element.next('span').text('').css('opacity', 0); return true;
			} else {
				element.next('span').css('opacity', 0); return true;
			}
		}
	}
	$scope.isNumeric = function(id) {
		var element = angular.element('#'+id);
		var value	= $.trim(element.val());
		var regEx	= /^[0-9]+$/i;
		if (value != '' && !regEx.test(value)) {
			element.next('span').text('Invalid Characters').css('opacity', 1); return false;
		} else {
			element.next('span').css('opacity', 0); return true;
		}
	}
	$scope.validateVin = function() {
		var element = angular.element('#vin');
		var value	= $.trim(element.val());
		var regEx	= /^[a-z0-9]+$/i;
		if (value != '' && !regEx.test(value)) {
			element.next('span').text('Invalid Characters').css('opacity', 1); return false;
		} else if(value != '' && value.length < 17) {
			element.next('span').text('VIN must be 17 characters').css('opacity', 1); return false;
		} else {
			element.next('span').css('opacity', 0); return true;
		}
	}
	$scope.validateEmail = function() {
		var element		= angular.element('#email');
		var emailStr	= $.trim(element.val());
		var regEx		= /^.+@.+\..{2,3}$/;
		if (emailStr != '' && !regEx.test(emailStr)) {
			element.next('span').text('Invalid Email').css('opacity', 1); return false;
		} else {
			element.next('span').css('opacity', 0); return true;
		}
	}
	$scope.validatePhone = function() {
		var regEx	= /^[0-9\s\)\(\-]+$/i;
		var element = angular.element('#phoneNo');
		var value	= $.trim(element.val());
		if (value != '' && !regEx.test(value)) {
			element.next('span').text('Phone number contains invalid characters.').css('opacity', 1);
		} else if(value != '' && value.replace(/[^0-9]/gi, '').length != 10) {
			element.next('span').text('Phone must be 10 characters').css('opacity', 1);
			return false;
		} else {
			element.next('span').css('opacity', 0); return true;
		}
	}
	$scope.validateCity = function() {
		if($scope.isAlphabet('city')) {
			var element = angular.element('#city');
			var value	= $.trim(element.val());
			if(value != '' && value.length < 2) {
				element.next('span').text('City must be atleast 2 characters').css('opacity', 1); return false;
			} else {
				element.next('span').css('opacity', 0); return true;
			}
		} else {
			return false;
		}
	}
	$scope.validateState = function() {
		if($scope.isAlphabet('state')) {
			var element = angular.element('#state');
			var value	= $.trim(element.val());
			if(value != '' && value.length < 2) {
				element.next('span').text('State must be 2 characters').css('opacity', 1); return false;
			} else {
				element.next('span').css('opacity', 0); return true;
			}
		} else {
			return false;
		}
	}
	$scope.setDropdownVal = function(event) {
		$scope.dropdownFlag = !$scope.dropdownFlag;
		if(event.target.tagName == 'LI' || event.target.tagName == 'li') {
			var Label		= $(event.target).text();
			var selectedval	= $(event.target).data('value');
			$('#selectedVal').text(Label);
			$scope.adsort	=	selectedval;
		}
	}
	$scope.setCustomDropdownValue = function(event, id, LabelText) {
		if(event.target.tagName == 'LI' || event.target.tagName == 'li') {
			if(LabelText == 'value'){
				var Label	= $(event.target).data('value');
				Label = (Label == '')? 'Select':Label;
			} else {
				var Label	= $.trim($(event.target).text());
			}
			var selectedval	= $(event.target).data('value');
			$('#'+id).val(selectedval).focus();
			$('#'+id+'_label').val(Label);
			$timeout(function(){
				$('#'+id).blur();
				$('#'+id+'_label').focus();
			},50);
			$(event.target).parents('div.dropdown-wrapper').find("li.selected").removeClass('selected');
			$(event.target).addClass('selected');
		}
		if($(event.target).parents('div.dropdown-wrapper').find('.dropdown-list').is(':visible')) {
			$(event.target).parents('div.dropdown-wrapper').find('.dropdown-list').hide();
		} else {
			$('.dropdown-list').hide();
			$(event.target).parents('div.dropdown-wrapper').find('.dropdown-list').toggle();
		}
	}
	$scope.preventKeyPress = function(event) {
		var keyCode	= (event.which?event.which:(event.keyCode?event.keyCode:0));
		if(keyCode == 9) {
			$('.dropdown-list').hide();
			return true;
		} else {
			event.preventDefault();
			return false;
		}
	}
	// End : Advance Search Code
	$rootScope.customAlertPopup = function(message) {
		$rootScope.isConfirmed = false;
		return PermissionPopup({
			id: 'alertDialog',
			templateUrl:'views/alertPopup.html',
			title: message,
			backdrop: true,
			backdropCancel : false,
			modalClass: "popup_container",
			css: {width: "470px" },
			success: {
				label: 'Success',
				fn: function() {
					$rootScope.isConfirmed = true;
				}
			}
		});
	}
}]);

TMSApp.controller('customerTabsCtrl', ['$scope', '$rootScope','$templateCache','DealerviewPopup','AdditionalvehiclPopup','$timeout','$window', function ($scope, $rootScope,$templateCache,DealerviewPopup,AdditionalvehiclPopup,$timeout,$window) {
	//$templateCache.remove('views/tab1-container2.html')
	$scope.tab = 1;
	$scope.$on('customerid', function(events, args){
		$scope.tab = 1;
	})

	$scope.setTab = function (tabId) {
		$scope.tab = tabId;
	};

	$scope.isSet = function (tabId) {
		return $scope.tab === tabId;
	};

	$scope.isSetValue = function () {
		if($scope.tab == 'Surveys')
			return true; 
		else 
			return false;
	};
	$rootScope.ViewmoreSurvey = function(){
		$timeout(function(){
			$rootScope.$broadcast('SurveyDetails',1); // 6 - Survey Tab
		},300);
	}	
	$rootScope.ViewmoreMentions = function(){
		$timeout(function(){
			$rootScope.$broadcast('SurveyDetails',2); // 6 - Survey Tab
		},300);
	}
	$scope.$on('SurveyDetails', function(events, tabId){
		$timeout(function(){ $scope.setTab(tabId); },300);
	});
	$scope.$on('showDetailsMenuTab', function(events, tabId){
		$timeout(function(){ $scope.setTab(tabId); },100);
	});
}]); 

TMSApp.controller('customerScoringCtrl', function($scope) {

	$scope.opentheChart8= function() {
		$scope.openChart8 = $scope.openChart8==true ? false:true; 
	};
	
	$scope.roundProgressData = {
			label: 75,
			percentage: 100
	}
	
	$scope.roundProgressData1 = {
			label: 60,
			percentage: 100
	}
	
	$scope.roundProgressData2 = {
			label: 50,
			percentage: 100
	}
	
	$scope.roundProgressData3 = {
			label: 22,
			percentage: 100
	}
	
	$scope.roundProgressData4 = {
			label: 89,
			percentage: 100
	}
	
	$scope.roundProgressData5 = {
			label: 30,
			percentage: 100
	}
	
	$scope.roundProgressData6 = {
			label: 63,
			percentage: 100
	}

	// Here I synchronize the value of label and percentage in order to have a nice demo
	$scope.$watch('roundProgressData', function (newValue, oldValue) {
		newValue.percentage = newValue.label / 100;
	}, true);
	
	$scope.$watch('roundProgressData1', function (newValue, oldValue) {
		newValue.percentage = newValue.label / 100;
	}, true);
	
	$scope.$watch('roundProgressData2', function (newValue, oldValue) {
		newValue.percentage = newValue.label / 100;
	}, true);
	
	$scope.$watch('roundProgressData3', function (newValue, oldValue) {
		newValue.percentage = newValue.label / 100;
	}, true);
	
	$scope.$watch('roundProgressData4', function (newValue, oldValue) {
		newValue.percentage = newValue.label / 100;
	}, true);
	
	$scope.$watch('roundProgressData5', function (newValue, oldValue) {
		newValue.percentage = newValue.label / 100;
	}, true);
	
	$scope.$watch('roundProgressData6', function (newValue, oldValue) {
		newValue.percentage = newValue.label / 100;
	}, true);
});

TMSApp.controller('HomegrpahCtrl', ['$scope', '$rootScope','$templateCache','NshDataService','NshAmountDataService','EmdDataService','SurveyCountDataService','CustomerDataService','$filter','CaseDataService','GoodwillDataService', 
                                    function ($scope, $rootScope,$templateCache,NshDataService,NshAmountData,EmdDataService,SurveyCountDataService,CustomerDataService,$filter,CaseDataService,GoodwillDataService) {


	$scope.opentheChart1= function() {
		$scope.openChart1 = $scope.openChart1==true ? false:true; 
	}; 
	$scope.opentheChart2= function() {
		$scope.openChart2 = $scope.openChart2==true ? false:true; 
	};
	$scope.opentheChart3= function() {
		$scope.openChart3 = $scope.openChart3==true ? false:true; 
	};
	$scope.opentheChart4= function() {
		$scope.openChart4 = $scope.openChart4==true ? false:true; 
	};
	$scope.opentheChart5= function() {
		$scope.openChart5 = $scope.openChart5==true ? false:true; 
	};
	$scope.opentheChart6= function() {
		$scope.openChart6 = $scope.openChart6==true ? false:true; 
	};
	$scope.opentheChart7= function() {
		$scope.openChart7 = $scope.openChart7==true ? false:true; 
	};
	$scope.opentheChart8= function() {
		$scope.openChart8 = $scope.openChart8==true ? false:true; 
	};

	//Customer Data Chart
	$scope.CustomerData = function () {

		/*	CustomerDataService.getCustomerData().then(function(data){
			var response_data = data;
			$scope.TotalCustCount = response_data.stats.stats_fields.totalcustomercount.sum;
			$scope.LexusCustCount = response_data.stats.stats_fields.totalcustomercount.facets.make.LEXUS.sum;
			$scope.ToyotaCustCount = response_data.stats.stats_fields.totalcustomercount.facets.make.TOYOTA.sum;
			$scope.ScionCustCount = response_data.stats.stats_fields.totalcustomercount.facets.make.SCION.sum;

			$scope.UniqueCust =	 "64065046"; 
			$scope.CustwithVehicle	= "46907642"; 
			$scope.withoutVehicle	= "17157404"; 


		});*/
		$scope.UniqueCust =	 "64065046"; 
		$scope.CustwithVehicle	= "46907642"; 
		$scope.withoutVehicle	= "17157404"; 

		/*	var custCount = [
		                   {
		                	   values: [
		                	            { 
		                	            	"label" : "Toyota" ,
		                	            	"value" : $scope.ToyotaCustCount
		                	            } , 
		                	            { 
		                	            	"label" : "Lexus" , 
		                	            	"value" : $scope.LexusCustCount
		                	            } , 
		                	            { 
		                	            	"label" : "Scion" , 
		                	            	"value" : $scope.ScionCustCount
		                	            } 
		                	            ]
		                   }
		                   ]*/

		var custCount = [
		                 {
		                	 values: [
		                	          { 
		                	        	  "label" : "Only Toyota" ,
		                	        	  "value" :  38180312
		                	          } , 
		                	          { 
		                	        	  "label" : "Only Lexus" , 
		                	        	  "value" :  5109104
		                	          } , 
		                	          { 
		                	        	  "label" : "Only Scion" , 
		                	        	  "value" :  1012837
		                	          },
		                	          { 
		                	        	  "label" : "Toyota & Lexus" , 
		                	        	  "value" :   1591262 
		                	          },
		                	          { 
		                	        	  "label" : "Toyota & Scion" , 
		                	        	  "value" :   354389
		                	          },
		                	          { 
		                	        	  "label" : "Lexus & Scion" , 
		                	        	  "value" :   20284
		                	          },
		                	          { 
		                	        	  "label" : "Toyo, Lex & Sci" , 
		                	        	  "value" :    21717
		                	          }

		                	          ]
		                 }
		                 ]

		d3.select('#test5').selectAll('*').remove();
		d3.select('#test5').append('svg');
		nv.addGraph({
			generate: function() {
				var chart = nv.models.discreteBarChart()
				.x(function(d) { return d.label })
				.y(function(d) { return d.value })
				//.staggerLabels(true)
				//.tooltips(false)
				.showValues(false)
				var formatValue = d3.format(".2s")
				chart.yAxis.tickFormat(function(d) { return formatValue(d); });
				chart.rotateLabels(-45);
				var svg = d3.select('#test5 svg')
				.datum(custCount);
				svg.transition().duration(0).call(chart);
				return chart;
			},

		});
	}

	//Repair order Chart
	$scope.RepairOrder = function () {

		NshDataService.getNshData().then(function(data){
			var response_data = data;
			$scope.TotalRepairCount = response_data.stats.stats_fields.no_ro.sum;
			$scope.LexusCount = response_data.stats.stats_fields.no_ro.facets.brand.Lexus.sum;
			$scope.ToyotaCount = response_data.stats.stats_fields.no_ro.facets.brand.Toyota.sum;
		});


		var repairCount = [
		                   {
		                	   values: [
		                	            { 
		                	            	"label" : "Toyota" ,
		                	            	"value" : $scope.ToyotaCount
		                	            } , 
		                	            { 
		                	            	"label" : "Lexus" , 
		                	            	"value" : $scope.LexusCount
		                	            } 
		                	            ]
		                   }
		                   ]

		d3.select('#test1').selectAll('*').remove();
		d3.select('#test1').append('svg');
		nv.addGraph({
			generate: function() {
				var chart = nv.models.discreteBarChart()
				.x(function(d) { return d.label })
				.y(function(d) { return d.value })
				.color(['#da82ff', '#d8afff'])
				//.staggerLabels(true)
				//.tooltips(false)
				//.showValues(true)
				var formatValue = d3.format(".2s")
				chart.yAxis.tickFormat(function(d) { return formatValue(d); });
				//chart.xAxis.tickFormat(function(d) { return formatValue(d).replace('M', 'million'); });
				var svg = d3.select('#test1 svg')
				.datum(repairCount);
				svg.transition().duration(0).call(chart);
				return chart;
			},

		});
	}
	//NSH Data chart
	$scope.NshAmount = function () {


		NshAmountData.getNshAmountData().then(function(data){
			console.log(data);
			$scope.TotalPaidAmount = data.stats.stats_fields.total_amount.sum;
			$scope.LexusCustomerPay = data.stats.stats_fields.cp_amount.facets.brand.Lexus.sum;
			$scope.ToyotaCustomerPay = data.stats.stats_fields.cp_amount.facets.brand.Toyota.sum;
			$scope.LexusWarrantyPay = data.stats.stats_fields.wp_amount.facets.brand.Lexus.sum;
			$scope.ToyotaWarrantyPay = data.stats.stats_fields.wp_amount.facets.brand.Toyota.sum;
			console.log($scope.TotalPaidAmount);

		});

		var NshTotalAmount = [{
			"key": "Customer Pay",
			"values": [{
				"x": "Toyota",

				"y": $scope.LexusCustomerPay,

				"color": "#ffb15f"
			}, {
				"x": "Lexus",

				"y": $scope.ToyotaCustomerPay,

				"color": "#ffb15f"
			}]
		}, {
			"key": "Warranty Pay",
			"values": [{
				"x": "Toyota",

				"y": $scope.LexusWarrantyPay,

				"color": "#ffd8af"
			}, {
				"x": "Lexus",

				"y": $scope.ToyotaWarrantyPay,

				"color": "#ffd8af"
			}]
		}]

		d3.select('#test2').selectAll('*').remove();
		d3.select('#test2').append('svg');
		nv.addGraph({
			generate: function() {
				var chart = nv.models.multiBarChart()
				.color(['#ffb15f', '#ffd8af'])
				.stacked(false)


				chart.dispatch.on('renderEnd', function(){
					console.log('Render Complete');
				});
				var formatValue = d3.format(".2s")
				chart.yAxis.tickFormat(function(d) { return formatValue(d).replace('G', 'B'); });
				var svg = d3.select('#test2 svg').datum(NshTotalAmount).style("fill", function(d) { return d.color; });
				console.log('calling chart');
				svg.transition().duration(0).call(chart);

				return chart;
			},

		});
	}
	//EMD Data chart
	$scope.EmdData = function () {

		EmdDataService.getEmdData().then(function(data){
			var emd_data = data;
			$scope.TotalEmailCount = data.stats.stats_fields.emailsentcount.sum;
			$scope.ToyotaClicked = data.stats.stats_fields.emailclickcount.facets.brand_cd.TOYOTA.sum;
			$scope.LexusClicked = data.stats.stats_fields.emailclickcount.facets.brand_cd.LEXUS.sum;
			$scope.ScionClicked = data.stats.stats_fields.emailclickcount.facets.brand_cd.SCION.sum;
			$scope.ToyotaOpen = data.stats.stats_fields.emailopencount.facets.brand_cd.TOYOTA.sum;
			$scope.LexusOpen = data.stats.stats_fields.emailopencount.facets.brand_cd.LEXUS.sum;
			$scope.ScionOpen = data.stats.stats_fields.emailopencount.facets.brand_cd.SCION.sum;
			$scope.ToyotaSent = data.stats.stats_fields.emailsentcount.facets.brand_cd.TOYOTA.sum;
			$scope.LexusSent = data.stats.stats_fields.emailsentcount.facets.brand_cd.LEXUS.sum;
			$scope.ScionSent = data.stats.stats_fields.emailsentcount.facets.brand_cd.SCION.sum;
			console.log(emd_data);

			//var anyNumber = $filter('roundUp')($scope.ToyotaClicked);

		});

		var emdData =  [{
			"key": "Sent Emails",
			"values": [{
				"x": "Toyota",

				"y": $scope.ToyotaSent,

				"color": "#ff6832"
			}, {
				"x": "Lexus",

				"y": $scope.LexusSent,

				"color": "#ff6832"
			}, {
				"x": "Scion",

				"y": $scope.ScionSent,

				"color": "#ff6832"
			}]
		}, {
			"key": "Open Emails",
			"values": [{
				"x": "Toyota",

				"y": $scope.ToyotaOpen,

				"color": "#ffa882"
			}, {
				"x": "Lexus",

				"y": $scope.LexusOpen,

				"color": "#ffa882"
			}, {
				"x": "Scion",

				"y": $scope.ScionOpen,

				"color": "#ffa882"
			}]
		}, {
			"key": "Clicked Emails",
			"values": [{
				"x": "Toyota",

				"y": $scope.ToyotaClicked,

				"color": "#ffe0d2"
			}, {
				"x": "Lexus",

				"y": $scope.LexusClicked,

				"color": "#ffe0d2"
			}, {
				"x": "Scion",

				"y": $scope.ScionClicked,

				"color": "#ffe0d2"
			}]
		}]

		d3.select('#test3').selectAll('*').remove();
		d3.select('#test3').append('svg');
		nv.addGraph({
			generate: function() {
				var chart = nv.models.multiBarChart()
				.color(['#ff6832','#ffa882','#ffe0d2'])
				.stacked(false);

				chart.dispatch.on('renderEnd', function(){
					console.log('Render Complete');
				});
				var formatValue = d3.format(".2s")
				chart.yAxis.tickFormat(function(d) { return formatValue(d).replace('B', 'Billion'); });
				var svg = d3.select('#test3 svg').datum(emdData).style("fill", function(d) { return d.color; });
				console.log('calling chart');
				svg.transition().duration(0).call(chart);

				return chart;
			},

		});
	}
	//Survey chart
	$scope.SurveyCount = function () {
		SurveyCountDataService.getSurveyCountData().then(function(data){
			//console.log(data.data);
			if(data.data != undefined) {
				var survey_data = data.data;			
				$scope.ToyotaSales = parseInt(data.data[3].total, 10);
				$scope.ToyotaService = parseInt(data.data[4].total, 10);
				$scope.LexusCpo = parseInt(data.data[0].total, 10);
				$scope.LexusSales = parseInt(data.data[1].total, 10);
				$scope.LexusService = parseInt(data.data[2].total, 10);
				$scope.totalSurveys = $scope.ToyotaSales + $scope.ToyotaService + $scope.LexusCpo + $scope.LexusSales + $scope.LexusService;
			}
		});

		var SurveyData =  [{
			"key": "Lexus",
			"values": [{
				"x": "Sales",

				"y": $scope.LexusSales,

				"color": "#a8566e"
			}, {
				"x": "CPO",

				"y": $scope.LexusCpo,

				"color": "#a8566e"
			}, {
				"x": "Service",

				"y": $scope.LexusService,

				"color": "#a8566e"
			}]
		},{
			"key": "Toyota",
			"values": [{
				"x": "Sales",

				"y": $scope.ToyotaSales,

				"color": "#dbbac5"
			}, {
				"x": "CPO",

				"y": 0,

				"color": "#dbbac5"
			}, {
				"x": "Service",

				"y": $scope.ToyotaService,

				"color": "#dbbac5"
			}]
		}]

		d3.select('#test4').selectAll('*').remove();
		d3.select('#test4').append('svg');
		nv.addGraph({
			generate: function() {
				var chart = nv.models.multiBarChart()
				.color(['#a8566e', '#dbbac5'])
				.stacked(false);

				chart.dispatch.on('renderEnd', function(){
					console.log('Render Complete');
				});
				var formatValue = d3.format(".2s")
				chart.yAxis.tickFormat(function(d) { return formatValue(d).replace('B', 'Billion'); });
				var svg = d3.select('#test4 svg').datum(SurveyData).style("fill", function(d) { return d.color; });
				console.log('calling chart');
				svg.transition().duration(0).call(chart);

				return chart;
			},

		});
	}

	//Cases Chart
	$scope.CaseData = function () {

		CaseDataService.getCaseData().then(function(data){
			var response_data = data;
			$scope.TotalCaseCount = response_data.stats.stats_fields.no_of_cases.sum;
			$scope.LexusCaseCount = response_data.stats.stats_fields.no_of_cases.facets.brand.Lexus.sum;
			$scope.ToyotaCaseCount = response_data.stats.stats_fields.no_of_cases.facets.brand.Toyota.sum;
			$scope.ScionCaseCount = response_data.stats.stats_fields.no_of_cases.facets.brand.Scion.sum;
		});


		var CaseCount = [
		                 {
		                	 values: [
		                	          { 
		                	        	  "label" : "Toyota" ,
		                	        	  "value" : $scope.ToyotaCaseCount
		                	          } , 
		                	          { 
		                	        	  "label" : "Lexus" , 
		                	        	  "value" : $scope.LexusCaseCount
		                	          } , 
		                	          { 
		                	        	  "label" : "Scion" , 
		                	        	  "value" : $scope.ScionCaseCount
		                	          } 
		                	          ]
		                 }
		                 ]

		d3.select('#test6').selectAll('*').remove();
		d3.select('#test6').append('svg');
		nv.addGraph({
			generate: function() {
				var chart = nv.models.discreteBarChart()
				.x(function(d) { return d.label })
				.y(function(d) { return d.value })
				.color(['#006ee1', '#87c4ff', '#d7ebff'])
				//.staggerLabels(true)
				//.tooltips(false)
				//.showValues(true)
				var formatValue = d3.format(".2s")
				chart.yAxis.tickFormat(function(d) { return formatValue(d); });
				var svg = d3.select('#test6 svg')
				.datum(CaseCount);
				svg.transition().duration(0).call(chart);
				return chart;
			},

		});
	}

	//Goodwill Chart
	$scope.GoodWillData = function () {

		GoodwillDataService.getGoodwillData().then(function(data){
			var response_data = data;
			$scope.OffCustomer = response_data.stats.stats_fields.offered_amt.facets.pay_to.Customer.sum;
			$scope.OffDealer = response_data.stats.stats_fields.offered_amt.facets.pay_to.Dealer.sum;
			$scope.PayCustomer = response_data.stats.stats_fields.payment_amt.facets.pay_to.Customer.sum;
			$scope.PayDealer = response_data.stats.stats_fields.payment_amt.facets.pay_to.Dealer.sum;

			$scope.TotalGoodwillsum = $scope.OffCustomer + $scope.OffDealer + $scope.PayCustomer + $scope.PayDealer;

			//var anyNumber = $filter('roundUp')($scope.OffCustomer);
		});


		var GoodwillData =  [{
			"key": "Offered Amount",
			"values": [{
				"x": "Customer",

				"y": $scope.OffCustomer,

				"color": "#0fc2ff"
			}, {
				"x": "Dealer",

				"y": $scope.OffDealer,

				"color": "#0fc2ff"
			}]
		}, {
			"key": "Payment Amount",
			"values": [{
				"x": "Customer",

				"y": $scope.PayCustomer,

				"color": "#afe8ff"
			}, {
				"x": "Dealer",

				"y": $scope.PayDealer,

				"color": "#afe8ff"
			}]
		}]

		d3.select('#test7').selectAll('*').remove();
		d3.select('#test7').append('svg');
		nv.addGraph({
			generate: function() {
				var chart = nv.models.multiBarChart()
				.color(['#0fc2ff', '#afe8ff'])
				.stacked(false);

				chart.dispatch.on('renderEnd', function(){
					console.log('Render Complete');
				});
				var formatValue = d3.format(".2s")
				chart.yAxis.tickFormat(function(d) { return formatValue(d).replace('B', 'Billion'); })
				var svg = d3.select('#test7 svg').datum(GoodwillData).style("fill", function(d) { return d.color; });
				console.log('calling chart');
				svg.transition().duration(0).call(chart);

				return chart;
			},

		});
	}


	//venn

	$scope.VennChart = function () {

		$scope.UniqueCust =	 "65781836"; 
		$scope.CustwithVehicle	= "45126739"; 
		$scope.withoutVehicle	= "20655097";

		var sets = [
		            {"sets": [0], "label": "Toyota", "size": 37196974, "color":"#0ac1ff"},
		            {"sets": [1], "label": "Lexus", "size": 4851199, "color":"#ff4c0f"},
		            {"sets": [2], "label": "Scion", "size": 1007939, "color":"#c314ff"},
		            {"sets": [0, 1], "size": 1615784},
		            {"sets": [0, 2], "size": 367998},
		            {"sets": [1, 2], "size": 21360},
		            {"sets": [0, 1, 2], "size": 22250},
		            ];

		var chart = venn.VennDiagram()
		.width(450)
		.height(380);

		var div = d3.select("#venn")
		div.datum(sets).call(chart);

		var tooltip = d3.select("body").append("div")
		.attr("class", "venntooltip");

		div.selectAll("path")
		.style("stroke-opacity", 0)
		.style("stroke", "#ff8787")
		.style("stroke-width", 0)
		//.style("fill","yellow")
		div.selectAll("g")
		.on("mouseover", function(d, i) {
//			sort all the areas relative to the current item
			venn.sortAreas(div, d);
//			Display a tooltip with the current size
			tooltip.transition().duration(400).style("opacity", .9);
//			Convert to millions
			var formatValue = d3.format(".2s")
			tooltip.text(formatValue(d.size) + " Customers");

//			highlight the current path
			var selection = d3.select(this).transition("tooltip").duration(400);
			selection.select("path")
			.style("stroke-width", 3)
			.style("fill-opacity", d.sets.length == 1 ? .4 : .1)
			.style("stroke-opacity", 1);
		})

		.on("mousemove", function() {
			tooltip.style("left", (d3.event.pageX) + "px")
			.style("top", (d3.event.pageY - 28) + "px");
		})

		.on("mouseout", function(d, i) {
			tooltip.transition().duration(400).style("opacity", 0);
			var selection = d3.select(this).transition("tooltip").duration(400);
			selection.select("path")
			.style("stroke-width", 0)
			.style("fill-opacity", d.sets.length == 1 ? .5 : .0)
			.style("stroke-opacity", 0);
		});




	}

	$scope.RepairOrder();
	$scope.NshAmount();
	$scope.EmdData();
	$scope.SurveyCount();
	$scope.CustomerData();
	$scope.CaseData();
	$scope.GoodWillData();
	$scope.VennChart();

}]);

TMSApp.filter('roundUp', function () {

	return function nFormatter(num) {
		if (num >= 1000000000) {
			return (num / 1000000000).toFixed(1).replace(/\.0$/, '') + ' B';
		}
		if (num >= 1000000) {
			return (num / 1000000).toFixed(1).replace(/\.0$/, '') + ' M';
		}
		if (num >= 1000) {
			return (num / 1000).toFixed(1).replace(/\.0$/, '') + ' K';
		}
		return num;
	}

});
/* jQuery Code for set dynamic height 'mainCustomerView' ie. Right section */
function setScrollViewport(){
	var winH	=	$(window).height();
	// Container Height
	var cont_ht = winH - $("#main").offset().top;
	$("#main").css('height',cont_ht+'px');
	// Viewport Content Height
	var extraScroll = ($('.main_menu').is(':visible'))? 0 : $('#vin-info').outerHeight(true);
	extraScroll = (extraScroll == null || extraScroll == undefined)? 0 : extraScroll;
	if($('#dsplitview1').is(':visible'))
		var top_pos		= $('#dsplitview1').offset().top;
	else if($('#categoriesTab').is(':visible'))
		var top_pos		= $('#categoriesTab #mainCustomerView').offset().top;
	else if($('#mainCustomerView').is(':visible'))
		var top_pos		= $('#mainCustomerView').offset().top;
	else if($('#householdView').is(':visible'))
		var top_pos		= $('#householdView').offset().top;
	else if($('#editProfileView').is(':visible')) {
		var top_pos		= $('#editProfileView').offset().top;
	}
	var mainViewHt	=	winH - top_pos - extraScroll;
	console.log(winH+'-----:'+extraScroll+'--------------:'+top_pos+'--------------:'+mainViewHt);
	$('.viewport').css('height',mainViewHt+'px');
}
function setSearchContainer() {
	if($('#searchResults').length) {
		var winH	= $(window).height();
		var top_pos	= $('#searchResults').offset().top;
		//var cont_ht	= winH - top_pos - 40;
		var cont_ht	= winH - top_pos;
		$('#searchResults').css('height',cont_ht+'px');
	}
}
function triggerDisclaimerDetailPopup(value){
	//angular.element($('[ng-controller="customerprofileController"]')).scope().DisclaimerDetailPopup(); - This also works fine
	var scope = angular.element($('[ng-controller="customerprofileController"]')).scope();
	scope.$apply(function () {
		scope.DisclaimerDetailPopup(value);
	});
}
/* ends */

TMSApp.factory('SecurityService',['$http','$q', '$rootScope', function($http,$q, $rootScope){
	return {
		getCustomerRoleInfo: function(){
			var deferred = $q.defer()
			var customerRole;
			var url = 'getcustomerRole.do';
			$http.get(url).then(function(response){
				customerRole = response.data;
				deferred.resolve(customerRole);
			})
			return deferred.promise;
		},
		checkAccess : function(role) {
			var rolename = '';
			var roles = [
				{ "key" : "admin_view",  "value" : "C360_CUSTOMER_ADMIN_VIEWER" },
				{ "key" : "non_admin",  "value" : "C360_NON_CUSTOMER_ADMIN_VIEWER" },
				{ "key" : "telematics_view",  "value" : "C360_TELEMATICS_VIEWER" },
				{ "key" : "telematics_updater",  "value" : "C360_TELEMATICS_UPDATER" },
				{ "key" : "social_viewer",  "value" : "C360_SOCIAL_MENTION_WIDGET" },
				{ "key" : "scorer_viewer",  "value" : "C360_SCORING_WIDGET" },
				{ "key" : "survey_viewer",  "value" : "C360_SURVEY_WIDGET" },
				{ "key" : "email_viewer",  "value" : "C360_CAMPAIGN_WIDGET" },
				{ "key" : "customer_admin_updater",  "value" : "C360_CUSTOMER_ADMIN_UPDATER" },
				{ "key" : "customer_updater",  "value" : "C360_CUSTOMER_UPDATER" },
				{ "key" : "toyota_dealer",  "value" : "C360_TOYOTA_INQUIRY_DEALER" },
				{ "key" : "pd_dealer",  "value" : "C360_PD_TOYOTA_INQUIRY_DEALER" },
				{ "key" : "lexus_dealer",  "value" : "C360_LEXUS_INQUIRY_DEALER" },
				{ "key" : "lexus_updater",  "value" : "C360_LEXUS_UPDATE_DEALER" }
			];
			roles.some(function (data, index) {
				if(data.key == role){
					rolename = data.value;
					return true;
				}
			});
			if(rolename == '') return false;
			return this.checkUserByParticularRole(rolename);
		},
		checkMultipleAccess : function(x) {
			return $rootScope.customerRole.indexOf(x) >= 0;
		},
		checkUserByParticularRole : function(role) {
			if($rootScope.customerRole != undefined) {
				if($rootScope.customerRole.indexOf(role) !== -1) return true;
				return false;
			}
		},
		hasAnyOneAccess : function(roleLists) {
			return roleLists.some(this.checkMultipleAccess)
		}
	}
}]);

TMSApp.factory('ValidationService',['$http','$q', '$rootScope', '$timeout', function($http, $q, $rootScope, $timeout){
	return {
		displayError: function(errMsg,elmError,element) {
			if(elmError != undefined) {
				$("#" + elmError).html(errMsg);
				$("#" + elmError).css('display','block');
			}
			$(element).addClass('error_focus');
			if(field_focus == '') field_focus = element;
			$("#errorFlag").val(1);
			return false;
		},
		getValueById: function(id) {
			var element = angular.element('#'+id);
			return $.trim(element.val());
		},
		checkBlank: function(id,fieldName,elmError) {
			var element = angular.element('#'+id);
			var value	= $.trim(element.val());
			if(value == "") {
				this.displayError(fieldName + " is required.", elmError, element);
				return false;
			} else {
				if ($(field_focus).attr('id') == $(element).attr('id')) field_focus = '';
				return true;
			}
		},
		checkRegexp: function(id,regexp,fieldName,elmError) {
			var element = angular.element('#'+id);
			var value	= $.trim(element.val());
			if (value != '' && !regexp.test(value)) {
				if(id == 'customerEmailAddress_emailAddress_emailAddress') {
					this.displayError(fieldName + " is invalid.", elmError, element);
				} else {
					this.displayError(fieldName + " contains invalid characters.", elmError, element);
				}
				return false;
			} else {
				return true;
			}
		},
		checkLengthof: function(id, fieldName, min, max, elmError) {
			var element = angular.element('#'+id);
			var value	= $.trim(element.val());
			var error = '';
			var length = value.length;
			if ((min != 0 && max != 0) && (length > max || length < min))
				error = fieldName + " must be between " + min + " to " + max + ".";
			else if ((min != 0 && max == 0) && (length < min))
				error = fieldName + " must be at least " + min + " characters.";
			else if ((min == 0 && max != 0) && (length > max))
				error = fieldName + " must be maximum " + max + " characters.";
			if (error != '') {
				this.displayError(error, elmError,element);
				return false
			} else {
				return true
			}
		},
		validatePhoneNumber: function(elementId, elemName, errElement) {
			var element 	= angular.element('#'+elementId);
			var elementVal	= $.trim(angular.element('#'+elementId).val());
			if(elementVal == '' || elementVal == null) return true;
			if(this.checkRegexp(elementId, phoneExp, elemName, errElement)) {
				elementVal			= elementVal.replace(/[^0-9]/gi, '');
				var tripleNineCheck	= elementVal.substring(0,3);
				var doubleNumCheck	= elementVal.substring(1,3);
				//May not area code, start with 0 or 1 or 999 or X11
				if(elementVal.charAt(0) == '0' || elementVal.charAt(0) == '1' || tripleNineCheck == '999' || doubleNumCheck == '11') {
					this.displayError(elemName + " contains invalid characters.", errElement, element);
					return false;
				}
				//May not start phNum, with 0 or 1 or 999
				if(elementVal.charAt(3) == '0') {
					this.displayError(elemName + " contains invalid characters.", errElement, element);
					return false;
				}
				//all X's checking i.e., 2s through 9s
				if(elementVal.length > 1) {
					var fistChar = elementVal.charAt(0);
					var flagCheck = false;
					for(i=0; i< elementVal.length; i++) {
						if(elementVal.charAt(i) != fistChar) {
							flagCheck = true;
							break;
						}
					}
					if(!flagCheck) { // false
						this.displayError(elemName + " contains invalid characters.", errElement, element);
						return false;
					}
				}
				if(elementVal.length < 10) {
					this.displayError(elemName + " must be 10 characters.", errElement, element);
					return false;
				}
			} else {
				this.displayError(elemName + " contains invalid characters.", errElement, element);
				return false;
			}
		},
		checkandSetFieldFocus: function() {
			$timeout(function() {
				console.log(field_focus);
				if (field_focus != '' && $.type(field_focus) == "object") {
					$(field_focus).focus();
				} else if (field_focus != '' && $.type(field_focus) == "string") {
					$("#"+field_focus).focus();
				}
			},500);
		}
	}
}]);
// Set Cookie for user
TMSApp.service('AuthenticationService', function() {
	this.setCookie = function(name) {
		if($.cookie(name) == undefined) {
			if(name == "cookie_disclaimer") {
				var today			= new Date();
				var expiresValue	= new Date(today);
				expiresValue.setMinutes(today.getMinutes() + 600); //Set 'expires' option in 600 minutes
				$.cookie(name, true, { expires: expiresValue }); 
			} else {
				$.cookie(name, userId);
			}
			console.log("-----Set: "+name+"----------"+$.cookie(name));
		}
	}
	this.readCookie = function(name) {
		return $.cookie(name);
	}
	this.removeCookie = function(name) {
		$.removeCookie(name);
	}
	this.isCookieExist = function(name) {
		return (this.readCookie(name) != undefined)? true : false;
	}
});

TMSApp.factory('NshDataService',['$http','$q',function($http, $q){
	return {
		getNshData: function(){
			var deferred = $q.defer()
			var NshData;
			var url='getNSHdata.do';
			$http.get(url, {headers: {'Content-Type': 'application/x-www-form-urlencoded'}}).then(function(response){
				NshData = response.data;
				deferred.resolve(NshData);
			})
			return deferred.promise;
		}
	}
}]);

TMSApp.factory('NshAmountDataService',['$http','$q',function($http, $q){
	return {
		getNshAmountData: function(){
			var deferred = $q.defer()
			var NshAmountData;
			var url='getNSHAmountdata.do';
			$http.get(url, {headers: {'Content-Type': 'application/x-www-form-urlencoded'}}).then(function(response){
				NshAmountData = response.data;
				deferred.resolve(NshAmountData);
			})
			return deferred.promise;
		}
	}
}]);

TMSApp.factory('EmdDataService',['$http','$q',function($http, $q){
	return {
		getEmdData: function(){
			var deferred = $q.defer()
			var EmdData;
			var url='getEmdData.do';
			$http.get(url, {headers: {'Content-Type': 'application/x-www-form-urlencoded'}}).then(function(response){
				EmdData = response.data;
				deferred.resolve(EmdData);
			})
			return deferred.promise;
		}
	}
}]);


TMSApp.factory('SurveyCountDataService',['$http','$q',function($http, $q){
	return {
		getSurveyCountData: function(){
			var deferred = $q.defer()
			var SurveyCountData;
			var url='getUssSurveyData.do';
			$http.get(url, {headers: {'Content-Type': 'application/x-www-form-urlencoded'}}).then(function(response){
				SurveyCountData = response.data;
				deferred.resolve(SurveyCountData);
			})
			return deferred.promise;
		}
	}
}]);

TMSApp.factory('CustomerDataService',['$http','$q',function($http, $q){
	return {
		getCustomerData: function(){
			var deferred = $q.defer()
			var CustomerData;
			var url='getCustomerData.do';
			$http.get(url, {headers: {'Content-Type': 'application/x-www-form-urlencoded'}}).then(function(response){
				CustomerData = response.data;
				deferred.resolve(CustomerData);
			})
			return deferred.promise;
		}
	}
}]);

TMSApp.factory('CaseDataService',['$http','$q',function($http, $q){
	return {
		getCaseData: function(){
			var deferred = $q.defer()
			var CaseData;
			var url='getCasesData.do';
			$http.get(url, { headers: {'Content-Type': 'application/x-www-form-urlencoded'}}).then(function(response){
				CaseData = response.data;
				deferred.resolve(CaseData);
			})
			return deferred.promise;
		}
	}
}]);

TMSApp.factory('GoodwillDataService',['$http','$q',function($http, $q){
	return {
		getGoodwillData: function(){
			var deferred = $q.defer()
			var GoodwillData;
			var url='getGoodwillData.do';
			$http.get(url, {headers: {'Content-Type': 'application/x-www-form-urlencoded'}}).then(function(response){
				GoodwillData = response.data;
				deferred.resolve(GoodwillData);
			})
			return deferred.promise;
		}
	}
}]);
TMSApp.directive('ngNumeric', function () {
    return function (scope, element, attrs) {
        element.bind("keypress", function (event) {
			var keyCode	= (event.which?event.which:(event.keyCode?event.keyCode:0));
			if (keyCode == 13) {
				return true;
			}
			var value	= String.fromCharCode(keyCode);
			if($.isNumeric(value)) return true;
			return false;
	
        });
    };
});
TMSApp.directive('ngAlphabets', function () {
    return function (scope, element, attrs) {
        element.bind("keypress", function (event) {
			var keyCode	= (event.which?event.which:(event.keyCode?event.keyCode:0));
			if (keyCode == 13) {
				return true;
			}
			var value	= String.fromCharCode(keyCode);
			if($.isNumeric(value)) return false;
			return true;
        });
    };
});
TMSApp.directive('ngAlphanumeric', function () {
    return function (scope, element, attrs) {
        element.bind("keypress", function (event) {
			var regEx = /^[a-z0-9\s]+$/i;
			var keyCode	= (event.which?event.which:(event.keyCode?event.keyCode:0));
			if (keyCode == 13) {
				return true;
			}
			var value	= String.fromCharCode(keyCode);
			if (regEx.test(value)) return true;
			return false;
        });
    };
});
TMSApp.directive('ngPhone', function () {
    return function (scope, element, attrs) {
        element.bind("keypress", function (event) {
			var regEx = /^[0-9\s\)\(\-]+$/i;
			var keyCode	= (event.which?event.which:(event.keyCode?event.keyCode:0));
			if (keyCode == 13) {
				return true;
			}
			var value	= String.fromCharCode(keyCode);
			if (regEx.test(value)) return true;
			return false;
        });
    };
});
TMSApp.directive('ngModelOnblur', function() {
	return {
        restrict: 'A',
        require: 'ngModel',
        priority: 1, // needed for angular 1.2.x
        link: function(scope, elm, attr, ngModelCtrl) {
            if (attr.type === 'radio' || attr.type === 'checkbox') return;
            elm.unbind('input').unbind('keydown').unbind('change');
            elm.bind('blur', function() {
                scope.$apply(function() {
                    ngModelCtrl.$setViewValue(elm.val());
                });         
            });
        }
    };
});
TMSApp.directive('bindOnce', function($timeout) {
    return {
        scope: true,
        link: function( $scope ) {
            $timeout(function() {
                $scope.$destroy();
            });
        }
    }
});
TMSApp.directive('calendar', function ($timeout) {
	return {
		require: 'ngModel',
		link: function (scope, el, attr, ngModel) {
			$timeout( function(){
				$(el).datepicker({
					showOn: "button",
					changeMonth: true,
					changeYear: true,
					buttonImage: "img/calendericon.png",
					buttonImageOnly: true,
					buttonText: "Select date",
					dateFormat: 'mm/dd/yy',
					changeYear:true,
					yearRange: "c-25:+25", // last hundred years
					beforeShow: function(input, obj) {
						$(el).after($(el).datepicker('widget'));
					},
					onSelect: function (dateText) {
						scope.$apply(function () {
							ngModel.$setViewValue(dateText);
						});
					}
				});
			});
		}
	};
});
TMSApp.directive('ngScroll', function () {
	return {
        restrict: 'A',
        priority: 1, // needed for angular 1.2.x
        link: function(scope, element, attrs, ngModelCtrl) {
			 //Add event listener for 'keydown' event
			var _this, keyCode, currentElem, nextElem, searchedElem, nextElem_pos, container_ht;
			var searchText = previousVal = typedChar = '';
			var lastKeyPressedAt	= 0;
			var KeyPressedAt		= 0;
			var inc = 0;
            element.on("keydown", function (event) {
				_this			= $(this);
				keyCode			= (event.which?event.which:(event.keyCode?event.keyCode:0));
				typedChar		= String.fromCharCode(keyCode);				
				container_ht	= $(_this).find('ul').height();
				
				console.log(typedChar+'----'+keyCode+'---');
				KeyPressedAt = new Date();
				if (lastKeyPressedAt == 0) {
					lastKeyPressedAt = KeyPressedAt;
				}
				
				if(lastKeyPressedAt.toString() == KeyPressedAt.toString()) {
				//if((KeyPressedAt.getSeconds() - lastKeyPressedAt.getSeconds()) < 1 ) { // Time difference between keypressed = 1 Sec
					searchText = searchText+typedChar;
					console.log(lastKeyPressedAt.getSeconds()+"----same------"+KeyPressedAt.getSeconds());
				} else {
					console.log(lastKeyPressedAt.getSeconds()+"----diff------"+KeyPressedAt.getSeconds());
					searchText = typedChar;
					lastKeyPressedAt = KeyPressedAt;
				}
				console.log("----Final Text-----: "+searchText);
				// Find Current Element or Dropdown value
				scope.getCurrentDropdownValue = function() {
					if($(_this).find('ul li').hasClass('selected')) {
						return  $(_this).find('ul li.selected');
					} else {
						return $("li[data-value='']");
					}
				}
				scope.getNextDropdownElement = function() {
					currentElem =  scope.getCurrentDropdownValue();
					if(currentElem != undefined) {
						// Find Next or Prev element
						if (keyCode == 40) { // Next
							if(!$(_this).find('div.dropdown-list').is(':visible')) {
								angular.element($(_this)).find('input:first').trigger('click'); // Open Dropdown manually on pressing down arrow for first time
								return;
							} else {
								return currentElem.next('li');
							}
						} else if (keyCode == 38) { // Prev
							return currentElem.prev('li');
						}
					}
				}
				// Set Scroll position
				scope.setScrollbarPosition = function() {
					var elementHeight	= nextElem.outerHeight();
					var scrollar_pos	= $(_this).find('ul').scrollTop() - ($(_this).offset().top + $(_this).outerHeight());
					var nextElem_pos	= nextElem.offset().top;
					var current_scroll	= scrollar_pos + nextElem_pos;			
					console.log("-----current_scroll------"+current_scroll+"------nextElem_pos----"+nextElem_pos);
					if(current_scroll >= container_ht) {
						if (keyCode == 40) {
							if((nextElem_pos - $(_this).offset().top - $(_this).outerHeight()) >= container_ht) {
								var next_scroll = current_scroll - container_ht + elementHeight;
								$(_this).find('ul').scrollTop(next_scroll);
							}
						} else {
							if(nextElem_pos < ($(_this).offset().top + $(_this).outerHeight())) {
								var next_scroll = $(_this).find('ul').scrollTop() - elementHeight;
								$(_this).find('ul').scrollTop(next_scroll);
							}
						}
						$(_this).find('ul').scrollTop(next_scroll);
					} else {
						var next_scroll = current_scroll - container_ht + elementHeight;
						$(_this).find('ul').scrollTop(next_scroll);
					}
				}
				scope.getSearchValueElement = function () {
					console.log("----previousVal---: "+previousVal);
					if(previousVal == typedChar) {
						inc++;
					} else {
						inc = 0;
					}
					// var options = $(_this).find("li[data-value^='"+character+"']");
					// var options = $(_this).find("li:contains('"+character+"')");
					console.log("---searchText---: "+searchText);
					var options = $(_this).find('li').filter(function() {
						return $(this).text().indexOf(searchText) == 0;
					});
					if(options.length > 0) {
						previousVal = typedChar;
						if(options[inc] != undefined) return $(options[inc]);
						return;
					}
					return;
				}
				scope.searchValue = function() {
					searchedElem = scope.getSearchValueElement();
					if(searchedElem != undefined) {
						$(_this).find('ul li').removeClass('selected');
						searchedElem.addClass('selected');
						
						var scrollar_pos	= $(_this).find('ul').scrollTop() - ($(_this).offset().top + $(_this).outerHeight());
						var searchElem_pos	= searchedElem.offset().top;
						console.log("-----scrollar_pos------:"+scrollar_pos+"------searchElem_pos----:"+searchElem_pos);
						if(scrollar_pos > 0 && searchElem_pos >0) {
							if(searchElem_pos >= scrollar_pos) {
								if((searchElem_pos + scrollar_pos) <= container_ht) {
									var next_scroll	= scrollar_pos + searchElem_pos;
									$(_this).find('ul').scrollTop(next_scroll);
								} else {
									if((searchElem_pos - $(_this).offset().top - $(_this).outerHeight()) >= container_ht) {
										var next_scroll	= scrollar_pos + searchElem_pos;
										$(_this).find('ul').scrollTop(next_scroll);
									}
								}
							} else {
								if((searchElem_pos - $(_this).offset().top - $(_this).outerHeight()) < 1) {
									var next_scroll	= scrollar_pos + searchElem_pos;
									$(_this).find('ul').scrollTop(next_scroll);
								}
								return false;
							}
						} else if(scrollar_pos > 0 && searchElem_pos < 0) {
							var next_scroll	= scrollar_pos + searchElem_pos;
							$(_this).find('ul').scrollTop(next_scroll);
						} else if(scrollar_pos < 0 && searchElem_pos > 0) {
							var next_scroll	= scrollar_pos + searchElem_pos;
							if(next_scroll >= container_ht) {
								$(_this).find('ul').scrollTop(next_scroll);
							}
						}
					}
				}
				// Key Actions
				if(keyCode == 9) {
					return true;
				} else if(keyCode == 13) {
					currentElem = scope.getCurrentDropdownValue();
					currentElem.click();
					setTimeout(function() { angular.element($(_this)).find('input:first').focus(); }, 300);
					
					return false;
				} else if(keyCode == 38 || keyCode == 40) { // Up, Down
					nextElem	= scope.getNextDropdownElement();
					if(nextElem == undefined || nextElem.data('value') == undefined) {
						return false;
					} else {
						$(_this).find('ul li').removeClass('selected');
						nextElem.addClass('selected');
						scope.setScrollbarPosition();
					}
				} else if(keyCode >= 65 && keyCode <= 90) { // a to Z
					if(!$(_this).find('div.dropdown-list').is(':visible')) {
						angular.element($(_this)).find('input:first').trigger('click'); // Open Dropdown manually on pressing down arrow for first time
					}
					scope.searchValue();
				}
			});
        }
    };
});
TMSApp.directive('errorBar', function () {
	return {
		restrict: 'E',
		scope: {
			errorMessage:'=' // or error(any name) : '@errorMessage'
		},
		//template : '<div style="padding: 10px 0; margin-bottom: 10px;" class="errorbar font12"><div style="float: left; padding: 0 10px;"><img src="img/error.png" width="17" height="17"></div><div style="float: left; width:90%;"><p ng-repeat="error in errorMessage track by $index" style="padding:0 0 4px 0;" ng-bind-html="error"></p></div><div style="clear:both;"></div></div>',
		template : '<div style="padding: 10px 0; margin: 10px 0;" class="errorbar font12"><div style="float: left; padding: 0 10px;"><img src="img/error.png" width="17" height="17"></div><div style="float: left; width:90%;"><p style="padding:0 0 4px 0;" ng-bind-html="errorMessage"></p></div><div style="clear:both;"></div></div>',
		link: function(scope, element, attrs, ngModelCtrl) {
			console.log(scope);
		}
	}
});
$("#advancedSearchForm input").keypress(function(event) {
	if (event.which == 13) {
		event.preventDefault();
		$("#advancedSearchForm").submit();
	}
});
function getParameterByName(name, url) {
	if (!url) url = window.location.href;
	name = name.replace(/[\[\]]/g, "\\$&");
	var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
	results = regex.exec(url);
	if (!results) return null;
	if (!results[2]) return '';
	//return decodeURIComponent(results[2].replace(/\+/g, " "));
	return decodeURIComponent(results[2]);
}
/*
if(window.location.hostname == 'c360.qa.toyota.com' || window.location.hostname == 'c360.toyota.com') {
	if(getParameterByName('debug') != 1) {
		$(document).bind("contextmenu",function(e) {
			e.preventDefault();
		});
		$(document).bind("keydown",function(e) {
			if(e.which === 123){ // F12
			   e.preventDefault();
			}
		});
	}
}
$(document).bind("keydown",function(e) {
	console.log("-------e.which--------"+e.which);
	if(e.which === 123){ // F12
	   e.preventDefault();
	}
});
*/
/*
window.onbeforeunload = function(event) { 
	console.log("----------onbeforeunload----------------");
	event.preventDefault();
	event.stopPropagation();
	window.location.replace("http://localhost:8080/profile/profile.do");
};
$(window).bind({
	beforeunload: function(ev) {
		window.location.replace("http://localhost:8080/profile/profile.do");
	},
	unload: function(ev) {
		window.location.replace("http://google.com");
		return false;
	}
});
*/
/*
$(document).ready(function() {
	function disableBack() {
		console.log("----back---disableBack--------");
		window.history.forward();
	}
	window.onload = function() {
		console.log("----back---onload--------");
		disableBack();
	}
	window.onpageshow = function(evt) {
		console.log("---back----onpageshow--------"+evt.persisted);
		if(evt.persisted) {
			console.log("---back----persisted--------");
			disableBack();
		}
	}
});
*/
/******************* dashboard.js ***********************/
var Utilities = Utilities || {};

Utilities.helpers = {
	camelCase: function(input) {
		if (input) {
			input = input.replace(/(!|"|#|\$|%|\'|\(|\)|\*|\&|\-|\+|\,|\.|\/|\:|\;|\?|@)/g, '');
			input = input.charAt(0).toLowerCase() + input.slice(1); //don't lowercase already camelCased strings
			return input.replace(/(?:^\w|[A-Z]|\b\w|\s+)/g, function(match, index) {
				if (+match === 0) return ""; // or if (/\s+/.test(match)) for white spaces
				return index == 0 ? match.toLowerCase() : match.toUpperCase();
			});
		} else {
			return '';
		}
	},
	
	getObjectSize: function(obj) {
	    var size = 0, key;
	    for (key in obj) {
	        if (obj.hasOwnProperty(key)) size++;
	    }
	    return size;
	},
	
	getImage: function(type) {
		var imgName = '';
		switch(type) {
		    case 'toyota':
				imgName = 'product';
		        break;
		    case 'lexus':
				imgName = 'product';
		        break;
		    case 'scion':
				imgName = 'product';
		        break;
		    case 'c360Filter':
		    	imgName = 'c360Filter';
		        break;
		    case 'regularSentiment':
				imgName = 'sentiment';
		        break;
		    case 'entitySentiment':
				imgName = 'sentiment';
		        break;
		    case 'author':
		    	imgName = 'author';
		        break;
		    case 'toyotaCampaign':
				imgName = 'campaign';
		        break;
		    case 'lexusCampaign':
				imgName = 'campaign';
		        break;
		    case 'region':
		    	imgName = 'dealer';
		        break;
		    case 'state':
				imgName = 'demographic';
		        break;
		    case 'gender':
				imgName = 'demographic';
		    default:
		    	imgName = type;
		}
		return imgName;
	},
	
	setText: function (text) {
		var retVal = '';
		if (text) {
	        var siteRegEx = /(\b( https?| ftp| file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
	        retVal =  (text.replace(siteRegEx, "<a href=\"$1\" target=\"_blank\" >$1</a>"));
		}
        return retVal;
    },

	setSpredfast: function(obj) {
	    //SPREDFAST WIDGET
		retVal = [];
		retVal.display = "false";
		if (obj.channel == "Twitter") {
			retVal.display = "true";
			retVal.contentChannel = "twitter";
			retVal.contentType = "tweet";
			retVal.contentId = obj.interaction_id;
			if (obj.brand_group[0] = "Lexus") {
				retVal.accId = 48497136;
			} else {
				retVal.accId = 14219877; //default toyota
			}
	//        } else if (userType =='Scion') {
	//            accId = 7082202;
	//        } else { //other Toyota
	//            if (roleVar.indexOf('CR') > 0) {
	//                accId = 202384221;
	//            }
	//            if (roleVar.indexOf('TFS') > 0) {
	//                accId = 19085737;
	//            }
	//        }
		} else if (obj.channel == "Facebook" && obj.sub_channel) {
			retVal = [];
			retVal.display = "true";
			retVal.contentChannel = "facebook";
			retVal.contentType = "post";
			retVal.contentId = obj.interaction_id;
			switch(obj.sub_channel[0]) {
				case 'Facebook - Toyota Sienna':
					retVal.accId = 111019649989;
					break;
				case 'Facebook - Toyota Latino':
					retVal.accId = 119117898120532;
					break;
				case 'Facebook - Toyota 4Runner':
					retVal.accId = 181224177104;
					break;
				case 'Facebook - Toyota Teen Driver':
					retVal.accId = 183751721705631;
					break;
				case 'Facebook - Toyota USA':
					retVal.accId = 197052454200;
					break;
				case 'Facebook - Toyota Showcase':
					retVal.accId = 235449096548867;
					break;
				case 'Facebook - Toyota Racing':
					retVal.accId = 350285487945;
					break;
				case 'Facebook - TMMI Visitors Center':
					retVal.accId = 382975611726554;
					break;
				case 'Facebook - Toyota Visitor Center - Kentucky':
					retVal.accId = 613765461972283;
					break;
				case 'Facebook - Lexus':
					retVal.accId = 90671958533;
					break;
				case 'Facebook - Toyota Prius':
					retVal.accId = 92381987248;
					break;
	    		}
			}
	   return retVal;
	}
};



TMSApp.controller('dashboardcustomerctrlr', ['$scope', '$rootScope','$http', '$timeout','SecurityService', '$filter', 'EmailWidgetService', function ($scope, $rootScope, $http, $timeout, SecurityService,$filter,EmailWidgetService) {
		console.log("--------dashboardcustomerctrlr-------------");
		//$scope.$on('customerid', function(events, args){
		//var cust_id = args
		$scope.helpers = Utilities.helpers;
		$rootScope.offset = 0;
		$rootScope.navSearchText = '';
		$scope.result = 3;
		//$rootScope.gettingData = false;
		
		// Begin : Security role Implementation
		// The angular-widgetbox directive calls this method when a widget is moved
		$scope.columns = [];
		if($rootScope.customerRole != undefined) {
			if(SecurityService.checkAccess('social_viewer')) {
				$scope.columns.push([{'header':'Recent Mentions','path':'widgets/recentmentions.html'}]);
			}
			if(SecurityService.checkAccess('survey_viewer')) {
				if($scope.columns[0] !== undefined)
					$scope.columns[0].push({'header':'Surveys','path':'widgets/surveys.html'});
				else
					$scope.columns.push([{'header':'Surveys','path':'widgets/surveys.html'}]);
			}
			if(SecurityService.checkAccess('email_viewer')) {
				if($scope.columns[0] !== undefined)
					$scope.columns[0].push({'header':'Email','path':'widgets/emailCampaign.html'});
				else
					$scope.columns.push([{'header':'Email','path':'widgets/emailCampaign.html'}]);
			}
			if(SecurityService.checkAccess('scorer_viewer')) {
				$scope.columns.push([{'header':'Scoring','path':'widgets/customerScoring.html'}]);
			}
			if($scope.columns[1] == undefined) {
				$scope.columns[1] = [];
			}
			console.log($scope.columns);
		}
		// End : Security role Implementation
		
		//$scope.columns = [ [{'header':'Recent Mentions','path':'widgets/recentmentions.html' },{'header':'Surveys','path':'widgets/surveys.html' }],[{'header':'Scoring','path':'widgets/customerScoring.html' }] ];  // The angular-widgetbox directive calls this method when a widget is moved
		
		$scope.widgetboxOnWidgetMove = function(sourceColumn, sourcePosition, targetColumn, targetPosition){
			console.log(sourceColumn+"----"+sourcePosition+"----"+targetColumn+"------"+targetPosition);
			targetColumn = (targetColumn != null)? targetColumn : 1;
			$scope.$apply(function(){
				// The actual movement of the widget happens here, and that's not covered by this module
				// You can copy this snippet if you like - it does the job.
				if(targetColumn){
					var widget = $scope.columns[parseInt(sourceColumn, 10)].splice(parseInt(sourcePosition, 10), 1)[0];
					var target = $scope.columns[parseInt(targetColumn, 10)];
					targetPosition == 'last' ? target.push(widget) : target.splice(parseInt(targetPosition, 10), 0, widget);
				}
				// Swap all Right columns to Left
				if($scope.columns[0].length == 0 && $scope.columns[1].length != 0){
					$scope.columns[0] = $scope.columns[1];
					$scope.columns[1] = [];
				}
				console.log($scope.columns);
			});
		}
		//ios check
		if (window.location == window.parent.location && navigator.userAgent.match(/(iPod|iPhone|iPad)/)) {
			$('#tab1Customercontent').attr('style', '-webkit-overflow-scrolling: touch !important; overflow-y: scroll !important;');
		}
		
		// Email Widget
		// Begin: Variable declaration
		$rootScope.selectedEmail 		= [];
		$rootScope.checkAll				= true;
		$rootScope.emailDropdownFlag	= false;
		// End: Variable declaration
		$scope.getEmaiList = function(cust_id) {		
			console.log("-----getEmaiList-----");
			var url = 'getEmailList.do?customerId='+cust_id;
			$http.get(url).then(function(response){
				$rootScope.emailDetails = response.data;
				$rootScope.emailDetails = {"emailIdList":[{"emailID":1122912,"emailAddress":"jmcarter470@yahoo.com","startDate":"23 Mar 2010","endDate":"Till Now","startDt":1269343160000,"count":"6"}],"emailDetailsList":[{"emailId":1122912,"emailName":"Scheduled Monthly Vehicle Health Rpt PROD","sentOn":"29 May 2017","sentOnDate":1496078340000,"sentOnDt":1496078340000,"businessUnit":"Lexus BRRI","dealerCode":null,"dealerName":null,"status":"Delivered","mid":6303773,"proofLink":null,"channel":"EM"},{"emailId":1122912,"emailName":"Scheduled Monthly Vehicle Health Rpt PROD","sentOn":"29 Apr 2017","sentOnDate":1493486340000,"sentOnDt":1493486340000,"businessUnit":"Lexus BRRI","dealerCode":null,"dealerName":null,"status":"Delivered","mid":6303773,"proofLink":null,"channel":"EM"},{"emailId":1122912,"emailName":"Scheduled Monthly Vehicle Health Rpt PROD","sentOn":"30 Mar 2017","sentOnDate":1490894400000,"sentOnDt":1490894400000,"businessUnit":"Lexus BRRI","dealerCode":null,"dealerName":null,"status":"Delivered","mid":6303773,"proofLink":null,"channel":"EM"},{"emailId":1122912,"emailName":"Scheduled Monthly Vehicle Health Rpt PROD","sentOn":"28 Feb 2017","sentOnDate":1488284220000,"sentOnDt":1488284220000,"businessUnit":"Lexus BRRI","dealerCode":null,"dealerName":null,"status":"Delivered","mid":6303773,"proofLink":null,"channel":"EM"},{"emailId":1122912,"emailName":"Scheduled Monthly Vehicle Health Rpt PROD","sentOn":"30 Jan 2017","sentOnDate":1485778740000,"sentOnDt":1485778740000,"businessUnit":"Lexus BRRI","dealerCode":null,"dealerName":null,"status":"Delivered","mid":6303773,"proofLink":null,"channel":"EM"},{"emailId":1122912,"emailName":"Scheduled Monthly Vehicle Health Rpt PROD","sentOn":"30 Dec 2016","sentOnDate":1483121880000,"sentOnDt":1483121880000,"businessUnit":"Lexus BRRI","dealerCode":null,"dealerName":null,"status":"Delivered","mid":6303773,"proofLink":null,"channel":"EM"}]};
				$rootScope.$broadcast('GetSelectedEmail');
				$rootScope.widgetEmailData = angular.copy($rootScope.emailDetails.emailDetailsList.slice(0,5));
				$rootScope.emailMasterData = angular.copy($rootScope.emailDetails.emailDetailsList);
				$scope.recentMailIds = [];
				if($rootScope.emailMasterData.length > 0) {
					angular.forEach($rootScope.emailMasterData, function(value, key) {
						// Recent 5 mails and their Id's
						if(key < 5) {
							if(value.emailId != 0 && $scope.recentMailIds.indexOf(value.emailId) < 0) {
								$scope.recentMailIds.push(value.emailId);
							}
						}
					});
					angular.forEach($rootScope.emailDetails.emailIdList, function(value, key) {
						if(value.count != null && $rootScope.selectedEmail.indexOf(value.emailID) < 0) {
							$rootScope.selectedEmail.push(value.emailID);
						}
					});
				}
			});
		}
		$scope.$on('customerid', function(event,data) {
			customerId = data;
			$scope.getEmaiList(customerId);
		});
		var getEmailDetailsOnLoad = setInterval(function(){
			if($rootScope.Newcustomer != undefined) {
				$scope.getEmaiList($rootScope.customerId);
				clearInterval(getEmailDetailsOnLoad);
			}
		}, 100);
		$scope.viewMoreEmail = function() {
			angular.element($('#categoriesTab [ng-controller="customerTabsCtrl"]')).scope().setTab(2);
			$timeout(function() {
				$rootScope.e_reverse			= true;
				$rootScope.e_columnName			= 'sentOnDate';
				$rootScope.checkAll				= true;
				$rootScope.emailDropdownFlag	= false;
				$rootScope.emailDetails.emailDetailsList = angular.copy($rootScope.emailMasterData);
				$rootScope.$broadcast('GetSelectedEmail');
				setScrollViewport();
			}, 300);
		}
		$scope.showEmailDropdown = function(){
			EmailWidgetService.showEmailDropdown();
		}
		$scope.showAllEmailDetails = function() {
			EmailWidgetService.showAllEmailDetails('Widget');
		}
		$scope.filterEmailList = function(event) {
			EmailWidgetService.filterEmailList(event, 'Widget');
		}		
	}
]);

TMSApp.filter('offset', function() {
    return function(input, start) {
        start = parseInt(start, 10);
        return input.slice(start);
    };
});
  var cities = [
    {
        city : 'Toronto',
        desc : 'This is the best city in the world!',
        lat : 43.7000,
        long : -79.4000
    }
];


TMSApp.controller('CampaignsCtrl',['$scope','$rootScope','createDialog', function($scope,$rootScope,createDialog) {
	$scope.openPopup = function(title) {};
}]);
TMSApp.controller('EmailCampaignCtrl',['$scope','$rootScope', '$http', '$timeout', 'EmailWidgetService', function($scope, $rootScope, $http, $timeout, EmailWidgetService) {
	console.log("--------------EmailCampaignCtrl----------");
	$rootScope.checkAll		= true;
	$rootScope.e_reverse	= true;
	$rootScope.e_columnName	= 'sentOnDate';
	$scope.searchtxt	= '';
	$scope.startIndex	= 0;
	$scope.endIndex		= 15;
	// Filters
	$scope.emailListSort = function(sortvalue, sortvalue2) {
		$rootScope.e_reverse	= ($rootScope.e_columnName === sortvalue || ($rootScope.e_columnName[0] != undefined && $rootScope.e_columnName[0] === sortvalue) )? !$rootScope.e_reverse : false;
		$rootScope.e_columnName	= sortvalue;
		if(sortvalue2 != undefined) {
			$rootScope.e_columnName = [sortvalue, sortvalue2];
		}
	};
	$scope.showEmailDropdown = function(){
		EmailWidgetService.showEmailDropdown();
	}
	$scope.showAllEmailDetails = function() {
		$scope.initializeFilterOptions();
		EmailWidgetService.showAllEmailDetails('Categories');
	}
	$scope.filterEmailList = function(event) {
		$scope.startIndex	= 0;
		$scope.endIndex		= 15;
		$scope.initializeFilterOptions();
		EmailWidgetService.filterEmailList(event, 'Categories');
	}
	$scope.setEmailPagination = function(nav) {
		$scope.emailResultCnt = $rootScope.emailDetails.emailDetailsList.length;
		if(nav == 'Next') {
			$scope.startIndex	= $scope.startIndex + 15;
			$scope.endIndex		= $scope.endIndex + 15;
			$scope.endIndex		= ($scope.endIndex > $scope.emailResultCnt)? $scope.emailResultCnt : $scope.endIndex;
		} else if(nav == 'Prev') {
			$scope.startIndex	= $scope.startIndex - 15;
			if($scope.endIndex == $scope.emailResultCnt && ($scope.emailResultCnt % 15 != 0)) {
				$scope.endIndex = $scope.endIndex - ($scope.emailResultCnt % 15);
			} else {
				$scope.endIndex = $scope.endIndex - 15;
			}
		} else {
			$scope.endIndex = ($scope.endIndex > $scope.emailResultCnt)? $scope.emailResultCnt : $scope.endIndex;
		}	
		if(nav != '') {
			$("#searchResults").animate({"scrollTop": "0px"}, 500);
		}
	}
	/*********************** Begin : Email Filter ********************************/
	$rootScope.emailFilterFlag = false;
	$scope.initializeFilterOptions = function() {
		console.log("-----------initializeFilterOptions------------");
		$scope.filterOptions		= { "emailFilter": {"em":'', "dm":''}, "dateFilter": {"stdate":'', "enddate":''}, "sentby": "", "name": "", "statusFilter": {"opened":'', "clicked":'', "sent":'', "delivered":'', "bounced":'', "emailsent":''} };
	}
	$scope.initializeFilterOptions();
	$scope.openFilter = function(){
		$scope.searchtxt	= '';
		$rootScope.emailFilterFlag = !$rootScope.emailFilterFlag ;
	}	
	$scope.applyFilter = function() {
		$scope.submitEmailWidgetFilter();
		$rootScope.emailFilterFlag = false;
	}
	$scope.resetFilterOptions = function() {
		$scope.initializeFilterOptions();
		$rootScope.emailDetails.emailDetailsList = angular.copy($rootScope.emailMasterData);
	}
	$scope.submitEmailWidgetFilter = function() {
		console.log("-----------submitEmailWidgetFilter-------------");
		// Reset Email Filter
		$rootScope.$broadcast('GetSelectedEmail');
		$timeout(function() { angular.element('.email_container input[type="checkbox"]').prop('checked', true); },100);
		$rootScope.checkAll = true;
		// Ends
		$scope.startIndex	= 0;
		$scope.endIndex		= 15;
		$rootScope.emailDetails.emailDetailsList = [];
		var results = angular.copy($rootScope.emailMasterData);
		// Email Filter
		if($scope.filterOptions.emailFilter.dm != '' || $scope.filterOptions.emailFilter.em != '') {
			var masterData	= angular.copy(results);
			results			= [];
			angular.forEach(masterData, function(value, key) {
				console.log(value.channel);
				if(value.channel != '' && ($scope.filterOptions.emailFilter.dm == value.channel || $scope.filterOptions.emailFilter.em == value.channel)) {
					results.push(value);
				}
			});
		}
		// SentBy Filter
		if($scope.filterOptions.sentby != '') {
			var searchText = $scope.filterOptions.sentby.toLowerCase();
			var masterData	= angular.copy(results);
			results			= [];
			angular.forEach(masterData, function(value, key) {
				if(value.businessUnit != null && value.businessUnit.toLowerCase().indexOf(searchText) != -1) {
					results.push(value);
				}
				if(value.dealerName != null && value.dealerName.toLowerCase().indexOf(searchText) != -1) {
					results.push(value);
				}
			});
		}
		// Name/Subject Filter
		if($scope.filterOptions.name != '') {
			var searchText = $scope.filterOptions.name.toLowerCase();
			var masterData	= angular.copy(results);
			results			= [];
			angular.forEach(masterData, function(value, key) {
				if(value.emailName != null && value.emailName.toLowerCase().indexOf(searchText) != -1) {
					results.push(value);
				}
			});
		}
		// Status Filter
		if($scope.filterOptions.statusFilter.opened != '' || $scope.filterOptions.statusFilter.clicked != '' || $scope.filterOptions.statusFilter.sent != '' || $scope.filterOptions.statusFilter.delivered != '' || $scope.filterOptions.statusFilter.bounced != '' || $scope.filterOptions.statusFilter.emailsent != '') {
			statusSearch = true;
			var masterData	= angular.copy(results);
			results			= [];
			angular.forEach(masterData, function(value, key) {
				console.log(value.status);
				if(value.status === $scope.filterOptions.statusFilter.opened || value.status === $scope.filterOptions.statusFilter.clicked || value.status === $scope.filterOptions.statusFilter.sent || value.status === $scope.filterOptions.statusFilter.delivered || value.status === $scope.filterOptions.statusFilter.bounced || value.status === $scope.filterOptions.statusFilter.emailsent) {
					results.push(value);
				}
			});
		}
		// Date Filter
		if($scope.filterOptions.dateFilter.stdate != '' || $scope.filterOptions.dateFilter.enddate != '') {
			var masterData	= angular.copy(results);
			results			= [];
			var startDate	= getDateTime($scope.filterOptions.dateFilter.stdate);
			var endDate		= getDateTime($scope.filterOptions.dateFilter.enddate);
			angular.forEach(masterData, function(value, key) {
				console.log(startDate+'------------'+value.sentOnDate+'------------'+endDate);
				if(startDate != '' && endDate != '') {
					if(value.sentOnDate >= startDate && value.sentOnDate <= endDate) results.push(value);
				} else if(startDate != '') {
					if(value.sentOnDate >= startDate) results.push(value);
				} else if(endDate != '') {
					if(value.sentOnDate <= endDate) results.push(value);
				}
			});
		}
		$rootScope.emailDetails.emailDetailsList = angular.copy(results);
	}
	getDateTime = function(date) {
		if(date != '') {
			var dateArr = date.split("/");
			var d = new Date(dateArr[2], (dateArr[0]-1), dateArr[1]);
			return d.getTime()
		} else {
			return '';
		}
	}
	$scope.addHttps = function(url) {
		return url.replace("http://", "https://");
	}
	// Get Email Campaign Master Data
	$rootScope.$on('GetEmailCampaignDetails', function(events) {
		$rootScope.checkAll	= true;
		$rootScope.emailDetails.emailDetailsList = angular.copy($rootScope.emailMasterData);
	});
	// Get all Emailaddress to which emails has been sent
	$rootScope.$on('GetSelectedEmail', function(events) {
		$rootScope.selectedEmail	= [];
		angular.forEach($rootScope.emailDetails.emailIdList, function(value, key) {
			if(value.count != null && $rootScope.selectedEmail.indexOf(value.emailID) < 0) {
				$rootScope.selectedEmail.push(value.emailID);
			}
		});
	});
	// Reset Filter Form
	$rootScope.$on('resetFilterOptions', function(events) {
		$scope.initializeFilterOptions();
	});
	/*********************** End : Email Filter **********************************/
}]);
TMSApp.service('EmailWidgetService',['$http', '$q', '$rootScope', '$timeout', function($http, $q, $rootScope, $timeout){
	this.showEmailDropdown = function() {
		$rootScope.emailDropdownFlag = !$rootScope.emailDropdownFlag;
	}
	this.showAllEmailDetails = function(page) {
		$rootScope.checkAll = !$rootScope.checkAll;
		if(page == 'Widget') {
			var emailData = angular.copy($rootScope.widgetEmailData);
		} else {
			var emailData = angular.copy($rootScope.emailMasterData);
		}
		if($rootScope.checkAll == false) {
			$rootScope.selectedEmail = [];
			$timeout(function() { angular.element('.email_container input[type="checkbox"]').prop('checked', false); },100);
			$rootScope.emailDetails.emailDetailsList = [];
			angular.forEach(emailData, function(emailObj, key) {
				if(emailObj.emailId == 0) {
					$rootScope.emailDetails.emailDetailsList.push(emailObj);
				}
			});
		} else {
			// GetSelectedEmail
			$rootScope.$broadcast('GetSelectedEmail');
			$rootScope.emailDetails.emailDetailsList = angular.copy(emailData);
		}
	}
	this.filterEmailList = function(event, page) {
		var emailId = parseInt(event.target.value);
		if($(event.target).is(':checked')) {
			if($rootScope.selectedEmail.indexOf(emailId) < 0) {
				$rootScope.selectedEmail.push(emailId);
			}
		} else {
			$timeout(function() {
				if(page == 'Widget') {
					$("#email_"+emailId).prop('checked', false);
				} else {
					$("#email_detail_"+emailId).prop('checked', false);
				}
			},100);
			var index = $rootScope.selectedEmail.indexOf(emailId);
			if(index != -1) {
				$rootScope.selectedEmail.splice(index,1);
			}
		}
		$rootScope.checkAll = ($rootScope.selectedEmail.length == $rootScope.emailDetails.emailIdList.length)? true:false;
		// Filtered result
		$rootScope.emailDetails.emailDetailsList = [];
		if(page == 'Widget') {
			var emailData = angular.copy($rootScope.widgetEmailData);
		} else {
			var emailData = angular.copy($rootScope.emailMasterData);
		}
		if($rootScope.selectedEmail.length > 0) {
			angular.forEach(emailData, function(emailObj, key) {
				if($rootScope.selectedEmail.indexOf(emailObj.emailId) != -1 || emailObj.emailId == 0) {
					$rootScope.emailDetails.emailDetailsList.push(emailObj);
				}
			});
		} else {
			angular.forEach(emailData, function(emailObj, key) {
				if(emailObj.emailId == 0) {
					$rootScope.emailDetails.emailDetailsList.push(emailObj);
				}
			});
		}
	}
	this.resetEmailWidgetData = function(page) {
		$rootScope.checkAll = true;
		$timeout(function() { angular.element('.email_container input[type="checkbox"]').prop('checked', true); },100);
		if(page == 'Widget') {
			var emailData = angular.copy($rootScope.widgetEmailData);
		} else {
			var emailData = angular.copy($rootScope.emailMasterData);
		}
		$rootScope.$broadcast('resetFilterOptions');
		$rootScope.$broadcast('GetSelectedEmail');
		$rootScope.emailDetails.emailDetailsList = angular.copy(emailData);
	}
}]);
/******************* FamilyController.js ***********************/
var household_id, cust_id1;
var telematics_temp_arr = [];
var alphabets	= /^[aA-zZ\s]+$/i;
var nameRegEx	= /^[a-zA-z\'\-\"\s]+$/;
//var nameRegEx	= /[a-zA-Z0-9àâäèéêëîïôœùûüÿçÀÂÄÈÉÊËÎÏÔŒÙÛÜŸÇ\s]+/g;
var phoneExp	= /^[0-9\s\)\(\-]+$/i;
var emailExp	= /^.+@.+\..{2,3}$/;
var orgNameExp	= /^[\\`\?\_\;\@\=\$\%\+\(\)\{\}\[\]\|\>\/\<\"\'\-\s\&\#\.\,0-9a-zA-Z\:\~\'\!\^\*]+/;

/* ==============================================FamilyCtrl================================================= */
TMSApp.controller('FamilyCtrl',['$scope', '$filter', '$http', '$q', '$rootScope', 'createDialog','$timeout','PermissionPopup','NewCustomerInfoService','CustomerDetail','HistoryService', 'DealerviewPopup', '$localStorage', 'AuthenticationService', 'SecurityService', 'CustomerUpdateService', 'ValidationService', 'CustomerValidationService',  function($scope, $filter, $http, $q, $rootScope, createDialog, $timeout, PermissionPopup, NewCustomerInfoService,CustomerDetail, HistoryService, DealerviewPopup, $localStorage, AuthenticationService, SecurityService, CustomerUpdateService, ValidationService, CustomerValidationService) {
	console.log('--------FamilyCtrl Intiated-----------');
	 $scope.$on('network_connection',function(events, value) {
		 console.log("comes here");
		 $scope.network_connection = value;
	 });
	 
	 /* Begin : Confirmation popup flag variables */
	$scope.initialisePopupVariables = function() {
		$rootScope.mergeAcrossRegionFlag			= false;
		$rootScope.mergeConfirmationFlag			= false;
		$rootScope.updateOwnerConfirmationFlag		= false;
		$rootScope.deceasedIndConfirmationFlag		= false;
		$rootScope.custTypeChangeConfirmationFlag	= false;
		$rootScope.commPermissionsConfirmationFlag	= false;
	}
	$scope.initialisePopupVariables();
	/* End : Confirmation popup flag variables */
	 
	$scope.$on('customerid', function(events, args, vin){
		console.log(args+"----customerid----------"+vin);
		$('.loader_outer, .loader_inner').show();
		$('#customertab1-container1 .ngscroll-container').css('marginTop','0px'); 
		var cust_id = args
		//var cust_id = '129891175';	// 119780997, 118882516, Active Dealer - 41325800|104297600, sh - 95546347, 24383926, 34497359
		var customer;
		var empty_handle = false
		$scope.empty_handles = false
		$scope.empty_vehicle = false
		$scope.customerAddress = []
		$rootScope.customerId = cust_id;
		if(cust_id != undefined && cust_id != null){
			$rootScope.serviceHistoryFlag = $rootScope.nonWarrantyFlag = $rootScope.reAcquireFlag = true;
			NewCustomerInfoService.getNewCustomerDetails(cust_id, $rootScope.roleType, vin).then(function(data){
				console.log(data);
				$rootScope.customerName = [];
				if(data == '' || data == null) {
					if(vin != undefined && vin != '') {
						$rootScope.vinView	= true;
						return false;
					} else {
						$rootScope.nocustomer = true;
						$rootScope.$broadcast('showMainProfilePage');
						$('.loader_outer, .loader_inner').hide();
						return false;
					}
				} else {
					$rootScope.customerId	= data.customerId;
					$rootScope.vinView		= false;
					$rootScope.nocustomer	= false;
				}
				// Hide Loader
				if($('#no_widgets').length || !SecurityService.checkAccess('scorer_viewer')) {
					$timeout(function() { $('.loader_outer, .loader_inner').hide(); },300);
				}
				var response_data = data;
				$rootScope.Newcustomer = response_data;
				// Begin: Recent search history
				if(SecurityService.checkAccess('admin_view')) {
					$scope.addToRecentSearchHistory('Customer', $rootScope.Newcustomer.customerId, $rootScope.Newcustomer);
				}
				// End: Recent search history
				
				// Begin : Edit Profile Info
				$rootScope.$broadcast('customerEdit');
				// End : Edit Profile Info
				$rootScope.vehicles = $rootScope.Newcustomer.vehicles; 
				$rootScope.vehicles = $filter('orderBy')($rootScope.vehicles, '-purchaseDate');
				// Disposed Vehicles
				$rootScope.disposedVehicles = $rootScope.Newcustomer.disposedVehicles;
				$rootScope.disposedVehicles =  $filter('orderBy')($rootScope.disposedVehicles, '-purchaseDate');
				if($rootScope.selectedVin == undefined || $rootScope.selectedVin == '') { // Enters the loop, only for the first time when choosing customer from solar search
					if ($rootScope.vehicles != 0 && $rootScope.vehicles != undefined){
						// both are different - used in different controllers
						$rootScope.Vin = $rootScope.Newcustomer.vehicles[0].vin;
						$rootScope.vin = $rootScope.Newcustomer.vehicles[0].vin;
						// Selected Vin
						$rootScope.selectedVin			= $rootScope.Newcustomer.vehicles[0].vin;
						$rootScope.ownerEffectiveDate	= $rootScope.Newcustomer.vehicles[0].effectiveDate;
					} else if ($rootScope.disposedVehicles != 0 && $rootScope.disposedVehicles != undefined) {
						$rootScope.selectedVin			= $rootScope.Newcustomer.disposedVehicles[0].vin;
						$rootScope.ownerEffectiveDate	= $rootScope.Newcustomer.disposedVehicles[0].effectiveDate;
					}
				}		
				$rootScope.permissions = $rootScope.Newcustomer.permissions;

				if($rootScope.Newcustomer.customerType != 'BUSINESS'){
					$rootScope.customerName	=	$rootScope.Newcustomer.customerFirstName;
					if($rootScope.Newcustomer.customerMiddleName != null && $rootScope.Newcustomer.customerMiddleName != '')
						$rootScope.customerName	= $rootScope.Newcustomer.customerFirstName+' '+$rootScope.Newcustomer.customerMiddleName;
					
					if($rootScope.Newcustomer.customerLastName != null && $rootScope.Newcustomer.customerLastName != '')
						$rootScope.customerName	= $rootScope.customerName+' '+$rootScope.Newcustomer.customerLastName;
					
					if($rootScope.Newcustomer.salutation != null && $rootScope.Newcustomer.salutation != '')
						$rootScope.customerName	= $rootScope.Newcustomer.salutation+' '+$rootScope.customerName;
					if($rootScope.Newcustomer.nameSuffix != null && $rootScope.Newcustomer.nameSuffix != '')
						$rootScope.customerName	= $rootScope.customerName+' '+$rootScope.Newcustomer.nameSuffix;
				}
				$timeout(function() {setScrollViewport() },300);
				// Get pma details
				if($rootScope.Newcustomer.pmaDealerDetails.length != 0) {
					var postdata = { "pmadealers": $rootScope.Newcustomer.pmaDealerDetails };
					$http.post('getpmaDealerInfo.do', postdata).then(function (response) {
						var response_data = response.data;
						$rootScope.Newcustomer.pmaLexusDealer = response_data.pmaLexusDealer;
						$rootScope.Newcustomer.pmaToyotaDealer = response_data.pmaToyotaDealer;
					});
				} else {
					$rootScope.Newcustomer.pmaLexusDealer = null;
					$rootScope.Newcustomer.pmaToyotaDealer = null;
				}
				//Goolemap lat and long
				if($rootScope.Newcustomer.address != null && $rootScope.Newcustomer.address != null) {
					var lat12 = $rootScope.Newcustomer.address.latitude;
					var long12 = $rootScope.Newcustomer.address.longitude;
				}
				var lat,long;
				if(long12 != null && lat12 != null) {
					lat = lat12.substring(0,lat12.length-6) + '.' + lat12.substring(lat12.length-6);
					long = long12.substring(0,long12.length-6) + '.' + long12.substring(long12.length-6);
				}
				$rootScope.address = [lat,long]
				$rootScope.AddressLatLong = $rootScope.address
				//console.log(lat); console.log(long);
				function insertDecimalPoints(s) {
					var l = s.length;
					var res = ""+s[0];
					for (var i=1;i<l-1;i++) {
						if ((l-i)%3==0)
							res+= ",";
						res+=s[i];
					}
					res+=s[l-1];
					res = res.replace(',.','.');
					return res;
				}
				
				
				//show more vehicles functionality
				var pagesShown = 1;
				var pageSize = 5;

				$scope.paginationLimit = function(data) {
					return pageSize * pagesShown;
				};
				$scope.hasMoreItemsToShow = function() {
					return pagesShown < ($rootScope.vehicles.length / pageSize);
				};
				$scope.showMoreItems = function() {
					pagesShown = pagesShown + 1;       
				};	
				
				var resultsArray = ['PHONE','TEXT','EMAIL','MAIL'];
				var Marketarray = [];
				var surveyarray = [];
				var servicearray = [];
				var marketingArray = $rootScope.permissions.marketing;
				var surveyArray = $rootScope.permissions.survey;
				var serviceArray = $rootScope.permissions.service;
				for(i = 0; i < resultsArray.length; i ++)
				{ 
					
					for(j= 0; j < marketingArray.length; j ++)
					{
						if(marketingArray[j].channel == resultsArray[i])
						{
							 Marketarray.push(marketingArray[j]);
						}
					}
					
					for(j= 0; j < surveyArray.length; j ++)
					{
						if(surveyArray[j].channel == resultsArray[i])
						{
							surveyarray.push(surveyArray[j]);
						}
					}
					
					for(j= 0; j < serviceArray.length; j ++)
					{
						if(serviceArray[j].channel == resultsArray[i])
						{
							servicearray.push(serviceArray[j]);
						}
					}
					
				}
				$rootScope.permissions.marketing = Marketarray;
				$rootScope.permissions.survey = surveyarray;
				$rootScope.permissions.service = servicearray;
			}).catch(function(response){
				console.log("----------------error----------------");
			}); 
			/*
			$scope.click = function(vehicle,modelyear,modelname,brand){
				console.log(vehicle+'-----'+modelyear+'-----'+modelname+'-----'+brand);
				$rootScope.editProfileView	= false;
				$rootScope.VehicleMakeModel	= '';
				var vehicle = vehicle;
				$timeout(function(){
					$rootScope.$broadcast('VehicleClicked', vehicle,modelyear,modelname,brand);
					setScrollViewport();
				},300);
			}
			*/
			$scope.Showmoreclicked = function(){		   
				if($rootScope.vehicles.length > 5){
					$rootScope.VehiclesClicked = $rootScope.vehicles;
					var vehicle = $rootScope.VehiclesClicked[0].vin;
					var modelyear = $rootScope.VehiclesClicked[0].modelYear;
					var modelname = $rootScope.VehiclesClicked[0].model;
					var brand = $rootScope.VehiclesClicked[0].brand;
					$timeout(function(){
						$rootScope.$broadcast('VehicleClicked', vehicle,modelyear,modelname,brand);
						$rootScope.$broadcast('showDetailsMenuTab',2); // 2 - All vehicles
					},300);
				}
			};
			
		}
		function vehicle($scope,$rootScope) {
			$scope.vehicle=$rootScope.vehicle
		}
		$scope.launchInlineModal = function(hh_data) {
			$rootScope.vehicle_details = hh_data
			createDialog({
				id: 'simpleDialog',
				templateUrl:'views/family.html',
				title: 'Household',
				backdrop: true,
				success: {label: 'Success', fn: function() {console.log('Inline modal closed');}}
			});

		};
		$scope.PermissionPopup=function(){
			$scope.title="Permissions";
			PermissionPopup({
				id: 'simpleDialog',
				templateUrl:'views/permissionPopup.html',
				title: $scope.title,
				backdrop: true,
				modalClass: "popup_container",
				css: {minHeight : "345px", width: "425px" },
				success: {
							label: 'Success',
							fn: function() {
								$timeout(function() { $scope.openEditPermission(); }, 50);
							}
						}
			});
		}
		$scope.CustomerDetailview=function(){
			var marginPos = $('.activeDealer').outerHeight() + 20;
			$('.customerDetailWrapper').css('marginTop', marginPos+'px');
			$rootScope.customerDetailFlag = !$rootScope.customerDetailFlag;
		}
		$scope.activeDealerPopup = function(dealerCode) {
			$rootScope.customerDetailFlag = false;
			HistoryService.getDealerInfoDetails(dealerCode).then(function(data){	
				//$rootScope.weeks = ['Monday','Tueday','Wednesday','Thursday','Friday','Saturday','Sunday'];
				var response_data = data;
				$rootScope.dealerInfoDetail = response_data;	
			});
			DealerviewPopup({
				id: 'simpleDialog',
				templateUrl:'views/dealerinfopopup.html',
				title: '',
				backdrop: true,
				modalClass: "delaerinfopopup",
				success: {label: 'Success', fn: function() {console.log('Inline modal closed');}}
			});
		}
		angular.element('body').bind('click', function(event){
			var activeInfoElement = $(event.target).parents('div.activedealerinfo').hasClass('activedealerinfo');
			if($(event.target).attr('id') != 'customername' && !activeInfoElement) {
				$rootScope.customerDetailFlag = false;
			}
		});
	});
	// Edit Profile
	$scope.setEditProfile = function(action) {
		$rootScope.editProfileView = (action == 'Open')? true : false;
		$scope.resetEditProfileData();
	}
	// Update Vehicle Owner for Orphan VIN view
	$scope.UpdateOrphanVinOwner = function() {
		$rootScope.$broadcast('customerEdit');
	}
	$scope.resetEditProfileData = function() {
		$rootScope.customerEditFlag	= true;
		$rootScope.customerAddFlag	= false;
		$timeout(function(){
			// Reset values, when every time edit profile link is clicked.
			if($rootScope.Newcustomer != undefined) {
				$rootScope.$broadcast('customerEdit');
			}
			$('#editProfileView').scrollTop(0);
			setScrollViewport();
		},50);
	}
	$scope.openEditPermission = function(){
		$scope.resetEditProfileData();
		$rootScope.$broadcast('EditPermission');
	}
	
	/************************** Begin : Merge Purge Module **************************/
	// Begin : Variable Declaration
	$scope.merge_errMsg				= '';
	$scope.diff_region_errMsg		= '';
	$rootScope.mergeCustomerDetails	= [];
	$scope.mergedCustomerIds		= [];
	$rootScope.mergePurgeViewFlag	= false;
	// End : Variable Declaration
	// Begin : Methods
	$scope.$on('AddToMergeList', function(events, data){
		console.log(data);
		$scope.MergeCustomer(data);
	});
	$scope.showCustomerDetails = function(cust_id) {
		console.log("--------showCustomerDetails--------");
		$scope.$emit('showCustomerProfile');
		$scope.advanceSearchResultFlag	= false;
		$rootScope.mergePurgeViewFlag	= false;
		$rootScope.recentSearchViewFlag = false; 
		$timeout(function(){
			// Delete previously searched customer details
			if($rootScope.Newcustomer != undefined) {
				delete $rootScope.Newcustomer;
				delete $rootScope.customerId;
			}
			// Update Customer
			$rootScope.$broadcast('customerid', cust_id);
			$rootScope.$broadcast('showMainMenuTab', 1);
			// Update Vehicle Tab
			var getCustomerDetailsOnLoad = setInterval(function(){
				if($rootScope.Newcustomer != undefined) {
					angular.element($('[ng-controller="customerprofileController"]')).scope().setVehicleTab();
					clearInterval(getCustomerDetailsOnLoad);
				}
			}, 100);
		}, 300);
	}
	$scope.MergeCustomer = function(data) {
		$scope.merge_errMsg = $scope.diff_region_errMsg = '';
		if(data != undefined) {
			$scope.mergeCustomerData = data;
		} else {
			$scope.mergeCustomerData = $rootScope.Newcustomer;
		}
		$scope.mergeCustomerData.isEditable		= false;
		$scope.mergeCustomerData.errorMessage	= '';
		if(AuthenticationService.isCookieExist("cookie_userId")) {
			console.log("--Cookie available-- Merge Customer----"+$scope.mergeCustomerData.customerId)
			if($localStorage.mergedCustomers != undefined) {
				$scope.mergedCustomerIds = $localStorage.mergedCustomers;
			}
			if($scope.mergedCustomerIds.length < 10) {
				if($scope.mergedCustomerIds.indexOf($scope.mergeCustomerData.customerId) < 0) {
					// Scope variables
					$scope.mergedCustomerIds.push($scope.mergeCustomerData.customerId);
					$rootScope.mergeCustomerDetails.push($scope.mergeCustomerData);
					// Local Storage
					$localStorage.mergePurge		= angular.copy($rootScope.mergeCustomerDetails);
					$localStorage.mergedCustomers	= $scope.mergedCustomerIds;
					$rootScope.customAlertPopup("The customer has been added to the Merge Customer List.");
					var checkConfirmation = setInterval(function(){
						if($rootScope.isConfirmed == true) {
							clearInterval(checkConfirmation);
							$scope.checkForDifferentRegionCustomer('Add');
						}
					}, 100);
				} else {
					$rootScope.customAlertPopup("Customer has already been added to the Merge Customer List.");
				}
			} else {
				$rootScope.customAlertPopup("The number of candidate customers merged in Merge Purge process exceeded.");
			}
		} else {
			$scope.clearMergePurgeData();
		}		
	}
	$scope.removeMergedCustomer = function(customerId) {
		$scope.merge_errMsg = $scope.diff_region_errMsg = '';
		$timeout(function() {
			if(AuthenticationService.isCookieExist("cookie_userId")) {
				$rootScope.customAlertPopup("The customer record has been removed from the Merge Customer List.");
				var index = $localStorage.mergedCustomers.indexOf(customerId);
				if(index !== -1) {
					$localStorage.mergedCustomers.splice(index,1);
					$localStorage.mergePurge.splice(index,1);
					// Get details from local storage and assign to scope variable
					$rootScope.mergeCustomerDetails = $localStorage.mergePurge;
					$scope.mergedCustomerIds		= $localStorage.mergedCustomers;
					$timeout(function() { $("#merged_customer_ids").val($scope.mergedCustomerIds); }, 100);
					var checkConfirmation = setInterval(function(){
						if($rootScope.isConfirmed == true) {
							clearInterval(checkConfirmation);
							$scope.checkForDifferentRegionCustomer('Remove');
						}
					}, 100);
				}
			} else {
				$scope.clearMergePurgeData();
			}
		}, 100);
	}
	$scope.getMergePurgeData = function() {
		console.log("--------getMergePurgeData------------");
		console.log($localStorage.mergePurge);
		$rootScope.mergePurgeViewFlag	= !$rootScope.mergePurgeViewFlag;
		$scope.merge_errMsg = $scope.diff_region_errMsg = '';
		if(AuthenticationService.isCookieExist("cookie_userId")) {
			if($localStorage.mergePurge != undefined) {
				// Get details from local storage and assign to scope variable
				$rootScope.mergeCustomerDetails 	= angular.copy($localStorage.mergePurge);
				$scope.mergedCustomerIds			= $localStorage.mergedCustomers;
				$rootScope.survivorCustomerDetail	= $rootScope.mergeCustomerDetails[0];
				$scope.checkForDifferentRegionCustomer('List');
			}
			$timeout(function() { $("#merged_customer_ids").val($scope.mergedCustomerIds); }, 500);
		} else {
			$scope.clearMergePurgeData();
		}
		setMergePurgeContainer();
	}
	$scope.clearMergePurgeData = function() {
		$timeout(function() {
			console.log("--clear Local storage----")
			$scope.merge_errMsg = $scope.diff_region_errMsg = '';
			//$localStorage.$reset(); //delete all our data from localStorage
			if($localStorage.mergePurge != undefined) {
				delete $localStorage.mergePurge;
				delete $localStorage.mergedCustomers;
			}
			$rootScope.mergeCustomerDetails = [];
			$scope.mergedCustomerIds		= [];
			$timeout(function() { $("#merged_customer_ids").val(""); }, 500);
		},100);
	}
	$scope.setMergePurgeCustomerVehicle = function(event, customerId) {
		if($(event.target).hasClass('open')) {
			$(event.target).removeClass('open').addClass('close');
			$('#vehicle_info_'+customerId).show();
		} else {
			$(event.target).removeClass('close').addClass('open');
			$('#vehicle_info_'+customerId).hide();
		}
	}
	$scope.checkForDifferentRegionCustomer = function(action) {
		$scope.usDistributorFlag	= false;
		$scope.tdprDistributorFlag	= false;
		angular.forEach($rootScope.mergeCustomerDetails, function(value, key) {
			if(value.distributor == 'US') $scope.usDistributorFlag = true;
			else if(value.distributor == 'TDPR') $scope.tdprDistributorFlag = true;
		});		
		if($scope.usDistributorFlag && $scope.tdprDistributorFlag) {
			if(action == 'Add') {
				$scope.notifyUserForAcrossRegionCustomers();
			}
			$scope.diff_region_errMsg = "Customer profiles in different regions cannot be merged. Please add only customer profiles from the same region to proceed.";
		} else {
			$scope.diff_region_errMsg = '';
		}
	}
	$scope.validateMergeCustomersList = function() {
		$scope.merge_errMsg = '';
		$timeout(function() {
			var survivorId	= angular.element("input[name=survivorId]:checked").val();
			if($scope.mergedCustomerIds.length < 2) {
				$rootScope.customAlertPopup("You must select a minimum of 2 customers to merge.<br>You currently have 1 customer on the Merge Customer List.");
			} else if(survivorId == undefined){
				$scope.merge_errMsg = "Please choose the customer to be survived after Merge Purge";
				$('.merge-purge-container .ngscroll-container').css('marginTop','0px'); 
			} else {
				$scope.mergePurgeConfirmPopup();
			}
		},100);
	}
	$scope.notifyUserForAcrossRegionCustomers = function() {
		$scope.initialisePopupVariables();
		$rootScope.mergeAcrossRegionFlag = true;
		DealerviewPopup({
			id: 'simpleDialog',
			templateUrl:'views/confirmationPopup.html',
			title: '',
			backdrop: true,
			modalClass: "popup_container",
			css: {width: "470px" }
		});
	}
	$scope.mergePurgeConfirmPopup = function() {
		$scope.initialisePopupVariables();
		$rootScope.mergeConfirmationFlag = true;
		DealerviewPopup({
			id: 'simpleDialog',
			templateUrl:'views/confirmationPopup.html',
			title: '',
			backdrop: true,
			modalClass: "popup_container",
			css: {width: "470px" },
			success: {
				label: 'Success',
				fn: function() {
					$timeout(function() { $scope.getMergePurgeData(); }, 10);
					$scope.saveMergeCustomer();
				}
			},
			cancel: {
				label: 'Failure',
				fn: function() {
					$timeout(function() { $scope.getMergePurgeData(); }, 100);
				}
			}
		});
	}
	$scope.saveMergeCustomer = function() {
		$('.loader_outer, .loader_inner').show();
		var customerIds = angular.element("#merged_customer_ids").val();
		var survivorId	= angular.element("input[name=survivorId]:checked").val();
		survivorId		= (survivorId == undefined)? '': survivorId;
		var data = { "customerIds" : customerIds, "survivorId" : survivorId};
		$http.post('submitMergeCustomer.do', data).then(function (response) {
			$('.loader_outer, .loader_inner').hide();
			var result = response.data;
			if(result.status == "FAILURE") {
				$timeout(function() { 
					$scope.merge_errMsg = result.warning[0];
				}, 500);
			} else {
				$timeout(function() { 
					$scope.clearMergePurgeData();
					$scope.defaultInitialization();
					$scope.showCustomerDetails(result.customerId);
				}, 300);
			}
		}, function (response) {
			// Failure
		});
	}
	$scope.selectSurvivorCustomer = function(event, survivorObj){
		$("input[name=survivorId]").prop('checked', false);
		angular.element('#mp_customer_form_'+survivorObj.customerId+' input[name=survivorId]').prop('checked', true);
		angular.element('.highlight').removeClass("highlight");
		angular.element(event.target).parents('div.merge-wrapper').addClass('highlight');
		$rootScope.survivorCustomerDetail = survivorObj;
	}
	$scope.editMergePurgeDetails = function(custId) {
		$timeout(function() {
			console.log("------editMergePurgeDetails--------");
			var index = $localStorage.mergedCustomers.indexOf(custId);
			if(index !== -1) {
				angular.element('#merge_submit').hide();
				angular.element('#merge_disabled').show();
				// Get States
				CustomerUpdateService.getDropdownValues(custId).then(function(data){
					$scope.ddl = data;
					$scope.setStateDD(custId, 'onLoad');
				});
				// Format phone number
				if($rootScope.mergeCustomerDetails[index].phone != undefined) {
					angular.forEach($rootScope.mergeCustomerDetails[index].phone, function(value, key) {
						value.phoneType = (value.phoneType == '')? 'UNKNOWN' : value.phoneType;
						if(value.phoneNumber != '') {
							value.phoneNumber = $filter('telephone')(value.phoneNumber);
						}
					});
				}
				$rootScope.mergeCustomerDetails[index].isEditable = true;
			}
		}, 100);
	}
	$scope.setStateDD = function(custId, action) {
		var index = $localStorage.mergedCustomers.indexOf(custId);
		var temp_state = $rootScope.mergeCustomerDetails[index].address.state;
		$rootScope.mergeCustomerDetails[index].address.state = "";
		if($rootScope.mergeCustomerDetails[index].address.country == 'USA') {
			$scope.states = $scope.ddl.UsaStates;
		} else if($rootScope.mergeCustomerDetails[index].address.country == 'MEX') {
			$scope.states = $scope.ddl.MexStates;
		} else if($rootScope.mergeCustomerDetails[index].address.country == 'CAN') {
			$scope.states = $scope.ddl.CanStates;
		}
		$timeout(function() {
			if(temp_state != undefined && action == 'onLoad')
				$rootScope.mergeCustomerDetails[index].address.state = temp_state.toString();
		},50);
	}
	$scope.validateMergeCustomerForm = function(custId) {
		$('.loader_outer, .loader_inner').show();
		$('#cust_info_'+custId).find('.error_focus').removeClass('error_focus');
		$scope.addressFlag = $scope.phoneFlag = $scope.emailFlag = true;
		// Get Customer Details
		var index = $localStorage.mergedCustomers.indexOf(custId);
		if(index !== -1) {
			var custObj = $rootScope.mergeCustomerDetails[index];
			custObj.errorMessage = '';
		}
		/*
		 * Validation Begins
		 * checkBlank - If null or emtpy returns FALSE else TRUE;
		*/
		var customerType = angular.element('#mp-custType-'+custId).val();
		// Name
		if(customerType == 'PERSON') {
			if(ValidationService.checkBlank('mp-fname-'+custId)) {
				ValidationService.checkRegexp('mp-fname-'+custId, nameRegEx);
			}
			if(ValidationService.checkBlank('mp-lname-'+custId)) {
				ValidationService.checkRegexp('mp-lname-'+custId, nameRegEx);
			}
		} else {
			if(ValidationService.checkBlank('mp-organization-'+custId)) {
				if(ValidationService.checkRegexp('mp-organization-'+custId, orgNameExp)) {
					ValidationService.checkLengthof('mp-organization-'+custId, 'Organization Name', 2, 0);
				}
			}
		}
		// Address	
		if(ValidationService.getValueById('mp-address-'+custId) == '' && ValidationService.getValueById('mp-city-'+custId) == '' && ValidationService.getValueById('mp-state-'+custId) == '' && ValidationService.getValueById('mp-zipcode-'+custId) == '') {
			$scope.addressFlag = false;
		} else {
			if(ValidationService.getValueById('mp-address-'+custId) != '') {
				ValidationService.checkLengthof('mp-address-'+custId, 'Address Line 1', 2, 0);
			}
			if(ValidationService.getValueById('mp-city-'+custId) != '') {
				ValidationService.checkLengthof('mp-city-'+custId, 'City', 2, 0, 'customerPostalAddress_postalAddress_city_msg');
			}
		}
		// Email
		if(ValidationService.getValueById('mp-email-'+custId) == '') {
			$scope.emailFlag = false;
		} else {
			ValidationService.checkRegexp('mp-email-'+custId, emailExp, 'Email address');
		}
		// Phone
		if(ValidationService.getValueById('mp-phone-'+custId) == '' && ValidationService.getValueById('mp-alternate-'+custId) == '') {
			$scope.phoneFlag = false;
		} else {
			ValidationService.validatePhoneNumber('mp-phone-'+custId);
			ValidationService.validatePhoneNumber('mp-alternate-'+custId);
		}
		// Check Form is Valid or Not
		if($('#cust_info_'+custId).find('.error_focus').hasClass('error_focus')) {
			custObj.errorMessage = "Required Field(s) are Missing or Invalid.";
		}
		if($scope.addressFlag == false && $scope.emailFlag == false && $scope.phoneFlag == false) {
			if(custObj.errorMessage == '')
				custObj.errorMessage = 'Required Field Is Missing or Invalid. Please Provide Valid Address, Email or Phone.';
		}
		if(custObj.errorMessage == '') {
			// Custom Info Validation
			var submitFlag = $scope.isMergedCustomerInfoChanged(custId);
			if(submitFlag) {
				// Custom Form Submit
				$scope.submitMergePurgeCustomerForm(custId);
			} else {
				angular.element('.loader_outer, .loader_inner').hide();
			}
		} else {
			angular.element('.loader_outer, .loader_inner').hide();
		}
	}
	$scope.isMergedCustomerInfoChanged = function(custId) {
		var index = $localStorage.mergedCustomers.indexOf(custId);
		if(index !== -1) {
			var actualData	 = angular.copy($localStorage.mergePurge[index]);
			var modifiedData = $rootScope.mergeCustomerDetails[index];
			console.log(actualData);
			console.log(modifiedData);
			if(actualData.customerType == 'PERSON') {
				var haschanged = false;
				if(actualData.address == null) {
					if((actualData.customerFirstName.trim() != modifiedData.customerFirstName.trim().toUpperCase()) && (actualData.customerLastName.trim() != modifiedData.customerLastName.trim().toUpperCase()) && modifiedData.address.addressLine1) {
						haschanged = true;
					}
				} else if ((actualData.customerFirstName.trim() != modifiedData.customerFirstName.trim().toUpperCase()) && (actualData.customerLastName.trim() != modifiedData.customerLastName.trim().toUpperCase()) && (actualData.address.addressLine1.trim() != modifiedData.address.addressLine1.trim().toUpperCase())) {
					haschanged = true;
				}
				if(haschanged) {
					modifiedData.errorMessage = "You can only update two of following three fields per submission: First Name, Last Name, Address Line 1.";
					$("#mp-fname-"+custId+", #mp-lname-"+custId+", #mp-address-"+custId).addClass('error_focus');
					return false;
				}
			} else {
				var haschanged = false;
				if(actualData.address == null) {
					if((actualData.organizationName.trim() != modifiedData.organizationName.trim().toUpperCase()) && modifiedData.address.addressLine1) {
						haschanged = true;
					}
				} else if ((actualData.organizationName.trim() != modifiedData.organizationName.trim().toUpperCase()) && (actualData.address.addressLine1.trim() != modifiedData.address.addressLine1.trim().toUpperCase())) {
					haschanged = true;
				}
				if(haschanged) {
					modifiedData.errorMessage = "You can only update one of the following two fields per submission: Organization Name, Address Line 1.";
					$("#mp-organization-"+custId+", #mp-lname-"+custId+", #mp-address-"+custId).addClass('error_focus');
					return false;
				}
			}
			return true;
		}
	}
	$scope.cancelMergePurgeEdit = function(custId) {
		console.log('-----cancelMergePurgeEdit----------');
		$timeout(function() {
			if(AuthenticationService.isCookieExist("cookie_userId")) {
				angular.element('#customer_edit_'+custId).addClass('close');
				var index = $localStorage.mergedCustomers.indexOf(custId);
				if(index !== -1) {
					// Get master details from local storage and assign it back to scope variable
					$rootScope.mergeCustomerDetails[index] = angular.copy($localStorage.mergePurge[index]);
					$timeout(function() {
						if(angular.element('.editable').length == 0) {
							angular.element('#merge_submit').show();
							angular.element('#merge_disabled').hide();
						}
					}, 100);
				}
			} else {
				$scope.clearMergePurgeData();
			}
		}, 50);
	}
	$scope.submitMergePurgeCustomerForm = function(custId) {		
		var data = CustomerValidationService.serializeObject('mp_customer_form_'+custId);
		console.log(data);
		canceller = $q.defer();
		// mergePurgeEditProfile
		$http({ method: "POST", url: 'editProfile.do', data: data, timeout: canceller.promise }).then(function(response) {
			angular.element('.loader_outer, .loader_inner').hide();
			var result = response.data;
			console.log(result);
			//var result = {"warning":["Required Field Is Missing or Invalid", "Customer Postal Address set is null", "Address Line 1 contains invalid characters", "Zip Code contains invalid characters.  Please correct the zip code.", "We are unable to match the address entered against postal records. Please Verify that the address is correct."],"status":"FAILURE","customerId":null,"parentReload":null,"splitCustomer":null};
			var result = {"warning":["Address Line 1 contains invalid characters", "Zip Code contains invalid characters.  Please correct the zip code.", "We are unable to match the address entered against postal records. Please Verify that the address is correct."],"status":"FAILURE","customerId":null,"parentReload":null,"splitCustomer":null};
			var index = $localStorage.mergedCustomers.indexOf(custId);
			if(index !== -1) {
				var custObj = $rootScope.mergeCustomerDetails[index];
				custObj.errorMessage = '';
			}
			if(result.status == "SUCCESS") {
				NewCustomerInfoService.getNewCustomerDetails(custId, $rootScope.roleType).then(function(data){
					var updatedCustomerData = data;
					console.log(updatedCustomerData);
					// Update Lef Panel (Customer Details)
					if($rootScope.Newcustomer != undefined && $rootScope.customerId == custId) {
						$rootScope.Newcustomer = angular.copy(updatedCustomerData);
						if($rootScope.Newcustomer.customerType != 'BUSINESS'){
							$rootScope.customerName	=	$rootScope.Newcustomer.customerFirstName;
							if($rootScope.Newcustomer.customerMiddleName != null && $rootScope.Newcustomer.customerMiddleName != '')
								$rootScope.customerName	= $rootScope.Newcustomer.customerFirstName+' '+$rootScope.Newcustomer.customerMiddleName;
							
							if($rootScope.Newcustomer.customerLastName != null && $rootScope.Newcustomer.customerLastName != '')
								$rootScope.customerName	= $rootScope.customerName+' '+$rootScope.Newcustomer.customerLastName;
							
							if($rootScope.Newcustomer.salutation != null && $rootScope.Newcustomer.salutation != '')
								$rootScope.customerName	= $rootScope.Newcustomer.salutation+' '+$rootScope.customerName;
							if($rootScope.Newcustomer.nameSuffix != null && $rootScope.Newcustomer.nameSuffix != '')
								$rootScope.customerName	= $rootScope.customerName+' '+$rootScope.Newcustomer.nameSuffix;
						}
					}
					// Update merge purge details
					$rootScope.mergeCustomerDetails[index] = angular.copy(updatedCustomerData);
					$localStorage.mergePurge[index] = angular.copy($rootScope.mergeCustomerDetails[index]);
					// Update Recent Search details
					if($localStorage.recentlySearchedIds != undefined) {
						var rs_index = $localStorage.recentlySearchedIds.indexOf(custObj.customerId);
						if(rs_index !== -1) {
							// Updated data
							var tempCustomerData	= { "customerId":updatedCustomerData.customerId, "salutation":updatedCustomerData.salutation, "customerFirstName":updatedCustomerData.customerFirstName, "customerMiddleName":updatedCustomerData.customerMiddleName, "customerLastName":updatedCustomerData.customerLastName, "nameSuffix":updatedCustomerData.nameSuffix, "organizationName":updatedCustomerData.organizationName, "customerType":custObj.customerType, "distributor":updatedCustomerData.distributor, "address":updatedCustomerData.address, "email":updatedCustomerData.email, "phone":updatedCustomerData.phone };
							$localStorage.recentSearchHistory[rs_index].customerHistory = tempCustomerData;
						}
					}
					
				});
				custObj.isEditable = false;
				$timeout(function() {
					if(angular.element('.editable').length == 0) {
						angular.element('#merge_submit').show();
						angular.element('#merge_disabled').hide();
					}
				}, 100);
				$('#mp_editCustomerWarningCounter_'+custId).val(0);
				$('#mp_addNotConfirm_'+custId).val('');
				$('#mp_fdncAccepted_'+custId).val('');
				$('#mp_overridenFlag_'+custId).val('');
				$('#mp_canspamAccepted_'+custId).val('');
			} else {
				var errorMessage = (result.warning != '' && result.warning != null)? result.warning.toString() : '';
				if(result.warning != '' && result.warning != null)  {
					var index = result.warning.indexOf("We are unable to match the address entered against postal records. Please Verify that the address is correct.");
					if(index !== -1) {
						result.warning.splice(index,1);
					}
				}
				custObj.errorMessage = result.warning[0];
				CustomerValidationService.addressChanged(errorMessage, 1, custId);
			}
		});
	}
	// Begin: Get Merge Purge records Onload
	$scope.getMergePurgeData();
	$rootScope.mergePurgeViewFlag = false;
	// Ends: Get Merge Purge records Onload
	
	// End : Methods
	/************************** End : Merge Purge Module **************************/
}]);


/* ==============================================VehicleDetailsController================================================= */

TMSApp.controller('VehicleDetailsController', ['$scope', '$rootScope', '$compile', '$http', '$q', '$document', '$timeout', '$templateCache','DealerviewPopup','AdditionalvehiclPopup','VehicleOwnerService','SalesInfoService','AllVehicleService','VehicleDetailService','HistoryService','TelematicService','TfsProductService','PermissionPopup','HouseholdService','LoadDynamicTemplate','SecurityService', '$localStorage', function ($scope, $rootScope,$compile, $http, $q, $document, $timeout, $templateCache,DealerviewPopup,AdditionalvehiclPopup,VehicleOwnerService,SalesInfoService,AllVehicleService,VehicleDetailService,HistoryService,TelematicService,TfsProductService,PermissionPopup,HouseholdService,LoadDynamicTemplate,SecurityService, $localStorage) {
	console.log('--------------VehicleDetailsController---------------');
	$scope.security		= SecurityService;
	$scope.isAdminUser	= $scope.security.checkAccess('admin_view');
	// Get & Set Tab order
	$rootScope.defaultSortOrder	= [1,2,3,4,5,6,7];
	if($localStorage.tabOrder == undefined) {
		$http.get("getUserPreference.do").then(function(result) {
			$rootScope.vehicleTabOrder = result.data.userPreferenceOrder;
			if($rootScope.vehicleTabOrder != undefined && $rootScope.vehicleTabOrder != "") {
				$rootScope.tabOrder	= $rootScope.vehicleTabOrder.split(',').map(function(item) { return parseInt(item, 10); });
			} else {
				$rootScope.tabOrder	= angular.copy($rootScope.defaultSortOrder);
			}
			$localStorage.tabOrder =  angular.copy($rootScope.tabOrder);
		});
	} else {
		$rootScope.tabOrder =  angular.copy($localStorage.tabOrder);
	}
	console.log($rootScope.tabOrder);
	$rootScope.vehicleTabDetails =	{
										"1": { "id":"telematics_tab", "name": "Telematics", "hide": false, "classname": "norecord" },
										"2": { "id":"campaign_tab", "name": "Campaign", "hide": $scope.isVinView(), "classname": "norecord"},
										"3": { "id":"roadside_assistance_tab", "name": "Roadside Assistance", "hide": false, "classname": "norecord" },
										"4": { "id":"financial_product_tab", "name": "Financial Product", "hide": $scope.isVinView(), "classname": "norecord" },
										"5": { "id":"maintenance_plan_tab", "name": "Maintenance Plan", "hide": false, "classname": "norecord" },
										"6": { "id":"service_history_tab", "name": "Service History", "hide": false, "classname": "norecord" },
										"7": { "id":"mirai_swap_tab", "name": "Mirai Swap", "hide": (!($rootScope.brand == 'TOYOTA' || $rootScope.VehicleMakeModel.indexOf('TOYOTA') >= 0)), "classname": "norecord" }
									};

	$scope.showServiceHistory = function(count,triggerType) {
		if(count > 0) {	// Get Older Service History
			$('.loader_outer, .loader_inner').show();
		}
		$rootScope.$broadcast('ServiceHistoryClicked',count,triggerType);
	}
	$scope.$on('VehicleClicked', function(events,vin,modelyear,modelname,brand){
		console.log('------VehicleClicked--------'+vin+'------'+modelyear+'------'+modelname+'--------'+brand);
		if(!$(".loader_outer").is(":visible")) {
			$('.loader_outer, .loader_inner').show();
		}
		$scope.printFlag		= false;
		$scope.printBtnFlag		= true;
		$scope.optionsFlag		= false;
		$scope.setDefaultSortOrder('PurchaseDate','DisposedDate');
		$scope.setDefaultPagingValue();
		$rootScope.vin			= vin;
		$rootScope.selectedVin	= vin;
		$rootScope.modelyear	= modelyear;
		$rootScope.modelname	= modelname;
		$rootScope.brand		= brand;

		// Vehicle Details & Additional Vehicle Details
		console.log($rootScope.customerId);
		var cust_id = ($rootScope.customerId != undefined)? $rootScope.customerId: '';
		$rootScope.VehicleDetails = {};
		VehicleDetailService.getBasicVehicleInfoDetails(vin).then(function(data){	
			var response_data = data;
			$rootScope.VehicleDetails.vehicleInfo = response_data;
		});
		//if(cust_id != '') {
			VehicleDetailService.getVINInfoDetails(cust_id,vin).then(function(data){	
				var response_data = data;
				$rootScope.VehicleDetails.vinInfo = response_data;
				$rootScope.modelyear	= response_data.ModelYear;
				$rootScope.modelname	= response_data.VehModelName;
				$rootScope.brand		= response_data.Make;
				$rootScope.modelcode	= response_data.ModelCd;
				$rootScope.vehicleTabDetails[7].hide = (!($rootScope.brand == 'TOYOTA' || $rootScope.VehicleMakeModel.indexOf('TOYOTA') >= 0));
				$timeout(function() { $('.loader_outer, .loader_inner').hide(); }, 500);
			});
		//}
		VehicleDetailService.getMSRPInfoDetails(vin).then(function(data){	
			var response_data = data;
			$rootScope.VehicleDetails.MSRPInfo = response_data;
		});
		VehicleDetailService.getProductionInfoDetails(vin).then(function(data){	
			var response_data = data;
			$rootScope.VehicleDetails.prdtInfo = response_data;
		});
		VehicleDetailService.getRetailSaleInfoDetails(vin).then(function(data){	
			var response_data = data;
			$rootScope.VehicleDetails.salesInfo = response_data;
			if($rootScope.VehicleDetails.salesInfo.ReacquiredVehicle == 'Yes' && $rootScope.reAcquireFlag) {
				$scope.ReAcquireVehiclepopup();
				$rootScope.reAcquireFlag = false;
			}
		});
		// Update Preferred Dealer
		$scope.changeDealerFlag = false;
		$scope.setChangePreferDealer = function() {
			$scope.errMsg = '';
			$scope.prefDealer = {"code":""};
			$scope.successFlag = false;
			$scope.changeDealerFlag = !$scope.changeDealerFlag;
		}
		$scope.submitPreferredDealer = function() {
			var dealerCd	= $scope.prefDealer.code;
			var regEx		= /^[0-9]+$/i;
			if(dealerCd != null && dealerCd != '') {
				if(regEx.test(dealerCd)) {
					if(dealerCd.length == 5){
						var dealerCdInt = parseInt(dealerCd,10);
						if(dealerCdInt != 0){
							//$scope.successFlag = true;
							$scope.updatePreferredDealer(vin,cust_id,dealerCd);
						} else {
							$scope.errMsg = 'Invalid Dealer Code.';
						}
					} else {
						$scope.errMsg = 'Dealer Code must be five characters.';
					}
				} else {
					$scope.errMsg = 'Dealer Code is invalid. It must be a numeric code only.';
				}
			} else {
				$scope.errMsg = 'You must provide a Dealer Code to update Preferred Dealer. Dealer Code field is empty.';
			}
		};
		$scope.updatePreferredDealer = function(vin,cust_id,dealerCd) {
			VehicleDetailService.updatePreferredDealerCode(vin,cust_id,dealerCd).then(function(data){
				if(data == 'Success') {
					VehicleDetailService.getVINInfoDetails(cust_id,vin).then(function(data){	
						var response_data = data;
						$rootScope.VehicleDetails.vinInfo = response_data;
						$scope.successFlag = true;
					});
				} else {
					$scope.errMsg = 'Problem in Update Dealer Code.';
				}
			});
		}
		// Vehicle Owner History
		VehicleOwnerService.getVehicleownerDetails(vin).then(function(data){
			var response_data = data;
			$rootScope.Vehicleownership = response_data.vehicleOwnership;
		});
		// Telematics Product Details
		TelematicService.getTelematicsProductDetails(vin).then(function(data){
			$scope.mobileFlag = $scope.vhrEnabledLinkFlag = $scope.vhrDisabledLinkFlag = $scope.lpsEnabledLinkFlag = $scope.lpsDisabledLinkFlag = false;
			var response_data = data;
			var response_data = {"buyBackDate":null,"buyBackIndicator":null,"enformInd":null,"safetyInd":true,"meId":"MEID-A1000004A4D1F5","meIdInd":"Y","accStatus":"Not Enrolled","optedIn":null,"edoptedIn":"N","transmitting":"Y","edCapableIndicator":"Y","edLiteOrLitePlusIndicator":" (Lite)","veh":null,"vhrEnbFlg":false,"size":null,"brand":null,"spareTireBrand":null,"keyoffCapableIndicator":"Y","remoteCustomeFlag":"N","brriDisplayCtlActivationInd":"Y","brriErDisplayCtlActivationInd":"N","csCapable":"Y","scoutCapable":false,"headUnit":"LEXUS PREMIUM NAVIGATION CY13","headUnitType":"X08","mobileAppCapableLink":"https://c360.qa.toyota.com/be/admin/accountSearch.do","uieLinkURL":"https://c360.qa.toyota.com/csrp/admin/accountSearch.do","imEI":null,"activeRemoteUserExist":true};
			$rootScope.telematicsDetails = response_data;
			// Mobile App Account Status 
			if(!$rootScope.telematicsDetails.scoutCapable && $rootScope.telematicsDetails.headUnitType != null && $rootScope.telematicsDetails.headUnitType != '' && $rootScope.telematicsDetails.headUnitType != "Error retrieving data"){
				$scope.mobileFlag = true;
			}
			// Vehicle Health Report
			if($rootScope.telematicsDetails.edCapableIndicator == 'Y' && $rootScope.telematicsDetails.edoptedIn == 'Y' && $rootScope.telematicsDetails.brriDisplayCtlActivationInd == 'Y' && $rootScope.telematicsDetails.vhrEnbFlg) {
				$scope.vhrEnabledLinkFlag = true;
			} else if($rootScope.telematicsDetails.brriDisplayCtlActivationInd == 'Y') {
				$scope.vhrDisabledLinkFlag = true;
			}
			// LPS Setting
			if($rootScope.telematicsDetails.keyoffCapableIndicator == 'Y' && $rootScope.telematicsDetails.optedIn == 'Y' && $rootScope.telematicsDetails.brriErDisplayCtlActivationInd == 'Y' && $rootScope.telematicsDetails.remoteCustomeFlag =='Y' && $rootScope.telematicsDetails.activeRemoteUserExist){
				$scope.lpsEnabledLinkFlag = true;
			} else if($rootScope.telematicsDetails.brriErDisplayCtlActivationInd == 'Y') {
				$scope.lpsDisabledLinkFlag = true;
			}
		});
		// Telematic Product Enrollment
		TelematicService.getTelematicProductEnrollmentSummary(vin).then(function(data){
			var response_data = data;
			$rootScope.telematicsEnroll = response_data.telematicsProductList;
			$rootScope.printTelematicsEnroll = response_data;
			if($rootScope.telematicsEnroll != null && $rootScope.telematicsEnroll.length != 0 && $rootScope.telematicsEnroll[0].subscriptionDetails.length != 0) {
				$rootScope.vehicleTabDetails[1].classname = 'hasrecord';
			}			
		});
		// Telematic Ownership History
		$rootScope.primCustId = '';
		if($scope.isAdminUser) {
			TelematicService.getTelematicOwnershipSummary(vin).then(function(data){
				var response_data = data;
				var response_data = {"telematicOwnershipHistory":[{"ContractNo":"1-1DEBBZA","Product":"Safety Connect","PlanStatus":"Not Enrolled","OrganizationName":"","Salutation":"","CustomerFirstName":"JUDITH","CustomerLastName":"MANKEVICH","CustomerMiddleName":"","Role":"PRIMARY SUBSCRIBER","StartDate":"07/09/2012","NameSuffix":"","EndDate":"06/06/2013","CustomerId":"5281681","SerializedProductId":"79395792","CustomerProductAssocId":"110019673","distributor":"TDPR"}, {"ContractNo":"1-1DEBBZA","Product":"Safety Connect","PlanStatus":"Not Enrolled","OrganizationName":"","Salutation":"","CustomerFirstName":"JUDITH","CustomerLastName":"MANKEVICH","CustomerMiddleName":"","Role":"PRIMARY SUBSCRIBER","StartDate":"07/09/2012","NameSuffix":"","EndDate":"06/06/2013","CustomerId":"5281681","SerializedProductId":"79395792","CustomerProductAssocId":"110019673","distributor":"US"}],"userRole":["C360_ADMIN","C360_CUSTOMER_ADMIN_UPDATER","C360_CUSTOMER_ADMIN_VIEWER","C360_DISTRIBUTOR_US","C360_ENROLLED","C360_LEXUSMKTG","C360_SCIONCR","C360_SCIONMKTG","C360_SCIONPR","C360_TOYOTACR","C360_TOYOTAMKTG","C360_TOYOTAPR"]};
				$rootScope.telematicsOwners = response_data.telematicOwnershipHistory;
				if($rootScope.telematicsOwners != null && $rootScope.telematicsOwners.length != 0) {
					$rootScope.vehicleTabDetails[1].classname = 'hasrecord';
				}
				$rootScope.printTelematicsOwners = response_data;
				// Find 1st Primary Subscriber
				if($rootScope.telematicsOwners != null) {
					$rootScope.telematicsOwners.some(function (value, index) {
						if(value.Role == 'PRIMARY SUBSCRIBER'){
							$rootScope.primCustId = value.CustomerId;
							return true;
						}
					});
				}
			});
		}
		// Update Telematic Ownership History
		$scope.updateTelematicOwnershipHistory = function(custId) {
			$('#telematics_noti_element_'+custId+', .success, .failed').hide();
			$('#noti_update_'+custId).hide();
			$('#noti_updating_'+custId).show();
			canceller = $q.defer();
			var data = {
							"edCustomerId": custId,
							"edVin": $rootScope.vin,
							"isMAINTEmail": angular.element('#main_email_'+custId).val(),
							"isMAINTMobAppPushNotification": angular.element('#main_mobapp_'+custId).val(),
							"isMAINTPhoneByDealer": angular.element('#main_phone_'+custId).val(),
							"isVHREmail": angular.element('#vhr_email_'+custId).val(),
							"isVHRMobAppPushNotification": angular.element('#vhr_mobapp_'+custId).val()
						}
			$http({ method: "POST", url: "updateEnformNotificationDetails.do", data: data, timeout: canceller.promise }).then(function(response) {
				$('#noti_update_'+custId).show();
				$('#noti_updating_'+custId).hide();
				console.log(response);
				var result = response.data;
				if(result.status != 'FAILURE') {
					$('#telematics_noti_element_'+custId+', .success').show();
					$('#telematics_noti_element_'+custId).find('th div:first').addClass('successbar');
				} else {
					$('#telematics_noti_element_'+custId+', .failed').show();
					$('#telematics_noti_element_'+custId).find('th div:first').addClass('errorbar');
				}
			}).catch(function(data, status){
				// catch exceptopn
			});
		}
		// TFS Product Summary
		TfsProductService.getTfsProductSummary(vin).then(function(data){
			$scope.lexDis = false;
			$scope.toyDis = false;
			var response_data = data;
			$rootScope.tfsDetails = response_data;
			$rootScope.tfsDetails = [{"type":"CERT","expirationDate":"12/15/2016","expirationMileage":"100,000","tfsPrdtDetails":{"type":"CERT","subType":"WARRANTY","id":"0013960364","planCd":"MPJ","productStatus":"Approved and Issued","effectiveDate":"12/15/2009","expirationDate":"12/15/2016","expirationMileage":"100,000","make":"TOYOTA","makeDisclaimer":"TOYOTA","model":"PRIUS","modelYear":"2010","customerFName":"ANN","customerLName":"BAILEY","customerMName":"","customerSuffix":"","customerSalutation":"","customerId":"44299507","sellingDealerName":"MICHAEL'S TOY OF BELLEVUE","sellingDealerCode":"46050","customerType":"PERSON","organizationName":"","distributor":"US","tfsServiceDesc":null}},{"type":"TAC","expirationDate":"01/05/2014","expirationMileage":"55,000","tfsPrdtDetails":{"type":"TAC","subType":"PREMIUM","id":"0012897659","planCd":"SA3","productStatus":"Cancelled","effectiveDate":"01/05/2010","expirationDate":"01/05/2014","expirationMileage":"55,000","make":"TOYOTA","makeDisclaimer":"TOYOTA","model":"PRIUS","modelYear":"2010","customerFName":"","customerLName":"","customerMName":"","customerSuffix":"","customerSalutation":"","customerId":"","sellingDealerName":"BURIEN TOYOTA","sellingDealerCode":"46076","customerType":"","organizationName":"","distributor":"","tfsServiceDesc":[]}},{"type":"CERT","expirationDate":"11/21/2010","expirationMileage":"10,901","tfsPrdtDetails":{"type":"CERT","subType":"WARRANTY","id":"0013960365","planCd":"MPK","productStatus":"Approved and Issued","effectiveDate":"08/21/2010","expirationDate":"11/21/2010","expirationMileage":"10,901","make":"TOYOTA","makeDisclaimer":"TOYOTA","model":"PRIUS","modelYear":"2010","customerFName":"ANN","customerLName":"BAILEY","customerMName":"","customerSuffix":"","customerSalutation":"","customerId":"44299507","sellingDealerName":"MICHAEL'S TOY OF BELLEVUE","sellingDealerCode":"46050","customerType":"PERSON","organizationName":"","distributor":"TDPR","tfsServiceDesc":null}}];
			if($rootScope.tfsDetails != null && $rootScope.tfsDetails.length != 0) {
				$rootScope.vehicleTabDetails[4].classname = 'hasrecord';
			}
			angular.forEach($rootScope.tfsDetails, function(value, key) {
				if(value.tfsPrdtDetails.type == 'CERT' && value.tfsPrdtDetails.makeDisclaimer == 'LEXUS') {
					$scope.lexDis = true;
				}
				if(value.tfsPrdtDetails.type == 'CERT' && value.tfsPrdtDetails.makeDisclaimer == 'TOYOTA') {
					$scope.toyDis = true;
				}
			});
		});
		$rootScope.$broadcast('showDetailsMenuTab', 1);
		$('#scrollforcustprofil').scrollTop(0);
		// Service History - auto trigger
		$scope.showServiceHistory(0,'auto'); 
		// VHR
		$rootScope.filters =	[	
									{name : "All", value : ""},
									{name : "On-Demand", value : "On-Demand"},
									{name : "Scheduled", value : "Scheduled"},
									{name : "Event", value : "Event"}
								];
		$rootScope.selectedVHR = "";
		// Begin : VHR Info Popup
		$scope.VHRInfoPopup = function(){
			$('.vhrInfoPopup, .ownerpopup-backdrop').remove();
			$rootScope.vhrStatus = '';
			$rootScope.vhrVin	= vin;
			$scope.vhrCustId	= cust_id;
			TelematicService.getVHRSummary($rootScope.vhrVin,$scope.vhrCustId,$rootScope.primCustId).then(function(data){
				$rootScope.vhrInfo = {"CustomerId":null,"VHRId":null,"NotificationMailId":null,"MailStatus":null,"VHRDataList":[{"VHRID":"830ef3f4-cb19-4b1e-9458-4d96f5fcfd9c","VHRGenerationTime":"08/04/2016 00:49 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Aug 042016","EventTypeImageUrl":null,"VHRGenerationType":"Customer","VHRGeneratorID":"120100373_136390","VHRGenerationName":"LCCS/JOHNSON LEXUS OF","VHRTypeImageUrl":null,"EventType":"","VHRDate":1470322183000},{"VHRID":"f01021a2-6a1b-4fcc-bd59-26fd35e51020","VHRGenerationTime":"08/04/2016 00:43 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Aug 042016","EventTypeImageUrl":null,"VHRGenerationType":"Dealer","VHRGeneratorID":"24022_353632268","VHRGenerationName":"SEEGER TOYOTA","VHRTypeImageUrl":null,"EventType":"","VHRDate":1470321793000},{"VHRID":"4adfbf37-7bcb-4da8-a764-4b6bf2d5c1bc","VHRGenerationTime":"08/04/2016 00:07 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Aug 042016","EventTypeImageUrl":null,"VHRGenerationType":"TQSS","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1470319675000},{"VHRID":"bb968767-7ca2-4aba-93bc-48c71626b5aa","VHRGenerationTime":"08/04/2016 00:03 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Aug 042016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1470319398000},{"VHRID":"8ca87796-2c5b-4c29-9cdc-451d7b8f0891","VHRGenerationTime":"08/04/2016 00:02 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Aug 042016","EventTypeImageUrl":null,"VHRGenerationType":"LCAC","VHRGeneratorID":"136390","VHRGenerationName":"CSR","VHRTypeImageUrl":null,"EventType":"","VHRDate":1470319363000},{"VHRID":"c619315d-3a4b-4992-9801-5444edc31cff","VHRGenerationTime":"08/04/2016 00:01 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Aug 042016","EventTypeImageUrl":null,"VHRGenerationType":"LCAC","VHRGeneratorID":"136390","VHRGenerationName":"CSR","VHRTypeImageUrl":null,"EventType":"","VHRDate":1470319316000},{"VHRID":"2a2106ce-02b9-45da-895d-de569714f985","VHRGenerationTime":"08/04/2016 00:01 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Aug 042016","EventTypeImageUrl":null,"VHRGenerationType":"Customer360","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1470319290000},{"VHRID":"a7860af9-8173-4592-a137-f3a0398a8e0e","VHRGenerationTime":"08/03/2016 02:52 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Aug 032016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"135738","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1470243135000},{"VHRID":"52687873-44ec-4fc6-ad77-451d54d6283b","VHRGenerationTime":"08/03/2016 02:50 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Aug 032016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1470243045000},{"VHRID":"5c6e2060-1427-4713-8cb3-02e393b199f2","VHRGenerationTime":"07/29/2016 04:21 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 292016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469816481000},{"VHRID":"79274d5f-4e0e-42da-be1e-7fecf1d3af88","VHRGenerationTime":"07/28/2016 06:16 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 282016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469736972000},{"VHRID":"3a60ddf1-be2b-4c4d-9214-0faef9c9a6bc","VHRGenerationTime":"07/28/2016 06:15 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 282016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469736944000},{"VHRID":"940058d5-082b-4b83-bf55-4299b29eb99b","VHRGenerationTime":"07/27/2016 02:31 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 272016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"KMCECTOYOTA2","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469637105000},{"VHRID":"98f89129-700b-4877-a660-afae6790fc93","VHRGenerationTime":"07/27/2016 02:18 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 272016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"135738","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469636309000},{"VHRID":"982069d1-a810-4d86-bcf0-0ec7f95cd9ec","VHRGenerationTime":"07/26/2016 23:18 PM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469625482000},{"VHRID":"767787f3-b871-4691-8968-64a59c58f3e6","VHRGenerationTime":"07/26/2016 23:10 PM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"135738","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469625032000},{"VHRID":"1ff1c475-b7fe-40eb-81a4-4be88da1130c","VHRGenerationTime":"07/26/2016 23:09 PM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469624954000},{"VHRID":"ed8e2ace-e892-45e6-8450-c281d4e99802","VHRGenerationTime":"07/26/2016 23:08 PM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469624938000},{"VHRID":"ae4cb062-e553-43ea-9dd1-0eb99047ed78","VHRGenerationTime":"07/26/2016 23:07 PM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"135738","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469624874000},{"VHRID":"c95403b2-656c-4f2f-a424-55aff3277d83","VHRGenerationTime":"07/26/2016 22:56 PM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"LCAC","VHRGeneratorID":"136390","VHRGenerationName":"CSR","VHRTypeImageUrl":null,"EventType":"","VHRDate":1469624161000},{"VHRID":"e69a8b90-94ef-4ced-ae69-ed9b658e94c3","VHRGenerationTime":"07/26/2016 22:01 PM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"135738","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469620903000},{"VHRID":"c788d27b-87e9-4993-8281-e78cef4ae25a","VHRGenerationTime":"07/26/2016 22:01 PM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"135738","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469620902000},{"VHRID":"f437e658-af75-422d-930b-bd6a205f64df","VHRGenerationTime":"07/26/2016 07:52 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"LCAC","VHRGeneratorID":"136390","VHRGenerationName":"CSR","VHRTypeImageUrl":null,"EventType":"","VHRDate":1469569933000},{"VHRID":"0d3097ec-855d-49b2-9079-46e7225a5640","VHRGenerationTime":"07/26/2016 07:38 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"135738","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469569112000},{"VHRID":"061d0138-421d-462e-af06-72822476ad54","VHRGenerationTime":"07/26/2016 05:38 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"135738","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469561908000},{"VHRID":"41c043c2-58b8-44b3-9e99-6e7eda686f59","VHRGenerationTime":"07/26/2016 05:33 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469561583000},{"VHRID":"e7176298-8637-4550-ad90-64c89e76a526","VHRGenerationTime":"07/26/2016 04:07 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469556473000},{"VHRID":"55c63b1e-4c8a-44b8-a6b3-05614ba4d964","VHRGenerationTime":"07/26/2016 04:07 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469556471000},{"VHRID":"2d849e24-048a-4344-9b07-85e65408f347","VHRGenerationTime":"07/26/2016 04:06 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"135738","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469556378000},{"VHRID":"62ec4aab-1e49-4d6b-9698-679a5f02213f","VHRGenerationTime":"07/26/2016 04:05 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"135738","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469556323000},{"VHRID":"59cbfd57-44a6-48f0-84b6-5fe2ce29dfac","VHRGenerationTime":"07/26/2016 04:03 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"135738","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469556210000},{"VHRID":"5dd9b77d-d775-40d6-b0d6-b2146b645cba","VHRGenerationTime":"07/26/2016 04:03 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 262016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"135738","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469556199000},{"VHRID":"31c0a431-ed6f-476f-92e4-e086be431c33","VHRGenerationTime":"07/25/2016 06:48 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 252016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"KMCECTOYOTA2","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469479684000},{"VHRID":"248f5312-0138-43e2-96d8-b57cb70c4f88","VHRGenerationTime":"07/25/2016 06:47 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 252016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"KMCECTOYOTA2","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469479666000},{"VHRID":"5e7ef8c3-be7a-4037-9eec-d99d7a1d08e2","VHRGenerationTime":"07/21/2016 04:56 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 212016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469127371000},{"VHRID":"e2630885-2e55-4caf-ae69-c29b93859118","VHRGenerationTime":"07/21/2016 04:54 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 212016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469127299000},{"VHRID":"cb8e00e9-73c8-4375-b2f9-e5f05db3875a","VHRGenerationTime":"07/20/2016 07:09 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 202016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469048970000},{"VHRID":"b837ef42-22be-4630-a023-023ec9650672","VHRGenerationTime":"07/20/2016 07:08 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 202016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469048911000},{"VHRID":"c524aa4a-ff4f-4f53-ba12-08e5e8869fe1","VHRGenerationTime":"07/20/2016 07:08 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 202016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469048888000},{"VHRID":"e1785ef4-92d5-46a3-bd2a-f2632737ba6e","VHRGenerationTime":"07/20/2016 06:59 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 202016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469048343000},{"VHRID":"67e697ea-9369-4bbe-8f58-0218d6e71b41","VHRGenerationTime":"07/20/2016 06:58 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 202016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1469048319000},{"VHRID":"79a6d671-64a5-4068-a0b3-e6242a8240ef","VHRGenerationTime":"07/15/2016 04:17 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 152016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1468606662000},{"VHRID":"25120f4e-4889-445a-8e5f-e02bd321719e","VHRGenerationTime":"07/13/2016 07:55 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 132016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER360","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1468446943000},{"VHRID":"8a250c37-4943-4842-b526-7710a3d85b24","VHRGenerationTime":"07/13/2016 07:51 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 132016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1468446683000},{"VHRID":"49ec1dd6-1926-468e-8b15-a007171698cd","VHRGenerationTime":"07/13/2016 07:49 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 132016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1468446553000},{"VHRID":"9ee10d08-589f-4ffd-a87c-4a208b14298b","VHRGenerationTime":"07/12/2016 02:35 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 122016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1468341327000},{"VHRID":"c4df2cc4-4476-44d8-b1a1-4902c65dff9a","VHRGenerationTime":"07/12/2016 02:34 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 122016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1468341274000},{"VHRID":"a0bf6aee-7b88-440e-8eb0-b91ecf9013a1","VHRGenerationTime":"07/12/2016 02:03 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 122016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1468339414000},{"VHRID":"65193f4b-fff0-4773-907a-3f39e8653c34","VHRGenerationTime":"07/11/2016 23:44 PM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 112016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1468331087000},{"VHRID":"b1d0ba65-32e3-4a78-bf04-cbaa8d8b1ad3","VHRGenerationTime":"07/11/2016 05:47 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 112016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1468266426000},{"VHRID":"d927e334-2b2e-40d2-9efb-8eefa4d75a54","VHRGenerationTime":"07/06/2016 06:33 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 062016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1467837181000},{"VHRID":"63dff605-bb72-4672-89d3-169456b77765","VHRGenerationTime":"07/06/2016 04:20 AM PST","VHRType":"On-Demand","VHRFileName":"VHR ES 300H Jul 062016","EventTypeImageUrl":null,"VHRGenerationType":"CUSTOMER CENTRAL","VHRGeneratorID":"136390","VHRGenerationName":null,"VHRTypeImageUrl":null,"EventType":"","VHRDate":1467829213000},{"VHRID":"756af81c-32f8-4f65-9bf8-0e9ef7ecc8df","VHRGenerationTime":"05/26/2016 01:00 AM PST","VHRType":"Scheduled","VHRFileName":"VHR ES 300H May 262016","EventTypeImageUrl":null,"VHRGenerationType":"System","VHRGeneratorID":"","VHRGenerationName":"","VHRTypeImageUrl":null,"EventType":"","VHRDate":1464274819000},{"VHRID":"8c68b5e1-a630-4b30-9dd9-49f4a976b6f7","VHRGenerationTime":"03/20/2016 23:48 PM PST","VHRType":"Event","VHRFileName":"VHR ES 300H Mar 202016","EventTypeImageUrl":"https://tmsappqstorage01.blob.core.windows.net/web/LEX_BRRI_VHR_maintenance.png","VHRGenerationType":"System","VHRGeneratorID":"","VHRGenerationName":"","VHRTypeImageUrl":null,"EventType":"Maintenance","VHRDate":1458568103000},{"VHRID":"3176e306-b990-44d5-bb62-4f49f520a1b5","VHRGenerationTime":"03/11/2016 03:13 AM PST","VHRType":"Event","VHRFileName":"VHR ES 300H Mar 112016","EventTypeImageUrl":"https://tmsappqstorage01.blob.core.windows.net/web/LEX_BRRI_VHR_vehicle_alert.png","VHRGenerationType":"System","VHRGeneratorID":"","VHRGenerationName":"","VHRTypeImageUrl":null,"EventType":"MIL-ON","VHRDate":1457723635000}],"ErrorMsg":null,"ActiveCustomerList":[{"CustomerId":11229815,"FirstNm":null,"LastNm":null,"EmailNotification":null,"EmailAddressRole":null,"PhoneNo":null,"AreaCd":null,"PhoneRole":null,"AddressLine1":null,"City":null,"StateProvinceCd":null,"PostalCd":null,"CustomerName":"ELIZABETH A BROWN "}]};
			});
			var popup_ht = ($rootScope.primCustId != '')? '560px' : '355px';
			DealerviewPopup({
				id: 'simpleDialog',
				templateUrl:'views/vhrInfoPopup.html',
				title : '',
				backdrop : true,
				modalClass : "vhrInfoPopup",
				css: {maxHeight : popup_ht },
				success: {label: 'Success', fn: function() {console.log('Inline modal closed');}}
			});
		};
		// End : VHR Info Popup
		// Owner Notification Summary
		$scope.setOwnerNotification = function() {
			VehicleDetailService.getOwnerNotificationSummary(vin).then(function(data){
				var response_data = data;
				$rootScope.OwnerNotificationDetails = response_data;
				if($rootScope.OwnerNotificationDetails != null && $rootScope.OwnerNotificationDetails.length != 0) {
					$rootScope.vehicleTabDetails[2].classname = 'hasrecord';
				}
			});
		}
		$scope.copyToClipboard = function(event) {
			//var copyText = $(event.target).parents('td').find('a').attr('href');
			//var copyText = $(event.target).parents('td').find('a span.copy').text().replace(/\t/g,'');
			var copyText = $(event.target).parents('td').find('span.copy').text().replace(/\t/g,'');
			console.log(copyText);
			var textareaElem = $('<textarea/>');
			textareaElem.text(copyText);
			$('body').append(textareaElem);
			textareaElem.select();
			document.execCommand('copy', true);
			textareaElem.remove();
		}
		
		$scope.setOwnerNotification();
		// RoadSide Assistance Summary
		$scope.setRoadSideAssistance = function() {
			VehicleDetailService.getRoadSideAssistanceSummary(vin).then(function(data){
				var response_data = data;
				$rootScope.RoadSideAssistanceDetails = response_data;
				if($rootScope.RoadSideAssistanceDetails != null && $rootScope.RoadSideAssistanceDetails.length != 0) {
					$rootScope.vehicleTabDetails[3].classname = 'hasrecord';
				}
			});
		}
		$scope.setRoadSideAssistance();
		// Toyota Care Summary
		$scope.setToyotaCare = function() {
			VehicleDetailService.getToyotaCareUrl(vin).then(function(data){
				var response_data = data;
				$rootScope.ToyotaCareUrl = response_data;
			});
			VehicleDetailService.getToyotaCareSummary(vin).then(function(data){
				var response_data = data;
				$rootScope.ToyotaCareDetails = response_data;
				if($rootScope.ToyotaCareDetails!= null && $rootScope.ToyotaCareDetails.toyotacareList.length != 0 && ($rootScope.ToyotaCareDetails.toyotacareList[0].servIntrvlDesc != null || $rootScope.ToyotaCareDetails.toyotacareList[0].status != null || $rootScope.ToyotaCareDetails.toyotacareList[0].opcode != null || $rootScope.ToyotaCareDetails.toyotacareList[0].servicingDealer != null || $rootScope.ToyotaCareDetails.toyotacareList[0].dateServiced != null || $rootScope.ToyotaCareDetails.toyotacareList[0].mileage != null)) {
					$rootScope.vehicleTabDetails[5].classname = 'hasrecord';
				}
			});
		}
		$scope.setToyotaCare();
		// Mirai Swap Summary
		$scope.setMiraiSwap = function() {
			VehicleDetailService.getMiraiSwapSummary(vin).then(function(data){
				var response_data = data;
				$rootScope.MiraiSwapDetails = response_data;
				if($rootScope.MiraiSwapDetails != null && $rootScope.MiraiSwapDetails.ErrorMsg == null) {
					$rootScope.vehicleTabDetails[7].classname = 'hasrecord';
				}
			});
		}
		$scope.setMiraiSwap();
		// Set Default Vehicle Tab
		var setVehicleDefaultTab = setInterval(function(){
			if($('#sortable').length != 0) {
				angular.element($('#vehicleData')).scope().setTab($rootScope.tabOrder[0]);
				clearInterval(setVehicleDefaultTab);
			}
		}, 300);
		$scope.openPrintOptions = function(event) {
			$scope.printFlag = !$scope.printFlag;
			setPrintContainer();
			$scope.optionsFlag		= true;
			$scope.printBtnFlag		= true;
			$scope.custInfoDisFlag	= false;
			angular.element('#printPdfForm input[type="checkbox"]').prop('checked', true);
			angular.element('#add_vehicle, #cust_info, #tfs_prdt, #telematics_info').prop('checked', false);
			angular.element('#printPdfForm #short_form').prop('checked', true);
		}
		$scope.custInfoDisclaimer = function() {
			$scope.custInfoDisFlag = !$scope.custInfoDisFlag;
		}
		$scope.openServiceHistoryOptions = function() {
			if($('#printPdfForm #service_history').is(':checked')) {
				$scope.optionsFlag = !$scope.optionsFlag;
				setPrintContainer();
			} else {
				$scope.optionsFlag = false;
			}
		}
		angular.element('#printPdfForm input[type="checkbox"]').bind( "click", function() {
			if(!$('#printPdfForm input[type="checkbox"]').is(':checked')) {
				$scope.printBtnFlag = false;
			} else {
				$scope.printBtnFlag = true;
			}
		});
		$timeout(function(){ setScrollViewport(); }, 700);
	});
	
	$scope.$on('HouseholdClicked', function(events){
		console.log('------HouseholdClicked--------');
		$('#householdView').scrollTop(0);
		var custId = $rootScope.customerId;
		$scope.setDefaultSortOrder('PurchaseDate','disposalDate');
		$scope.setDefaultPagingValue();
		// Get Household Counts
		HouseholdService.getHouseholdCustomersCount(custId).then(function(data){	//442014
			$rootScope.hh_cust_cnt = parseInt(data);
		});
		HouseholdService.getHouseholdVehicleCount(custId,'CURRENT').then(function(data){
			$rootScope.hh_curr_veh_cnt = parseInt(data);
		});
		HouseholdService.getHouseholdVehicleCount(custId,'DISPOSED').then(function(data){
			$rootScope.hh_disp_veh_cnt = parseInt(data);
		});
		HouseholdService.getHouseholdTfsCount(custId,'CURRENT').then(function(data){
			$rootScope.hh_curr_tfs_cnt = parseInt(data);
		});
		HouseholdService.getHouseholdTfsCount(custId,'DISPOSED').then(function(data){
			$rootScope.hh_disp_tfs_cnt = parseInt(data);
		});
		
		// Begin: Household Customers
		$scope.getHouseholdCustomersRecords = function(nav) {
			var custObj = $scope.paging.hhCustomers;
			var custLimit = (custObj.curr_page - 1) * $scope.paging.per_page;
			HouseholdService.getHouseholdCustomers(custId,custLimit).then(function(data){	
				$rootScope.hh_customers = data;
				$scope.setNavigationControls(data,custObj,nav);
				if(nav != '') {
					setTimeout(function() { $scope.setPagingScrollPosition('householdView', 'householdCustList'); },1000);
				}
			});
		}
		$scope.getHouseholdCustomersRecords('');
		// End: Household Customers
		
		// Begin: Household Vehicles
		// Current
		$scope.getHouseholdCurrentVehiclesSummary = function(nav) {
			var curVehObj = $scope.paging.hhCurVehicles;
			var curVehLimit = (curVehObj.curr_page - 1) * $scope.paging.per_page;
			HouseholdService.getHouseholdVehicles(custId,curVehLimit,'CURRENT').then(function(data){
				$rootScope.hh_curr_vehicles = data;
				$scope.setNavigationControls(data,curVehObj,nav);
				if(nav != '') {
					setTimeout(function() { $scope.setPagingScrollPosition('householdView', 'currentVehicles'); },1000);
				}
			});
		}
		$scope.getHouseholdCurrentVehiclesSummary('');
		// Disposed
		$scope.getHouseholdDisposedVehiclesSummary = function(nav) {
			var dispVehObj = $scope.paging.hhDispVehicles;
			var dispVehLimit = (dispVehObj.curr_page - 1) * $scope.paging.per_page;
			HouseholdService.getHouseholdVehicles(custId,dispVehLimit,'DISPOSED').then(function(data){
				if(nav != '' && data.count == 0) {
					data = $rootScope.hh_disp_vehicles;
					data.Disposed.splice(0, 10);
					data.count = $rootScope.hh_disp_veh_cnt - dispVehLimit;
				} else if(nav == 'Next' && data.count != 0) {
					$rootScope.hh_disp_vehicles.Disposed.splice(0, 10);
					$rootScope.temp = $rootScope.hh_disp_vehicles.Disposed;
					angular.forEach($rootScope.temp, function(value, key) {
						data.Disposed.push(value);
					});
					data.count = (data.Disposed.length > data.count)? data.Disposed.length : data.count;
				} else if(nav == 'Prev') {
					var sliceCnt = data.actualCount - 10;
					$rootScope.temp.splice(0, sliceCnt);
					angular.forEach($rootScope.temp, function(value, key) {
						data.Disposed.push(value);
					});
					data.count = data.Disposed.length;
				}
				$rootScope.hh_disp_vehicles = data;
				$scope.setNavigationControls(data,dispVehObj,nav);
				if(nav != '') {
					setTimeout(function() { $scope.setPagingScrollPosition('householdView', 'disposedVehicles'); },1000);
				}
			});
		}
		$scope.getHouseholdDisposedVehiclesSummary('');
		// End: Household Vehicles
		
		// Begin: Household Tfs Products
		// Current
		$scope.getHouseholdCurrentTfsSummary = function(nav) {
			var curTfsObj = $scope.paging.hhCurTfs;
			var curTfsLimit = (curTfsObj.curr_page - 1) * $scope.paging.per_page;
			HouseholdService.getHouseholdTfsProducts(custId,curTfsLimit,'CURRENT').then(function(data){	
				$rootScope.hh_curr_tfs = data;
				$scope.setNavigationControls(data,curTfsObj,nav);
				if(nav != '') {
					setTimeout(function() { $scope.setPagingScrollPosition('householdView', 'tfsCurrentPrdt'); },1000);
				}
			});
		}
		$scope.getHouseholdCurrentTfsSummary('');
		// Disposed
		$scope.getHouseholdDisposedTfsSummary = function(nav) {
			var dispTfsObj = $scope.paging.hhDispTfs;
			var dispTfsLimit = (dispTfsObj.curr_page - 1) * $scope.paging.per_page;
			HouseholdService.getHouseholdTfsProducts(custId,dispTfsLimit,'DISPOSED').then(function(data){	
				$rootScope.hh_disp_tfs = data;
				$scope.setNavigationControls(data,dispTfsObj,nav);
				if(nav != '') {
					setTimeout(function() { $scope.setPagingScrollPosition('householdView', 'tfsDisposedPrdt'); },1000);
				}
			});
		}
		$scope.getHouseholdDisposedTfsSummary('');
		// End: Household Tfs Products
		
		// Begin: Household Telematics
		$scope.getHouseholdTelematicsRecords = function(nav) {
			var teleObj = $scope.paging.hhTelematics;
			var teleLimit = (teleObj.curr_page - 1) * $scope.paging.per_page;
			var inc = 1;
			HouseholdService.getHouseholdTelematicsCount(custId).then(function(data){
				$rootScope.hh_telematics_cnt = data.TotalCount;
				$rootScope.houseHoldId = data.HousseHoldId;
				HouseholdService.getHouseholdTelematics(custId,teleLimit,$rootScope.houseHoldId).then(function(data){
					angular.forEach(data.HousseHoldList, function(value, key) {
						angular.forEach(value, function(value2, key2) {
							value2.index = inc++;
						});
					});
					$rootScope.hh_telematics = data;
					$scope.setNavigationControls(data,teleObj,nav);
					if(nav != '') {
						setTimeout(function() { $scope.setPagingScrollPosition('householdView', 'householdTelematics'); },1000);
					}
					$timeout(function(){ $('.loader_outer, .loader_inner').hide(); }, 1000);
				});
			});
		}
		$scope.getHouseholdTelematicsRecords('');
		// End: Household Telematics
		
		// Begin: Household Selling Dealer
		$scope.getHouseholdSellingDealer = function(custProdAssocId){
			$rootScope.sellingDealer = '';
			var url = 'getHouseholdTelematicsSellingDealer.do?custProdAssocId='+custProdAssocId;
			$http.get(url).then(function(result){
				if(result.data) $rootScope.sellingDealer = result.data;
				else $rootScope.sellingDealer = 'No selling dealer found';
			});
		}
		// End: Household Selling Dealer
	});
	
	// Paging setup
	$scope.paging	=	{
							"allCurVehicles": { "curr_page": 1, "total_page": 1, "curr_count": 0 },
							"allDispVehicles": { "curr_page": 1, "total_page": 1, "curr_count": 0 },
							"hhCustomers": { "curr_page": 1, "total_page": 1, "curr_count": 0 },
							"hhCurVehicles": { "curr_page": 1, "total_page": 1, "curr_count": 0 },
							"hhDispVehicles": { "curr_page": 1, "total_page": 1, "curr_count": 0 },
							"hhCurTfs": { "curr_page": 1, "total_page": 1, "curr_count": 0 },
							"hhDispTfs": { "curr_page": 1, "total_page": 1, "curr_count": 0 },
							"hhTelematics": { "curr_page": 1, "total_page": 1, "curr_count": 0 },
							"per_page":10
						};
	// Begin: Pagination - To fetch next set of records				
	$scope.setPaging = function(nav,module) {
		$('.loader_outer, .loader_inner').show();
		switch (module) {
			case 'AllCurVehicles':
				var allCurVehObj = $scope.paging.allCurVehicles;
				if(nav == 'Next') allCurVehObj.curr_page += 1; else allCurVehObj.curr_page -= 1;
				$scope.getAllCurrentVehiclesList(nav);
				break;
			case 'AllDispVehicles':
				var allDispVehObj = $scope.paging.allDispVehicles;
				if(nav == 'Next') allDispVehObj.curr_page += 1; else allDispVehObj.curr_page -= 1;
				$scope.getAllDisposedVehiclesList(nav);
				break;
			case 'Customer':
				var custObj = $scope.paging.hhCustomers;
				if(nav == 'Next') custObj.curr_page += 1; else custObj.curr_page -= 1;
				$scope.getHouseholdCustomersRecords(nav);
				break;
			case 'VehicleCurrent':
				var curVehObj = $scope.paging.hhCurVehicles;
				if(nav == 'Next') curVehObj.curr_page += 1; else curVehObj.curr_page -= 1;
				$scope.getHouseholdCurrentVehiclesSummary(nav);
				break;
			case 'VehicleDisposed':
				var dispVehObj = $scope.paging.hhDispVehicles;
				if(nav == 'Next') dispVehObj.curr_page += 1; else dispVehObj.curr_page -= 1;
				$scope.getHouseholdDisposedVehiclesSummary(nav);
				break;
			case 'TfsCurrentPrdt':
				var curTfsObj = $scope.paging.hhCurTfs;
				if(nav == 'Next') curTfsObj.curr_page += 1; else curTfsObj.curr_page -= 1;
				$scope.getHouseholdCurrentTfsSummary(nav);
				break;
			case 'TfsDisposedPrdt':
				var dispTfsObj = $scope.paging.hhDispTfs;
				if(nav == 'Next') dispTfsObj.curr_page += 1; else dispTfsObj.curr_page -= 1;
				$scope.getHouseholdDisposedTfsSummary(nav);
				break;
			case 'Telematics':
				var teleObj = $scope.paging.hhTelematics;
				if(nav == 'Next') teleObj.curr_page += 1; else teleObj.curr_page -= 1;
				$scope.getHouseholdTelematicsRecords(nav);
				break;
			default:
		}
	}
	// End: Pagination
	
	// Begin : setNavigationControls - To enable/disable Next & Prev link based on 'total_page' value
	$scope.setNavigationControls = function(data,obj,nav){
		if((nav == '' || nav == 'Next') && Math.ceil(data.count/$scope.paging.per_page) > 1) {
			obj.total_page = obj.curr_page + 1;
		} else if(nav == 'Prev') {
			//obj.total_page -= 1;
		}
		obj.curr_count = parseInt(((obj.curr_page-1) * 10)) + parseInt((data.count > 10)? 10 : data.count);
	}
	// End : setNavigationControls
	
	// Begins : To set default sort order
	$scope.setDefaultSortOrder = function(column1, column2) {
		//console.log('setDefaultSortOrder');
		$scope.reverse			= true;
		$scope.columnName		= column1; 
		$scope.disReverse		= true;
		$scope.disColumnName	= column2;
	}
	// Ends: To set default sort order
	
	// Begins : To set default Paging Value
	$scope.setDefaultPagingValue = function() {
		$scope.paging.hhCustomers		= { "curr_page": 1, "total_page": 1, "curr_count": 0 };
		$scope.paging.hhCurVehicles		= { "curr_page": 1, "total_page": 1, "curr_count": 0 };
		$scope.paging.hhDispVehicles	= { "curr_page": 1, "total_page": 1, "curr_count": 0 };
		$scope.paging.hhCurTfs			= { "curr_page": 1, "total_page": 1, "curr_count": 0 };
		$scope.paging.hhDispTfs			= { "curr_page": 1, "total_page": 1, "curr_count": 0 };
		$scope.paging.hhTelematics		= { "curr_page": 1, "total_page": 1, "curr_count": 0 };
	}
	// Ends: To set default Paging Value
	
	// Begin : Dealer Info Popup
	$scope.DealerInfoPopup = function(dealerCode){
		HistoryService.getDealerInfoDetails(dealerCode).then(function(data){	
			var response_data = data;
			//$rootScope.weeks = ['Monday','Tueday','Wednesday','Thursday','Friday','Saturday','Sunday'];
			$rootScope.dealerInfoDetail = response_data;
		})
		DealerviewPopup({
			id: 'simpleDialog',
			templateUrl:'views/dealerinfopopup.html',
			title: '',
			backdrop: true,
			modalClass: "delaerinfopopup",
			success: {label: 'Success', fn: function() {console.log('Inline modal closed');}}
		});
	};
	// End : Dealer Info Popup
	
	// Begin : Telematics Product Enrollment Details
	$scope.getTelematicsProductEnrollmentDetail = function(event,subsId) {
		$scope.accordian(event, '');
		if($(event.target).parents('div.telematics').hasClass('hasrecords')) {
			$(event.target).parents('div.telematics').find('.expand').toggle();
			$scope.setInnerScrollPos(event,'scrollforcustprofil','telematics');
		} else {
			$(event.target).parents('div.telematics').addClass('hasrecords');
			var url = 'getTelematicsTranscationHistory.do?subscriptionDetailId='+subsId;
			$http.get(url).then(function(result){
				$rootScope.subscriptionDetail = result.data;
				LoadDynamicTemplate({
					templateUrl:'views/telematicsDynamicTemplate.html',
					viewportClass:'scrollforcustprofil',
					parentElementClass:'telematics',
					expandElementClass:'expand',
					event:event
				});
			});
		}
	}
	// End : Telematics Product Enrollment Details
	
	// Begin : Telematics Ownership Details
	$scope.getTelematicOwnershipDetail = function(event,custId,custProdAssocId,serPrdctId,role,expDate) {
		// Restricted access
		if($(event.target).parents('div.telematicsOwners').hasClass('restricted')) {
			return false;
		}
		// Non Restricted access
		$scope.accordian(event, '');
		$('#telematics_noti_element_'+custId).hide();
		if($(event.target).parents('div.telematicsOwners').hasClass('hasrecords')) {
			$(event.target).parents('div.telematicsOwners').find('.expand').toggle().html('');
			$scope.setInnerScrollPos(event,'scrollforcustprofil','telematicsOwners');
			$(event.target).parents('div.telematicsOwners').removeClass('hasrecords');
		} else {
			if(!$(event.target).parents('div.telematicsOwners').find('.expand').is(":visible")) {
				$(event.target).parents('div.telematicsOwners').find('.expand').toggle();
			}
			var vin = $rootScope.vin;
			$(event.target).parents('div.telematicsOwners').addClass('hasrecords');
			if(role == 'PRIMARY SUBSCRIBER' || role == 'SECONDARY SUBSCRIBER')
				var url ='getTelematicsEnformEmail.do?vin='+vin+'&custId='+custId+'&custProdAssocId='+custProdAssocId+'&serPrdctId='+serPrdctId+'&role='+role;
			else
				var url ='getTelematicsEnformRemote.do?vin='+vin+'&custId='+custId+'&expirationDate='+expDate;
			$http.get(url).then(function(result){
				$rootScope.teleOwnershipDetail = result.data;	
				$rootScope.teleOwnershipDetail = {"SellingDealer":"61206","SellingDealerName":"BREDEMANN LEXUS","EDOptedIn":"Y","MAINTEmail":"Y","MAINTMobAppPushNotification":"N","MAINTPhoneByDealer":"N","MILONEmail":"Y","MILONMobAppPushNotification":"N","VHREmail":"Y","VHRMobAppPushNotification":"N","CustomerEmailAddress":"nublu7@comcast.net","AlternativeEmailAddress":"nublu7@comcast.net","ActiveVINs":null,"NotificationEmail":["testetset@testse.com","tesasd123tetset@testse.com"]};
				$rootScope.teleOwnershipDetail.custId = custId;
				$rootScope.teleOwnershipDetail.role = role;
				LoadDynamicTemplate({
					templateUrl:'views/telematicsOwnershipTemplate.html',
					viewportClass:'scrollforcustprofil',
					parentElementClass:'telematicsOwners',
					expandElementClass:'expand',
					event:event
				});
			});
		}
	}
	// End : Telematics Ownership Details
	
	// Begin : TFS Product Details
	$scope.getTfsPrdtDetails = function(event) {
		$scope.accordian(event,'');
		$(event.target).parents('div.tfs').find('.expand').slideToggle();
		setTimeout(function() {
			$scope.setInnerScrollPos(event,'scrollforcustprofil','tfs');
		},300);
	}
	// End : TFS Product Details
	
	// Begin : HouseHold Vehicle Details
	$scope.getHouseHoldVehicleDetails = function(event,AssociateId){
		if (event.target.className.indexOf("link") >= 0) return false;
		$scope.accordian(event, '');
		if($(event.target).parents('div.hhVehicles').hasClass('hasrecords')) {
			$(event.target).parents('div.hhVehicles').find('.expand').toggle();
			$scope.setInnerScrollPos(event,'householdView','hhVehicles');
		} else {
			$(event.target).parents('div.hhVehicles').addClass('hasrecords');
			SalesInfoService.getSalesInfoDetails(AssociateId).then(function(data){	
				var response_data = data;
				$rootScope.houseHoldInfo = response_data;
				LoadDynamicTemplate({
					templateUrl:'views/householdDynamicTemplate.html',
					viewportClass:'householdView',
					parentElementClass:'hhVehicles',
					expandElementClass:'expand',
					event:event
				});
			});
		}
	}
	// End : HouseHold Vehicle Details
	
	// Begin : HouseHold TFS Details
	$scope.getHouseHoldTfsDetails = function(event,custId,serPrdctId,serPrdctType,extKey,vin){
		$scope.accordian(event,'');
		if($(event.target).parents('div.hh_tfs').hasClass('hasrecords')) {
			$(event.target).parents('div.hh_tfs').find('.expand').toggle();
			$scope.setInnerScrollPos(event,'householdView','hh_tfs');
		} else {
			$(event.target).parents('div.hh_tfs').addClass('hasrecords');
			var url = 'getHouseHoldTFSProductsDetails.do?productExtrnlSysKey='+extKey+'&serializedProductType='+serPrdctType+'&vin='+vin;
			$http.get(url).then(function(result){
				$rootScope.hhTfsInfo = result.data;
				LoadDynamicTemplate({
					templateUrl:'views/householdTfsDynamicTemplate.html',
					viewportClass:'householdView',
					parentElementClass:'hh_tfs',
					expandElementClass:'expand',
					event:event
				});
			});
		}
	}
	// End : HouseHold TFS Details
	
	$scope.setInnerScrollPos = function(event,viewport,currentElem) {
		var elem = $(event.target).parents('div.collapse');
		if(elem.find('tr span.symbol').hasClass('inline_loader')) {
			elem.find('tr span.symbol').removeClass('inline_loader').addClass('minus');
			elem.addClass('opened');
		}
		var scrollPos		= $("#"+viewport).scrollTop();
		var parentTopPos	= $("#"+viewport).offset().top;
		var elementPos		= $(event.target).parents('div.'+currentElem).offset().top;
		$("#"+viewport).animate({"scrollTop": (scrollPos+elementPos-parentTopPos-20)+"px"}, 300);		
	}
	$scope.setPagingScrollPosition = function(viewport,currentElem) {
		var viewportPos	= $("#"+viewport).scrollTop();
		var elementPos	= $('#'+currentElem).offset().top;
		var extraHt		= ($('.main_menu').offset().top + $('.main_menu').outerHeight(true));
		extraHt			= (viewport == 'scrollforcustprofil')? (extraHt + $('.vehicletabcolor').outerHeight(true)) : extraHt;		
		var scrollPos	= (viewportPos + elementPos - extraHt);
		//console.log(viewportPos+'------'+elementPos+'----'+extraHt+'-------'+scrollPos);
		$("#"+viewport).animate({"scrollTop": scrollPos+"px"}, 500);
		setTimeout(function(){$('.loader_outer, .loader_inner').hide();},100);
	}
	/*
	$scope.showVehicleDetail = function(vehicleObj, cust_id) {
		console.log(vehicleObj);
		if(cust_id != undefined) {
			$rootScope.$broadcast('customerid', cust_id);
		}
		if(vehicleObj != undefined){
			$rootScope.vin = vehicleObj.Vin;
			$rootScope.$broadcast('VehicleClicked', $rootScope.vin);
			$rootScope.VehicleMakeModel = vehicleObj.VehicleMakeModel;
			$rootScope.$broadcast('showMainMenuTab', 1);
			$rootScope.$broadcast('showDetailsMenuTab',1); // 1 - Vehicles details Tab, 2 - All Vehicles Tab
			$timeout(function(){
				setScrollViewport();
				$('#scrollforcustprofil').scrollTop(0);
			},300);
		};
	}
	*/
	/*
	$scope.updateCustomerDetails = function(cust_id){
		console.log("--------------updateCustomerDetails--------------");
		$timeout(function(){
			// Delete previously searched customer details
			if($rootScope.Newcustomer != undefined) {
				delete $rootScope.Newcustomer;
				delete $rootScope.customerId;
			}
			// Update Customer
			$rootScope.$broadcast('customerid', cust_id);
			$rootScope.$broadcast('showMainMenuTab', 1);
			// Update Vehicle Tab
			var getCustomerDetailsOnLoad = setInterval(function(){
				if($rootScope.Newcustomer != undefined) {
					angular.element($('[ng-controller="customerprofileController"]')).scope().setVehicleTab();
					clearInterval(getCustomerDetailsOnLoad);
				}
			}, 100);
		}, 300);
	};
	*/

	$scope.$on('customerid', function(events, args){
		$scope.paging.allCurVehicles	= { "curr_page": 1, "total_page": 1, "curr_count": 0 };
		$scope.paging.allDispVehicles	= { "curr_page": 1, "total_page": 1, "curr_count": 0 };
		var cust_id = args;
		if($rootScope.modelyear != undefined && $rootScope.modelname != undefined && $rootScope.brand != undefined) {
			$rootScope.VehicleMakeModel = '';
		}
		var vehicle = $scope.CustVehicle;
		if($rootScope.Vin != null) var Vin = $rootScope.Vin;
	
		$scope.ShowVehicle=function(Allvehicle){
			if(Allvehicle != undefined){
				$rootScope.vin = Allvehicle.Vin;
				$rootScope.$broadcast('VehicleClicked', $rootScope.vin);
				$rootScope.VehicleMakeModel = Allvehicle.VehicleMakeModel;
			};
		}
		$scope.ShowVehicle();
		$scope.Dealerpopup=function(vehicleOwner){
			var AssociateId = vehicleOwner.CustomerProductAssocId;
			SalesInfoService.getSalesInfoDetails(AssociateId).then(function(data){	
				var response_data = data;
				$rootScope.SalesInfo = response_data;	
			});

			$scope.title="Vehicle Owner Information";
			DealerviewPopup({
				id: 'simpleDialog',
				templateUrl:'views/dealerDetailspopup.html',
				title: $scope.title,
				backdrop: true,
				success: {label: 'Success', fn: function() {console.log('Inline modal closed');}}
			});
		};
		// Begin: All Vehicles
		// Get Vehicles Counts
		AllVehicleService.getAllVehiclesCount(cust_id,'CURRENT').then(function(data){
			$rootScope.all_curr_veh_cnt = parseInt(data);
		});
		AllVehicleService.getAllVehiclesCount(cust_id,'DISPOSED').then(function(data){
			$rootScope.all_disp_veh_cnt = parseInt(data);
		});
		// Current
		$scope.getAllCurrentVehiclesList = function(nav) {
			var allCurVehObj = $scope.paging.allCurVehicles;
			var allCurVehLimit = (allCurVehObj.curr_page - 1) * $scope.paging.per_page;
			AllVehicleService.getAllvehicleDetails(cust_id,allCurVehLimit,'CURRENT').then(function(data){	
				$rootScope.all_curr_vehicles = data.Current;
				$scope.setNavigationControls(data,allCurVehObj,nav);
				if(nav != '') {
					setTimeout(function() { $scope.setPagingScrollPosition('scrollforcustprofil', 'currentVehicleTable'); },1000);
				}
			});
		}
		$scope.getAllCurrentVehiclesList('');
		// Disposed
		$scope.getAllDisposedVehiclesList = function(nav) {
			var allDispVehObj = $scope.paging.allDispVehicles;
			var allDispVehLimit = (allDispVehObj.curr_page - 1) * $scope.paging.per_page;
			AllVehicleService.getAllvehicleDetails(cust_id,allDispVehLimit,'DISPOSED').then(function(data){	
				$rootScope.all_disp_vehicles = data.Disposed;
				$scope.setNavigationControls(data,allDispVehObj,nav);
				if(nav != '') {
					setTimeout(function() { $scope.setPagingScrollPosition('scrollforcustprofil', 'disposedVehicleTable'); },1000);
				}
			});
		}
		$scope.getAllDisposedVehiclesList('');
		// End: All Vehicles
	});

	/* Begin: All Vehicles Sorting Code*/
	$scope.sort = function(sortvalue, sortype) {	// sortype : 1 - current, 2 - Disposed
		if(sortype == 1) {
			$scope.reverse		= ($scope.columnName === sortvalue)? !$scope.reverse : false;
			$scope.columnName	= sortvalue;
		} else {
			$scope.disReverse		= ($scope.disColumnName === sortvalue)? !$scope.disReverse : false;
			$scope.disColumnName	= sortvalue;
		}
	};
	/* End: All Vehicles Sorting Code*/
	
	$scope.AdditionalVehiclepopup=function(){
		$scope.title="ADDITIONAL VEHICLE DETAILS";
		AdditionalvehiclPopup({
            id: 'simpleDialog',
            templateUrl:'views/additionalvehiclepopup.html',
            title: $scope.title,
            backdrop: true,
            success: {label: 'Success', fn: function() {console.log('Inline modal closed');}}
        });
	}
	$scope.ReAcquireVehiclepopup=function(){
		$('#reAcquireDialog, .ownerpopup-backdrop').remove();
		PermissionPopup({
            id: 'reAcquireDialog',
            templateUrl:'views/reacquirepopup.html',
            title: '',
            backdrop: true,
			backdropCancel : false,
            success: {label: 'Success', fn: function() {console.log('Inline modal closed');}}
        });
	}
	$scope.nonWarrantyPopup=function(){
		if($('#nonWarrantyDialog').length == 0){
			PermissionPopup({
				id: 'nonWarrantyDialog',
				templateUrl:'views/nonWarrantyVehiclePopup.html',
				title: '',
				backdrop: true,
				backdropCancel : false,
				success: {
							label: 'Success',
							fn: function() {
								$timeout(function() {
									angular.element('#service_history_tab').triggerHandler('click');
									var sh_top_pos = $('#vehicle_ownership_detail').offset().top;
									$('#scrollforcustprofil').scrollTop(sh_top_pos);
								}, 500);
							}
						}
			});
		}
	}
	$scope.serviceHistoryAlertPopup=function(){
		if($('#thirtyDayTripDialog').length == 0){
			PermissionPopup({
				id: 'thirtyDayTripDialog',
				templateUrl:'views/thirtyDayTripPopup.html',
				title: '',
				backdrop: true,
				backdropCancel : false,
				success: {
							label: 'Success',
							fn: function() {
								$timeout(function() {
									angular.element('#service_history_tab').triggerHandler('click');
									var sh_top_pos = $('#vehicle_ownership_detail').offset().top;
									$('#scrollforcustprofil').scrollTop(sh_top_pos);
								}, 300);
							}
						}
			});
		}
	}
	
	// Begin : Service History Codes
	$scope.$on('ServiceHistoryClicked', function(events, count, triggerType){
		console.log('------ServiceHistoryClicked--------'+$rootScope.vin+'--------------'+count);
		$scope.disclaimerFlag = true;
		// Service Summary
		HistoryService.getServiceHistorySummary($rootScope.vin,count).then(function(data){
			if(count > 0) {	// Get Older Service History
				$('.loader_outer, .loader_inner').hide();
			}
			var response_data = data;
			if(response_data.errorCode != 500) {
				$rootScope.services = response_data;
				if($rootScope.services.RepairOrderList != null && $rootScope.services.RepairOrderList.length != 0) {
					$rootScope.vehicleTabDetails[6].classname = 'hasrecord';
				}
				if($rootScope.services.unwarrantableVehicle == 'Y' && $rootScope.nonWarrantyFlag){
					if(triggerType == 'auto') {
						$scope.nonWarrantyPopup();
						$rootScope.nonWarrantyFlag = false;
					}
				}
				if($scope.services.thirtyDayTrip == 'Y' && $rootScope.serviceHistoryFlag){
					if(triggerType == 'auto'){
						$scope.serviceHistoryAlertPopup();
						$rootScope.serviceHistoryFlag = false;
					}
				}
			}
		});
		// Claims summary
		if(count == 0) { // To be executed only when "service history" tab is clicked
			HistoryService.getClaimsHistorySummary($rootScope.vin).then(function(data){
				var response_data = data;
				$rootScope.claims = response_data;
				if($rootScope.claims != null && $rootScope.claims.length != 0) {
					$rootScope.vehicleTabDetails[6].classname = 'hasrecord';
				}
			});
		}
	});
	$scope.closeInlinePopup = function(inlinepop) {
		if(inlinepop == 'warranty')
			$scope.warrantyFlag = false;
		else if(inlinepop == 'trip')
			$scope.tripFlag = false;
		else if(inlinepop == 'disclaimer')
			$scope.disclaimerFlag = false;
	}
	// Accordian
	$scope.accordian = function(event, type) {
		// To change plus & minus icon
		if (event.target.className.indexOf("link") >= 0) return false;
		var obj = $(event.target).parents('div.collapse').find('tr span.symbol');
		if($(obj).hasClass('plus')) {
			$(obj).removeClass('plus').addClass('inline_loader');
		} else if($(obj).hasClass('minus')) {
			$(obj).removeClass('minus').addClass('plus');
			$(event.target).parents('div.collapse').removeClass('opened');
		} else if(type != '') {
			if(type == 'Service')
				$(event.target).parents('div.serviceorders').find('.plus').removeClass('plus').addClass('inline_loader');
			else
				$(event.target).parents('div.surveyCustomercontent').find('.plus').removeClass('plus').addClass('inline_loader');
		}
	}
	// Service
	$scope.getServiceDetails = function(event,orderno,dealer,openDt,closeDt,condno) {
		var orderno = (orderno == null)? '':orderno;
		var dealer = (dealer == null)? '':dealer;
		var openDt = (openDt == null)? '':openDt;
		var closeDt = (closeDt == null)? '':closeDt;
		// To change plus & minus icon
		$scope.accordian(event, 'Service');
		// Service Call
		if($(event.target).parents('div.serviceorders').hasClass('hasrecords')) {
			if(condno == 'all') {	// If user clicks 'Expand All'
				$(event.target).parents('div.serviceorders').find('.expand').show();
				var elementPos	= $(event.target).parents('div.serviceorders').find('div.condition:first').offset().top;
				var expandElem	= $(event.target).parents('div.serviceorders');
			} else { // When user clicks particualr condtion '+' symbol
				$(event.target).parents('div.condition').find('.expand').toggle();
				var elementPos	= $(event.target).parents('div.condition').offset().top;
				var expandElem	= $(event.target).parents('div.condition');
			}
			if(expandElem.find('tr span.symbol').hasClass('inline_loader')) {
				expandElem.find('tr span.symbol').removeClass('inline_loader').addClass('minus');
				expandElem.find('div.collapse').addClass('opened');
			}
			// Begin: Animate
			var scrollPos		= $("#scrollforcustprofil").scrollTop();
			var parentTopPos	= $("#scrollforcustprofil").offset().top;
			$("#scrollforcustprofil").animate({"scrollTop": (scrollPos+elementPos-parentTopPos-20)+"px"}, 300);
			// End: Animate
		} else {
			var vin = $rootScope.vin;
			$(event.target).parents('div.serviceorders').addClass('hasrecords');	
			var url = 'getServiceHistoryDetails.do?repairOrderNo='+orderno+'&dealer='+dealer+'&openDt='+openDt+'&closeDt='+closeDt+'&vin='+vin;
			$http.get(url).then(function(result){
				$rootScope.temp_vin_make = $rootScope.brand;
				$rootScope.repairOrderCondition = result.data.repairOrderCondition;
				var html = '<div id="temp_condition" ng-include="\'views/serviceDynamicTemplate.html\'"></div>';
				var scope = $rootScope.$new();
				var modalEl = angular.element(html);
				var obj = $document.find('body');
				$compile(modalEl)(scope);
				obj.append(modalEl);
				var load = setInterval(function(){
					if($('#temp_condition').length) {
						clearInterval(load);
						var ang_element = angular.element($document.find('#temp_condition .temp'));
						angular.forEach(ang_element, function(value, key) {
							var id = 'ro_'+orderno+'_'+(key+1);
							var obj = $(event.target).parents('div.serviceorders').find('#'+id);
							obj.append(value);
							var htmlcontent = obj.html().replace(/(ng-\w+-\w+="(.|\n)*?"|ng-\w+="(.|\n)*?"|ng-(\w+-\w+)|ng-(\w+))/g, '').replace(/<!--(.*?)-->/gm, "");
							obj.html('').html(htmlcontent);
							if((key+1) == condno || condno == 'all') {
								obj.show();
								obj.prev().addClass('opened').find('span.symbol').removeClass('inline_loader').addClass('minus');
							} else {
								obj.hide();
							}
						});
						$document.find('#temp_condition').remove();
						// Begin: Animate
						var scrollPos		= $("#scrollforcustprofil").scrollTop();
						var parentTopPos	= $("#scrollforcustprofil").offset().top;
						if(condno == 'all')
							var elementPos		= $(event.target).parents('div.serviceorders').find('div.condition:first').offset().top;
						else
							var elementPos		= $(event.target).parents('div.condition').offset().top;
						$("#scrollforcustprofil").animate({"scrollTop": (scrollPos+elementPos-parentTopPos-20)+"px"}, 300);
						// End: Animate
					}
				}, 500);
			});
		}
	}
	$scope.getTfsServiceDetails = function(event) {
		// To change plus & minus icon
		$scope.accordian(event, 'Service');
		$(event.target).parents('div.condition').find('.expand').toggle();
		$scope.setInnerScrollPos(event,'scrollforcustprofil','tfs');
	}
	// Claims
	$scope.getClaimDetails = function(event,claimId,closeDt,dealer,ro_no) {
		var closeDt = (closeDt == null)? '':closeDt;
		var dealer = (dealer == null)? '':dealer;
		var ro_no = (ro_no == null)? '':ro_no;
		$scope.accordian(event, 'claim');
		// Service Call
		if($(event.target).parents('div.serviceorders').hasClass('hasrecords')) {
			$(event.target).parents('div.condition').find('.expand').toggle();
			$scope.setInnerScrollPos(event,'scrollforcustprofil','serviceorders');
		} else {
			var vin = $rootScope.vin;
			$(event.target).parents('div.serviceorders').addClass('hasrecords');
			var url = 'getWarrantyDetails.do?warrantyClaimId='+claimId+'&closeDt='+closeDt+'&dealer='+dealer+'&repairOrderNo='+ro_no+'&vin='+vin;
			$http.get(url).then(function(result){
				$rootScope.claimsDetail = result.data[0];
				$rootScope.claimsDetail = [{"WarrantyClaimNo":"019445","RONumber":"0149135","DateCalimSubmitted":"04/14/2014","SSCRelatedNumber":"---","DateClaimPaid":"04/17/2014","RequestedAmt":0.0,"PaidAmt":140.29,"GoodwillInd":"N","Condition":"CUSTOMER STATES, BRAKE ACTUATOR RECALL","Cause":"","Remedy":"COMPLETED","T1Code":"","T1Desc":"","T2Code":"","T2Desc":"","T3Code":null,"T3Desc":null,"SubletInvoiceNumber":null,"SubletDesc":null,"partInfoList":[],"subletList":[{"subletInvoiceNo":"1491353","subletDescription":"COMPLIMENTARY CARWASH"},{"subletInvoiceNo":"1491351","subletDescription":"CAR LOANER"},{"subletInvoiceNo":"1491352","subletDescription":"GAS"}],"claimType":"SSC"}];
				$rootScope.claimsDetail.sh_claims = false;
				if($(event.target).parents('div.serviceorders').hasClass('sh_claims')) {
					$rootScope.claimsDetail.sh_claims = true;
				}
				LoadDynamicTemplate({
					templateUrl:'views/claimsDynamicTemplate.html',
					viewportClass:'scrollforcustprofil',
					parentElementClass:'serviceorders',
					expandElementClass:'expand',
					event:event
				});
				
			});
		}
	}
	// End : Service History Codes
}]);


TMSApp.controller('SortableController', ['$scope', '$rootScope', '$http', '$timeout', '$localStorage', function ($scope, $rootScope, $http, $timeout, $localStorage) {
	var sortableEle;
	$scope.saveSortOrder = function(sort_order) {
		/*
		var data = { "userPreferenceOrder" : angular.copy($rootScope.tabOrder).toString() };
		$http.post('setUserPreference.do', data).then(function (response) {
			$localStorage.tabOrder = angular.copy($rootScope.tabOrder);
		});
		*/
		var data = { "userPreferenceOrder" : sort_order.toString() };
		$http.post('setUserPreference.do', data).then(function (response) {
			$localStorage.tabOrder = angular.copy(sort_order);
			console.log($localStorage.tabOrder);
		});
	}
	$scope.dragStart = function(e, ui) {
		$(ui.item).css('top', '12px');
		ui.item.data('start', ui.item.index());
	}
	$scope.dragEnd = function(e, ui) {
		$(ui.item).css({"top":"0px"});
		var sort_order = angular.copy($localStorage.tabOrder);
		var start	= ui.item.data('start');
		var end		= ui.item.index();
		console.log(start+"--------------"+end)
		sort_order.splice(end, 0, sort_order.splice(start, 1)[0]);
		$scope.saveSortOrder(sort_order);
		/*
		var start	= ui.item.data('start');
		var end		= ui.item.index();
		$rootScope.tabOrder.splice(end, 0, $rootScope.tabOrder.splice(start, 1)[0]);
		var temp = $rootScope.tabOrder;
		$rootScope.tabOrder = [];
		$timeout(function() {
			$rootScope.tabOrder = temp;
			$scope.$apply();
			$scope.saveSortOrder();
		}, 10);
		*/
	}
	sortableEle = $('#sortable').sortable({
		containment: "parent",
		axis: 'x',
		placeholder: "ui-state-highlight",
		cursor: "move",
		tolerance: "pointer",
		dropOnEmpty: true,
		start: $scope.dragStart,
		update: $scope.dragEnd,
		change: function( event, ui ) {
			$(ui.item).css('top', '0px');
		},
		over :function(event, ui) {
			$(ui.item).css('top', '12px');
		}
	}).disableSelection();
	
	$scope.resetToDefault = function() {
		console.log("------resetToDefault----------");
		$rootScope.tabOrder = [];
		$timeout(function() {
			$rootScope.tabOrder = [1,2,3,4,5,6,7];
			$scope.saveSortOrder($rootScope.tabOrder);
		}, 10);
	}
	// Tab Click Event
	$timeout(function() {
		angular.element('#campaign_tab').bind('click', function(event){ $scope.setOwnerNotification(); });
		angular.element('#roadside_assistance_tab').bind('click', function(event){ $scope.setRoadSideAssistance(); });
		angular.element('#maintenance_plan_tab').bind('click', function(event){ $scope.setToyotaCare(); });
		angular.element('#service_history_tab').bind('click', function(event){ $scope.showServiceHistory(0,'manual'); });
		angular.element('#mirai_swap_tab').bind('click', function(event){ $scope.setMiraiSwap(); });
	}, 1000);
}]);

TMSApp.controller('VehicleHealthReportController', ['$scope', '$rootScope', '$compile', '$http', '$document', '$timeout', 'TelematicService', 'LoadDynamicTemplate', function ($scope, $rootScope,$compile, $http, $document, $timeout, TelematicService,LoadDynamicTemplate) {
	$scope.selectedCustomer = '';
	
	$scope.checkTelematicsAccess = function() {
		if($rootScope.customerRole.indexOf('C360_TELEMATICS_UPDATER') !== -1) return true;
		return false;
	}
	// View 
	$scope.generateVhrRequest = function() {
		$rootScope.vhrStatus = '';
		var url = 'sendGenerateVHRrequest.do?vin='+$rootScope.vhrVin+'&userId='+userId;
		$http.get(url).then(function(response){
			var result = response.data
			var result = {"status":"ACKNOWLEDGED","statusId":"5842","statusTime":"06-21-2017 00:14:27"};
			$scope.statusId = result.statusId;
			if(result.status == "ACKNOWLEDGED") {
				console.log("-------GenerateVHRrequest--------"+new Date());
				$rootScope.vhrStatus = "Status: In-Progress";
				$timeout(function() {
					// Get Status
					var count = 1;
					var getGenerateStatus = setInterval(function(){
						if(count <= 5 && $(".vhrInfoPopup").is(":visible")) {
							console.log(count+"-------getStatus--------"+new Date());
							$http.get("getStatus.do?processId="+$scope.statusId+"&vin="+$rootScope.vhrVin+"&userId="+userId).then(function(response) {
								var result = response.data
								var result = {"statusId":"7041","status":"ACKNOWLEDGED","statusTime":"06-21-2017 00:18:27"};
								if(result.status == "SUCCESS") {
									clearInterval(getGenerateStatus);
									// result.statusTime = $scope.displayDateFormat(result.statusTime);
									$rootScope.vhrStatus = "Status: Success ("+result.statusTime+")";
								} else if(result.status != "SUCCESS" && result.status != "ACKNOWLEDGED") {
									// Failed
									clearInterval(getGenerateStatus);
									// result.statusTime = $scope.displayDateFormat(result.statusTime);
									$rootScope.vhrStatus = "Status: Failed ("+result.statusTime+")";
									//alert("Error in processing your request. Please try again later.");
									$rootScope.customAlertPopup("Error in processing your request. Please try again later.");
								} else if(count > 5) {
									clearInterval(getGenerateStatus);
									result.statusTime = $scope.displayDateFormat(result.statusTime, 11);
									console.log(result.statusTime);
									$rootScope.vhrStatus = "Status: Failed ("+result.statusTime+")";
									//alert("Error in processing your request. Please try again later.");
									$rootScope.customAlertPopup("Error in processing your request. Please try again later.");
								}
							});
						} else {
							clearInterval(getGenerateStatus);
						}
						count++;
					}, 120000); // 120000 - 2 minutes
					// Ends
				}, 60000);	// 60000 - 1 minutes
			} else {
				// result.statusTime = $scope.displayDateFormat(result.statusTime);
				$rootScope.vhrStatus = "Status: Failed ("+result.statusTime+")";
			}
		});
		
	}
	$scope.displayDateFormat = function(dateObj, additionalMin) {
		var d = new Date(dateObj);
		if(additionalMin != undefined) {
			d.setTime(d.getTime() + (additionalMin * 60 * 1000));
		}
		var year			= d.getFullYear();
		var month			= ("0" + (d.getMonth() + 1)).slice(-2);
		var date			= ("0" + d.getDate()).slice(-2);
		var hours			= ("0" + d.getHours()).slice(-2);
		var minutes			= ("0" + d.getMinutes()).slice(-2);
		var seconds			= ("0" + d.getSeconds()).slice(-2);
		var milliseconds	= ("0" + d.getMilliseconds()).slice(1,2);
		return year+"-"+month+"-"+date+" "+hours+":"+minutes+":"+seconds+"."+milliseconds;
	}
	// Latest Report
	$scope.generateLatestReport = function() {
		var url = 'getVHROnDemand.do?vin='+$rootScope.vhrVin+'&userId='+userId;
		window.open(url, '_blank', 'resizable=yes,scrollbars=no,height=530,width=790');
	};
	// VHR Report
	$scope.generateVHRReport = function(vhrId) {
		var url = 'getVHRPdf.do?vhrId='+vhrId+'&pdfVin='+$rootScope.vhrVin+'&userId='+userId;
		window.open(url, '_blank', 'resizable=yes,scrollbars=no,height=530,width=790');
	}
	
	// Begin : VHR GeneratedBy Info
	$scope.VHRGeneratedByInfo = function(event,type,id){
		var obj = $(event.target).parents('td.expand').find('div.generatedby');
		if($(obj).hasClass('open')) {
			$('.cust-tooltip').hide();
			$(obj).removeClass('open');
		} else {
			TelematicService.getVHRGeneratedByDetails(type,$rootScope.vhrVin,id).then(function(data){
				$rootScope.generatedBy = data;
				$rootScope.generatedBy = {"CustomerId":null,"FirstNm":null,"LastNm":null,"EmailNotification":null,"EmailAddressRole":null,"PhoneNo":null,"AreaCd":null,"PhoneRole":null,"AddressLine1":null,"City":null,"StateProvinceCd":null,"PostalCd":null,"CustomerName":null,"CustomerEmailNotificationList":["tessaasdsadesetset@test.com","tessesetset@test.com"]};
				var fulladress = '';
				if(type == 'Customer') {
					fulladress = ($rootScope.generatedBy.AddressLine1 != null && $rootScope.generatedBy.AddressLine1 != '')? ($rootScope.generatedBy.AddressLine1+', ') : '';
					fulladress += ($rootScope.generatedBy.City != null && $rootScope.generatedBy.City != '')? ($rootScope.generatedBy.City+', ') : '';
					fulladress += ($rootScope.generatedBy.StateProvinceCd != null && $rootScope.generatedBy.StateProvinceCd != '')? ($rootScope.generatedBy.StateProvinceCd+', ') : '';
					fulladress += ($rootScope.generatedBy.PostalCd != null && $rootScope.generatedBy.PostalCd != '')? $rootScope.generatedBy.PostalCd : '';
				} else {
					fulladress = ($rootScope.generatedBy.AddressLine1 != null && $rootScope.generatedBy.AddressLine1 != '')? ($rootScope.generatedBy.AddressLine1+', ') : '';
					fulladress += ($rootScope.generatedBy.AddressLine2 != null && $rootScope.generatedBy.AddressLine2 != '')? ($rootScope.generatedBy.AddressLine2+', ') : '';
					fulladress += ($rootScope.generatedBy.City != null && $rootScope.generatedBy.City != '')? ($rootScope.generatedBy.City+', ') : '';
					fulladress += ($rootScope.generatedBy.StateCd != null && $rootScope.generatedBy.StateCd != '')? ($rootScope.generatedBy.StateCd+', ') : '';
					fulladress += ($rootScope.generatedBy.PostalCd != null && $rootScope.generatedBy.PostalCd != '')? $rootScope.generatedBy.PostalCd : '';
				}
				$rootScope.generatedBy.fulladress = fulladress;
				$('.new-dropdown').removeClass('open');
				$('.cust-tooltip').hide();
				$(obj).addClass('open');
				$(obj).find('.cust-tooltip').show();
			});
		}
	};
	// End : VHR GeneratedBy Info
	
	// Begin : Send VHR Mail
	$scope.sendVHREmail = function(){
		if(confirm("Please ensure VHR report has been viewed before proceeding to the send email request.")) {
			var selCustId = $scope.selectedCustomer;
			TelematicService.sendVHREmail(selCustId,$rootScope.vhrVin,userId).then(function(data){
				var msg = '';
				if(data.MailStatus == 'Success'){
					//msg = 'Request has been sent. \n Link will be sent to '+data.NotificationMailId;
					msg = 'Request has been sent. \nLink will be sent to '+(data.EmailNotificationList.toString());
				} else if(data.MailStatus == 'Error') {
					msg = 'Error in processing your request. Please try again later.';
				} else if(data.MailStatus == 'Mail not Register') {
					msg = 'Unable to send Email VHR Request(Notofication Email Address missing). Please try again later.';
				}
				confirm(msg);
			});
		}
	}
	// End : Send VHR Mail
	
}]);


/* ==============================================EditProfileController================================================= */
TMSApp.controller('EditProfileController',['$scope', '$filter', '$rootScope', '$timeout', '$http', '$q', '$window', 'ValidationService', 'CustomerUpdateService', 'DealerviewPopup', '$localStorage', 'CustomerValidationService', function($scope,$filter, $rootScope, $timeout, $http, $q, $window, ValidationService, CustomerUpdateService, DealerviewPopup, $localStorage, CustomerValidationService) {
	console.log('--------------EditProfileController---------------');
	// Main Tab - Edit Profile, Update Vehicle Ownership
	$rootScope.editProfileTabIndex = 100; // Tabindex starts from 100
	$scope.tab = 1;
	$scope.setTab = function (tabId) {
		$scope.tab = tabId;
	};
	$scope.isSet = function (tabId) {
		return $scope.tab === tabId;
	};
	// Permissions Sub menu - Service, Survey, Marketing
	$scope.submenu = 1;
	$scope.setSubMenu = function (tabId) {
		$scope.submenu = tabId;
	};
	$scope.isSubMenu = function (tabId) {
		return $scope.submenu === tabId;
	};
	$scope.$on('EditPermission', function(events, args) {
		$rootScope.editProfileView = true;
		$timeout(function(){
			var scrollPos = $('#customer_additional_info').offset().top - $('#customer-update').offset().top - 10;
			$('#editProfileView').scrollTop(scrollPos);
			// To select permissions tab 
			angular.element($('#customer_additional_info')).scope().setTab(2);
		},150);
	});
	$scope.setEditProfileTab = function() {
		$rootScope.$broadcast('customerEdit');
	}
	$scope.$on('customerEdit', function(events, args) {
		console.log(args);
		$('.error_focus').removeClass('error_focus');
		$scope.validationMsg = '';
		$scope.addressFlag = $scope.phoneFlag = $scope.emailFlag = true;
		$rootScope.customerAddFlag	= false;
		$rootScope.customerEditFlag	= true;
		$scope.deceasedIndicatorConfirmation = false;
		$scope.tab = 1;
		var cust_id = $rootScope.customerId;
		var vin		= $rootScope.selectedVin;
		// Fetch Dropdown Values
		CustomerUpdateService.getDropdownValues(cust_id).then(function(data){
			$scope.ddl = data;
			if(cust_id != null && cust_id != '') {
				$scope.editCustomerData();
				// Intially load all select preferences data
				$scope.selectPreferences();
				$scope.customPreferences();
			} else {
				$scope.vehicleOwnershipAlertPopup(); // Orphan VIN View
			}
		});
		$scope.editCustomerData = function() {
			$('.err_msg, #phone_req, #email_req').hide();
			$scope.customPreferences(); // reload customer preference data
			$scope.validationMsg		= '';
			$scope.errorLists			= '';
			$rootScope.customerAddFlag	= false;
			$rootScope.customerEditFlag	= true;
			$scope.deceasedIndicatorConfirmation = false;
			$scope.tab			= 1;
			$scope.submenu		= 1;
			$rootScope.editProfileTabIndex = 100; // Tabindex starts from 100
			var customerData = angular.copy($rootScope.Newcustomer);
			$rootScope.editCustomerDetails = JSON.parse(JSON.stringify(customerData).replace(/null/g, "\"\""));
			if($rootScope.editCustomerDetails.socialMediaDetails.length == 0){
				$rootScope.editCustomerDetails.socialMediaDetails[0] = { "customerSocialMediaEmailId": "", "socialMediaId": "", "socialMediaSiteName": "", "socialMediaSiteStatus": "", "socialMediaSiteId": "", "socMediaSiteStatus": "", "socialMediaUserName": "", "socialMediaURL": "", "dbSiteDetails": "" };
			}
			angular.forEach($rootScope.editCustomerDetails.phone, function(value, key) {
				value.phoneType = (value.phoneType == '')? 'UNKNOWN' : value.phoneType;
				if(value.phoneNumber != '') {
					value.phoneNumber = $filter('telephone')(value.phoneNumber);
				}
			});
			$timeout(function() { $scope.setTextChannelPhState('INIT'); }, 1000);
			$scope.setStateDD();
			$scope.phoneTypeChange('Primary');
			$scope.phoneTypeChange('Alternate');
			//$('#editProfileView').scrollTop(0);
		}
		$scope.vehicleOwnershipAlertPopup = function() {
			if($("#update-vehicle-ownership").length > 0) return false;
			$scope.initialisePopupVariables();
			$rootScope.updateOwnerConfirmationFlag = true;
			DealerviewPopup({
				id: 'vehicleOwnershipDialog',
				templateUrl:'views/confirmationPopup.html',
				title : '',
				backdrop : true,
				backdropCancel : false,
				modalClass : "popup_container",
				css: {width: "470px" },
				success: {
					fn: function() {
						$scope.setTab(2); 
						$scope.addCustomerData();
						$scope.getRemoveCustomerDetails('Customer');
						return true;
					}
				},
				cancel: {
					fn: function() { return false; }
				}
			});
			$timeout(function() { $("#confirm_ok").focus(); }, 500);
		}
		$scope.addCustomerData = function() {
			$scope.tab = 2;
			$rootScope.editProfileTabIndex = 102; 	// For customer add we have 2 new fields so, Tabindex starts from 102
			$('.err_msg, #phone_req, #email_req').hide();
			$scope.validationMsg		= '';
			$scope.errorLists			= '';
			$rootScope.customerAddFlag	= true;
			$rootScope.customerEditFlag	= false;
			$scope.deceasedIndicatorConfirmation = false;
			if($rootScope.Newcustomer == undefined) { // Note: Orphan VIN View - i.e. No customer associated for this VIN so, we are manually setting all object to null value
				$rootScope.editProfileView	= true;
				var customerData = {"customerId":"","customerType":"","organizationName":"","customerFirstName":"","customerLastName":"","customerMiddleName":"","houseHoldId":"","nameSuffix":"","salutation":"","preferredToyotaDealer":"","preferredLexusDealer":"","socialMediaInfo":"","demographicInfo":"","vehicles":[],"associates":"","preferredName":"","preferredLanguage":"","email":"","phone":[{"phoneType":"UNKNOWN","phoneNumber":"","phoneRole":"PRIMARY","doNotCall":"","extension":"","effectiveDt":"","recordCreateSource":""},{"phoneType":"UNKNOWN","phoneNumber":"","phoneRole":"ALTERNATE","doNotCall":"","extension":"","effectiveDt":"","recordCreateSource":""},{"phoneType":"UNKNOWN","phoneNumber":"","phoneRole":"FAX","doNotCall":"","extension":"","effectiveDt":"","recordCreateSource":""},{"phoneType":"UNKNOWN","phoneNumber":"","phoneRole":"TEXT","doNotCall":"","extension":"","effectiveDt":"","recordCreateSource":""}],"phoneInfo":"","address":{"validAddrInd":"","country":"","city":"","state":"","addressLine1":"","addressLine2":"","ValidAddrInd":"","zipCode":"","latitude":"","longitude":"","CareOfAddress":"","DeliverableFlag":"DELIVER"},"permissions":"","magazineSubscription":"","profileLastUpdated":"","profileLastUpdatedSource":"","profileLastUpdatedUser":"","pmaLexusDealer":"","pmaScionDealer":"","pmaToyotaDealer":"","VehicleMakeModel":"","DeceasedInd":"","disposedVehicles":[],"dealershipDetails":"","socialMediaDetails":[]};
			} else {
				var customerData = angular.copy($rootScope.Newcustomer);
			}
			// $rootScope.editCustomerDetails same scope name used for both Add & Edit
			$rootScope.editCustomerDetails = JSON.parse(JSON.stringify(customerData).replace(/null/g, "\"\""));
			angular.forEach($rootScope.editCustomerDetails, function(value, key) {
				if(key == 'phone') {
					angular.forEach(value, function(phoneObj, phoneKey) {
						angular.forEach(phoneObj, function(x, y) {
							if(y == 'phoneType')
								phoneObj[y] = "UNKNOWN";
							else if(y != 'phoneRole')
								phoneObj[y] = "";
						}); 
					});				
				} else if(key == 'customerType'){
					$rootScope.editCustomerDetails[key] = "PERSON"; 
				} else if(key == 'socialMediaDetails') {
					$rootScope.editCustomerDetails['socialMediaDetails'] = [];
					$rootScope.editCustomerDetails['socialMediaDetails'].push({"customerSocialMediaEmailId": "", "socialMediaId": "", "socialMediaSiteName": "", "socialMediaSiteStatus": "", "socialMediaSiteId": "", "socMediaSiteStatus": "", "socialMediaUserName": "", "socialMediaURL": "", "dbSiteDetails": "" });
				} else if(key != 'address' && key != 'customerId' && key != 'vehicles' && key != 'disposedVehicles' ) {
					$rootScope.editCustomerDetails[key] = "";
				}
			});
			// Begin : Get All Vehicles Vin - Used in DDL
			$rootScope.allVehiclesVin	= [];
			$scope.tempVinArray			= [];
			// Current
			$rootScope.editCustomerDetails.vehicles =  $filter('orderBy')($rootScope.editCustomerDetails.vehicles, '-purchaseDate');
			angular.forEach($rootScope.editCustomerDetails.vehicles, function(value, key) {
				$rootScope.allVehiclesVin.push({"vin": value.vin, "make":(value.modelYear+' '+value.brand+' '+value.model), "effDate":value.effectiveDate});
				$scope.tempVinArray.push(value.vin);
			});
			// Disposed
			$rootScope.editCustomerDetails.disposedVehicles =  $filter('orderBy')($rootScope.editCustomerDetails.disposedVehicles, '-disposalDate');
			angular.forEach($rootScope.editCustomerDetails.disposedVehicles, function(value, key) {
				if($scope.tempVinArray.indexOf(value.vin) < 0) { // Remove duplicate
					$rootScope.allVehiclesVin.push({"vin": value.vin, "make":(value.modelYear+' '+value.brand+' '+value.model), "effDate":value.effectiveDate});
					$scope.tempVinArray.push(value.vin);
				}
			});
			 // Orphan  VIN View
			if($rootScope.vinView == true) {
				if($scope.tempVinArray.indexOf($rootScope.vin) < 0) { // Remove duplicate
					$rootScope.allVehiclesVin.push({"vin": $rootScope.vin, "make":($rootScope.modelyear+' '+$rootScope.brand+' '+$rootScope.modelname), "effDate":''});
					$scope.tempVinArray.push($rootScope.vin);
				}
			}
			// set ownereffective date
			angular.forEach($rootScope.allVehiclesVin, function(value, key) {
				if($rootScope.selectedVin == value.vin) {
					$rootScope.ownerEffectiveDate = value.effDate;
				}
			});
			// Ends
			$rootScope.editCustomerDetails.distributor = "";
			$rootScope.editCustomerDetails.role = "OWNER";
			$rootScope.editCustomerDetails.effectiveDate = " ";	// Empty space is required
			$timeout(function() {
				$('#editProfileView').scrollTop(0);
				$('#textChannelPhone_phoneNo').prop("readonly", true);
				setScrollViewport();
			},500);
		}
		// Begin: Remove Owner
		$scope.remove_errMsg = '';
		$scope.getRemoveCustomerDetails = function(type) {
			if($(".remove-customer").is(":visible") && type == 'Customer') return false;
			CustomerUpdateService.getRemoveCustomer(cust_id, $rootScope.selectedVin, $rootScope.roleType).then(function(data){
				if(data.status == "FAILURE") {
					$scope.remove_errMsg = data.message;
				} else {
					$scope.removeCustomerData		= data;
					//$scope.removeCustomerData		= {"firstVin":"JTJBM7FX2G5148431","serializedProductId":186945881,"status":"SUCCESS","message":null,"vinList":[{"vin":"JTJBM7FX2G5148431","make":"LEXUS","model":"GX 460","modelYear":"2016"}],"customerViewList":[[{"firstNm":"LAWRENCE","lastNm":"CHARLES","organizationNm":null,"salutation":null,"nameSuffix":null,"productRole":"OWNER","effectiveDt":"04/12/2017","expirationDt":"04/12/2017","customerProductAssocId":178876841,"customerId":131647957,"eventId":700834675,"distributor":"TDPR"}]],"customerEditList":[{"firstNm":"HERRY","lastNm":"PERRY","organizationNm":null,"salutation":null,"nameSuffix":null,"productRole":"OWNER","effectiveDt":"04/13/2017","expirationDt":null,"customerProductAssocId":178877802,"customerId":133990770,"eventId":700835496,"distributor":"TDPR"},{"firstNm":"MANJIT","lastNm":"KAUR","organizationNm":null,"salutation":null,"nameSuffix":null,"productRole":"OWNER","effectiveDt":"08/22/2016","expirationDt":null,"customerProductAssocId":175253426,"customerId":129790561,"eventId":643192390,"distributor":"US"},{"firstNm":"PUNEET","lastNm":"GIRI","organizationNm":null,"salutation":null,"nameSuffix":null,"productRole":"DRIVER","effectiveDt":"08/22/2016","expirationDt":null,"customerProductAssocId":175253425,"customerId":129790562,"eventId":643192390,"distributor":"US"}]};
					$scope.resetRemoveCustomerData	= angular.copy($scope.removeCustomerData);
					$timeout(function() {
						angular.forEach($scope.removeCustomerData.customerEditList, function(value, key) {
							if(value.expirationDt != '' && value.expirationDt != null) {
								$('#sold_date_'+(key+1)).prop('disabled', true).addClass('sold');
								$('#role_'+(key+1)).prop('disabled', true);
							} else {
								$('#sold_date_'+(key+1)).addClass('notsold');
								$('#undispose_'+(key+1)).prop('disabled', true);
							}
						});
					}, 500);
				}
			});
		}
		$scope.resetRemoveOwnerDetails = function() {
			var resetData = angular.copy($scope.resetRemoveCustomerData);
			$scope.removeCustomerData = resetData;
			$timeout(function() {
				angular.forEach($scope.removeCustomerData.customerEditList, function(value, key) {
					if(value.expirationDt != '' && value.expirationDt != null) {
						$('#sold_date_'+(key+1)).prop('disabled', true).addClass('sold');
						$('#role_'+(key+1)).prop('disabled', true);
					} else {
						$('#sold_date_'+(key+1)).addClass('notsold');
						$('#undispose_'+(key+1)).prop('disabled', true).prop('checked', false);
					}
				});
			}, 500);
		}
		// End: Remove Owner
		
		// Begin : Preferences 
		$scope.modDataId = [];
		$scope.preferenceViewFlag = false;
		$scope.setAddPreference = function() {
			// Begin : To reset previously selected values
			$scope.selectPreferences();
			$scope.customPreferences();
			// Ends
			$scope.preferenceViewFlag = !$scope.preferenceViewFlag;
		}
		$scope.selectPreferences = function() {
			$scope.modDataId = [];
			CustomerUpdateService.getSelectPrefernce(cust_id).then(function(data){
				$scope.preferencesData = data;
			});
		}
		$scope.customPreferences = function() {
			$scope.modDataId = [];
			CustomerUpdateService.getCustomerPrefernce(cust_id).then(function(data){
				$scope.customPreferencesData = data;
				$timeout(function() {
					angular.forEach($scope.customPreferencesData.response, function(element, x) {
						angular.forEach($scope.customPreferencesData.child['C'+element.id], function(parentObj, y) {
							var id			= parentObj.id;
							//var selFreq	= parentObj.freqSelect;
							var selFreq		= $filter('titleCase')(parentObj.freqSelect); // Because Frequency Dropdown options always comes in Titlecase, so we are changing parentObj.freqSelect value to Titlecase
							var selChannel	= parentObj.channelSelect;
							if(selFreq != '' && selFreq != null) {
								$('#freq_'+id+' option[value="'+selFreq+'"]').attr('selected', true);
								//$("input[name=freq_"+id+"][value='"+selFreq+"']").attr('checked', true);
								$scope.modDataId.push(id);
							}
							if(selChannel != '' && selChannel != null) {
								angular.forEach(selChannel, function(value, key) {
									//$('#channel_'+id+' option[value="'+value+'"]').attr('checked', true);
									$("input[name=channel_"+id+"][value='"+value+"']").attr('checked', true);
								});
							}
						});
						//console.log($scope.modDataId);
					});
				},500);
			});
		}
		$scope.checkboxCheck = function(id) {
			// Clear error
			$("#freq_"+id).val('').css("border","1px solid #ddd");
			$("input[name=channel_"+id+"]").attr('checked',false);
			$("#tag_channel_"+id).css("border","none");
			if($('#Checkbox_'+id).is(':checked')) {
				$('#tag_frequency_'+id).css('display', 'block');
				$('#tag_channel_'+id).css('display', 'block');
				$scope.modDataId.push(id);
			} else {
				$('#tag_frequency_'+id).css('display', 'none');
				$('#tag_channel_'+id).css('display', 'none');
				$scope.modDataId = $.grep($scope.modDataId, function(value) {
					return value != id;
				});
			}
			console.log($scope.modDataId);
		}
		$scope.radioCheck = function(parentId, currChildId) {
			if($('#Checkbox_'+parentId) != undefined) {
				$('#Checkbox_'+parentId).attr('disabled','disabled');
				$('#Checkbox_'+parentId).attr('checked',false);
				$scope.checkboxCheck(parentId);
			}
			var radioRows	= $('input[name="Radio_'+parentId+'"]');
			radioRows		= $.unique(radioRows);
			for(i=0;i<radioRows.length;i++) {
				var childId = $(radioRows[i]).attr('data-childId')
				$scope.modDataId = $.grep($scope.modDataId, function(value) {
					return value != childId;
				});
				$('#tag_frequency_'+childId).hide();
				$('#tag_channel_'+childId).hide();
			}
			$('#tag_frequency_'+currChildId).css('display', 'block');
			$('#tag_channel_'+currChildId).css('display', 'block');
			$scope.modDataId.push(currChildId);
			console.log($scope.modDataId);
		}
		$scope.addEditPreferences = function(id) {
			$('#add_'+id).removeClass().addClass('link').hide();
			$('#editDel_'+id).removeClass().show();
			$('#selected_freq_'+id).hide();
			$('#selected_channel_'+id).hide();
			$('#tag_frequency_'+id).css('display', 'block');
			$('#tag_channel_'+id).css('display', 'block');
			$scope.modDataId.push(id);
		}
		$scope.deletePreferences = function(id) {
			$('#selected_freq_'+id).text('').hide();
			$('#selected_channel_'+id).text('').hide();
			$("#freq_"+id).val('');
			$("input[name=channel_"+id+"]").attr('checked',false);
			$('#editDel_'+id).removeClass().hide();
			$('#add_'+id).removeClass().addClass('link').show();
			$('#tag_frequency_'+id).hide();
			$("#freq_"+id).val("");
			$('#tag_channel_'+id).hide();
			$("#channel_"+id).val("");
			$scope.modDataId = $.grep($scope.modDataId, function(value) {
				return value != id;
			});
		}
		$scope.consolidatePreferenceData = function(type) { // Same method used for both Add & Edit(Custom) preference
			$scope.modDataId	= $.unique($scope.modDataId);
			console.log($scope.modDataId);
			var data			= "**";
			var submitFlag		= true;
			if($scope.modDataId.length > 0) {
				angular.forEach($scope.modDataId, function(id, key) {
					$("#freq_"+id).css("border","1px solid #ddd");
					$("#tag_channel_"+id).css("border","none");
					if($("#freq_"+id).is(":visible")) {
						if($("#freq_"+id).val() == '' || $("#freq_"+id).val() == null) {
							$("#freq_"+id).css("border","1px solid red");
							submitFlag	= false;
						}
					} else {
						if($("#selected_freq_"+id).text() == '' || $("#selected_freq_"+id).text() == null) {
							$("#freq_"+id).css("border","1px solid red");
							submitFlag	= false;
						}
					}
					if($("input[name=channel_"+id+"]").is(':checked') == false) {
						$("#tag_channel_"+id).css("border","1px solid red");
						submitFlag	= false;
					}
					var selChannels	= $("input[name=channel_"+id+"]:checked").map(function() { return this.value; }).get().join(',');
					if($("#freq_"+id).is(":visible")) {
						var selFreq		= $("#freq_"+id).val();
					} else {
						var selFreq		= $("#selected_freq_"+id).text();
					}
					if(type == 'Add') {
						data = data + id + "**" + $("#prefName_"+id).val()+"**"+ selFreq +"**"+ selChannels +"**"+ $("#prefBrand_"+id).val()+"**";
					} else {
						data = data + id + "**Edit**" + $("#prefName_"+id).val()+"**"+ selFreq +"**"+ selChannels +"**"+ $("#prefBrand_"+id).val()+"**";
					}
				});
				console.log(data);
				if(submitFlag) {
					if(type == 'Add') {
						return data;
					} else {
						$('#customerPreferenceData').val(data);
						return true;
					}
				} else {
					//alert('Please fill all required fields highlighted.');
					$rootScope.customAlertPopup('Please fill all required fields highlighted.');
					$("#errorFlag").val(1);
					return false;
				}
			} else {
				if(type == 'Add') {
					$scope.setAddPreference(); // Close Add Preferences screen
					return;
				} else {
					$('#customerPreferenceData').val(data);
					return true;
				}
			}
		}
		$scope.savePreferences = function() {
			var data = $scope.consolidatePreferenceData('Add');
			console.log(data);
			if(data != undefined && data != false) {
				CustomerUpdateService.saveSelectPrefernce(cust_id, data).then(function(data){
					var response = data;
					if(response != '"Failure"') {
						// close add preference & load custom preference data
						$scope.setAddPreference();
					}
				});
			}
		}
		$scope.expandPreference = function(event, id) {
			if($(event.target).hasClass('expand')) {
				$(event.target).removeClass('expand').addClass('collapse');
				$('#preference_'+id).hide();
			} else {
				$(event.target).removeClass('collapse').addClass('expand');
				$('#preference_'+id).show();
			}
		}
		$scope.expandCollapseChildPreference = function(event, id) {
			if($(event.target).hasClass('minus')) {
				$(event.target).removeClass('minus').addClass('plus').text('Expand');
				$('#child_of_'+id).hide();
			} else {
				$(event.target).removeClass('plus').addClass('minus').text('Collapse');
				$('#child_of_'+id).show();
			}
		}
		$scope.validatePreferencePermission = function(id) {
			var brand		= $('#prefBrand_'+id).val();
			var category	= $('#permCategory_'+id).val();
			//var selDataVal	= $('#channel_'+id).val();
			var selDataVal	= $("input[name=channel_"+id+"]:checked").map(function() { return this.value; }).get().join(',');
			selDataVal = selDataVal.split(",");
			var selData		= '';
			var compareId	= '';
			if(brand != null && category != null && selDataVal !=undefined && selDataVal.length > 0){
				for(i=0; i < selDataVal.length; i++) {
					selData = selDataVal[i];
					selData = selData.toLowerCase();
					if(selData == 'e-mail'){
						selData = 'email';
					}
					brand		= brand.toLowerCase();
					category	= category.charAt(0).toUpperCase() + category.substr(1).toLowerCase();
					compareId	= selData+'Permissions_'+brand+category+'Value';
					if(selData != null && compareId !=null && $('#'+compareId).val() == 'OUT'){
						brand	= brand.charAt(0).toUpperCase() + brand.substr(1).toLowerCase();
						//alert(selData.toUpperCase()+' is opted out for '+brand+' under '+category+' category');
						$rootScope.customAlertPopup(selData.toUpperCase()+' is opted out for '+brand+' under '+category+' category');
						$('#channel_'+id).val('');
					}
				}
			}
		}
		// End : Preferences
	});
	$scope.setSelectedVin = function(vehicle) {
		$rootScope.ownerEffectiveDate	= vehicle.effDate;
		$rootScope.selectedVin			= vehicle.vin;
	}
	$scope.setTextChannelPhState = function(state) {
		var state = (state == undefined)? '':state;
		var textPermToyotaServiceValue		= $("#textPermissions_toyotaServiceValue").val();
		var textPermScionServiceValue		= $("#textPermissions_scionServiceValue").val(); 
		var textPermToyotaMarketingValue	= $("#textPermissions_toyotaMarketingValue").val(); 
		var textPermLexusMarketingValue		= $("#textPermissions_lexusMarketingValue").val(); 
		var textPermScionMarketingValue		= $("#textPermissions_scionMarketingValue").val();
		// Among 5 element, if any one element value is IN or LIMITED
		if((textPermToyotaServiceValue == 'IN' || textPermToyotaServiceValue == 'LIMITED') || (textPermScionServiceValue == 'IN' || textPermScionServiceValue == 'LIMITED') || (textPermToyotaMarketingValue == 'IN' || textPermToyotaMarketingValue == 'LIMITED') || (textPermLexusMarketingValue == 'IN' || textPermLexusMarketingValue == 'LIMITED') || (textPermScionMarketingValue == 'IN' || textPermScionMarketingValue == 'LIMITED')) {
			$('#textChannelPhone_phoneNo').prop("readonly", false).removeClass('readonly');
		} else {
			$('#textChannelPhone_phoneNo').prop("readonly", true).addClass('readonly').removeClass('error_focus');
			if(state != 'INIT') {
				$('#textChannelPhone_phoneNo').val("");
			}
		}
	}
	$scope.setStateDD = function() {
		var temp_state = $rootScope.editCustomerDetails.address.state;
		$rootScope.editCustomerDetails.address.state = "";
		if($rootScope.editCustomerDetails.address.country == 'USA') {
			$scope.states = $scope.ddl.UsaStates;
		} else if($rootScope.editCustomerDetails.address.country == 'MEX') {
			$scope.states = $scope.ddl.MexStates;
		} else if($rootScope.editCustomerDetails.address.country == 'CAN') {
			$scope.states = $scope.ddl.CanStates;
		}
		$timeout(function() {
			if(temp_state != undefined)
				$rootScope.editCustomerDetails.address.state = temp_state.toString();
		},50);
	}
	$scope.getStateValue = function(){
		var state = $rootScope.editCustomerDetails.address.state;
		if($scope.states != undefined) {
			var myArray = $scope.states;
			for (var i=0; i < myArray.length; i++) {
				if (myArray[i].key === state) {
					$('.state_label').val(myArray[i].value);
					return true;
				}
			}
		}
		return false;
	}
	$scope.phoneTypeChange = function(type) {
		// $rootScope.editCustomerDetails.phone - Array contains primary, alternate, fax, text phone
		// 0 - Primary, 1- Alternate, 2- Fax, 3 - Text phone
		if(type == 'Primary') {
			var index = 0;
			var extId = 'primaryPhone_extension';
		} else {
			var index = 1;
			var extId = 'alternatePhone_extension';
		}
		var phoneType = $rootScope.editCustomerDetails.phone[index].phoneType;
		var phoneValue = $rootScope.editCustomerDetails.phone[index].phoneNumber;
		if(phoneType == "MOBILE"){	
			$('#'+extId).val("");
			$('#'+extId).prop('disabled', true);
		} else {
			$('#'+extId).prop('disabled', false);
		}			
		if(phoneValue == null || phoneValue == '') {
			$timeout(function(){
				$rootScope.editCustomerDetails.phone[index].phoneType = "UNKNOWN";
				$('#'+extId).prop('disabled', false);
				return;
			},300);
		}
	}
	$scope.setPhoneExtAndType = function(type) {
		// $rootScope.editCustomerDetails.phone - Array contains primary, alternate, fax, text phone
		// 0 - Primary, 1- Alternate, 2- Fax, 3 - Text phone
		if(type == 'Primary') {
			$('#primaryPhone_extension').prop('disabled', false);
			$rootScope.editCustomerDetails.phone[0].phoneType = "UNKNOWN";
		} else {
			$('#alternatePhone_extension').prop('disabled', false);
			$rootScope.editCustomerDetails.phone[1].phoneType = "UNKNOWN";
		}
	}	
	// Begin : Social Media functions
	$scope.addRow = function() {
		var length = $rootScope.editCustomerDetails.socialMediaDetails.length;
		$rootScope.editCustomerDetails.socialMediaDetails[length] = { "customerSocialMediaEmailId": "", "socialMediaId": "", "socialMediaSiteName": "", "socialMediaSiteStatus": "", "socialMediaSiteId": "", "socMediaSiteStatus": "", "socialMediaUserName": "", "socialMediaURL": "", "dbSiteDetails": "" };
		console.log($rootScope.editCustomerDetails.socialMediaDetails);
	}
	$scope.deleteRow = function(socialMediaID, index) {
		// Remove row
		$rootScope.editCustomerDetails.socialMediaDetails.splice(index,1);
		// socialMediaID - Existing Record
		if(socialMediaID != '' && socialMediaID != null){
			var delIds = '';
			delIds = $("#socialMediaDeletedData").val();
			delIds = delIds + socialMediaID + ";";
			$("#socialMediaDeletedData").val(delIds);
		}
		if($rootScope.editCustomerDetails.socialMediaDetails.length == 0) {
			$scope.addRow();
		}
	}
	$scope.setSocialMediaSiteName = function(obj, index) {
		// $scope.ddl.SocMediaSiteDtlsList
		var socialMediaArray = {"1":"FACEBOOK", "2":"TWITTER", "3":"YOUTUBE"};
		if(obj.socialMediaSiteId != '') {
			obj.socialMediaSiteName		= $('#sm-dropdown-list-'+index).find("li[data-value='" + obj.socialMediaSiteId + "']").text();
			obj.socialMediaSiteStatus	= (socialMediaArray[obj.socialMediaSiteId] != undefined)? 'ACTIVE' : '';
			if(obj.socialMediaSiteName == 'OTHERS'){
				$('#addOthersMedia_'+index).show();
			} else {
				$('#addOthersMedia_'+index).hide();
			}
		} else {
			obj.socialMediaSiteName		= '';
			obj.socialMediaSiteStatus	= '';
		}
	}
	$scope.optCnt = 1;
	$scope.addOptionToDropdown = function(index, obj) {
		var newSocialMedia = $('#otherSocialMedia_'+index).val().toUpperCase();
		var id = 'new_'+$scope.optCnt;
		if( newSocialMedia != '') {
			var newOption = '<li id="'+id+'" data-value="0">'+newSocialMedia+'</li>';
			$('#sm-dropdown-list-'+index+' ul').append(newOption);
			$('#OthersTxtHidden_'+index).val(newSocialMedia);
			$('#otherSocialMedia_'+index).val('');
			$('#addOthersMedia_'+index).hide();
			$scope.optCnt = $scope.optCnt + 1;
			obj.socialMediaSiteId = '0';
			$timeout(function() {
				//$('#'+id).attr('selected', true);
				$('#social_media_site_'+index+'_label').val(newSocialMedia);
				$('#sm-dropdown-list-'+index).find("li.selected").removeClass('selected');
				$('#'+id).addClass('selected');
			},500);
			obj.socialMediaSiteName	 = 'OTHERS';
		} else {
			ValidationService.displayError('Social Media information is incomplete. Please enter the missing information','social_media_msg_'+index, 'social_media_site_'+index+'_label');
		}
	}
	// End : Social Media functions
	
	// Begin : Communication Permission functions
	$scope.emailDataValidation = function(element, oldValue) {
		var elementValue = element.indicator;
		var emailDataInvalidMsg = 'Please Provide your Email Address to Complete Your Authorization For Receiving Information Via Email';
		if(elementValue == 'IN' || elementValue == 'LIMITED' ) {
			if(($rootScope.editCustomerDetails.email.length == 0) || ($rootScope.editCustomerDetails.email[0].emailAddress == '' || $rootScope.editCustomerDetails.email[0].emailAddress == null)) {
				$scope.initialisePopupVariables();
				$rootScope.commPermissionsConfirmationFlag	= true;
				DealerviewPopup({
					id: 'vehicleOwnershipDialog',
					templateUrl:'views/confirmationPopup.html',
					title : emailDataInvalidMsg, backdropCancel : false, modalClass : "popup_container", css: { width: "570px" },
					success: {
						fn: function() {
							$timeout(function() {
								$rootScope.$broadcast('showDetailsMenuTab', 1); // 1 - Address, 2 - Permission, 3 - Preferences
								$timeout(function() { $("#customerEmailAddress_emailAddress_emailAddress").addClass('error_focus').focus(); }, 500);
							}, 300);
						}
					},
					cancel: {
						fn: function() {
							element.indicator = oldValue;
						}
					}
				});
			}
			return false;
		}
	}
	$scope.phoneDataValidation = function(element, oldValue) {
		var elementValue = element.indicator;
		var phoneDataInvalidMsg = 'Please Provide your Phone Number  to Complete Your Authorization For Receiving Information Via Phone';
		var primaryPhone 	= $rootScope.editCustomerDetails.phone[0].phoneNumber;
		var alternatePhone	= $rootScope.editCustomerDetails.phone[1].phoneNumber;
		if(primaryPhone == '' && alternatePhone == '') {
			if(elementValue == 'IN' || elementValue == 'LIMITED' ) {
				$scope.initialisePopupVariables();
				$rootScope.commPermissionsConfirmationFlag	= true;
				DealerviewPopup({
					id: 'vehicleOwnershipDialog',
					templateUrl:'views/confirmationPopup.html',
					title : phoneDataInvalidMsg,
					backdropCancel : false,
					modalClass : "popup_container",
					css: { width: "570px" },
					success: {
						fn: function() {
							$timeout(function() {
								$rootScope.$broadcast('showDetailsMenuTab', 1); // 1 - Address, 2 - Permission, 3 - Preferences
								$timeout(function() { $("#primaryPhone_phoneNo").addClass('error_focus').focus(); }, 500);
							}, 300);
						}
					},
					cancel: {
						fn: function() {
							element.indicator = oldValue;
						}
					}
				});
				return false;
			}
		}
	}
	$scope.mailDataValidation = function(element, oldValue) {
		var elementValue = element.indicator;
		var mailDataInvalidMsg = 'Please Provide Your Postal Address to Complete Your Authorization For Receiving Information Via Mail';
		if(elementValue == 'IN' || elementValue == 'LIMITED' ) {
			if(($rootScope.editCustomerDetails.address == null || $rootScope.editCustomerDetails.address == '') || ($rootScope.editCustomerDetails.address.addressLine1 == '' || $rootScope.editCustomerDetails.address.zipCode == '')) {
				$scope.initialisePopupVariables();
				$rootScope.commPermissionsConfirmationFlag	= true;
				DealerviewPopup({
					id: 'vehicleOwnershipDialog',
					templateUrl:'views/confirmationPopup.html',
					title : mailDataInvalidMsg,
					backdropCancel : false,
					modalClass : "popup_container",
					css: { width: "570px" },
					success: {
						fn: function() {
							$timeout(function() {
								$rootScope.$broadcast('showDetailsMenuTab', 1); // 1 - Address, 2 - Permission, 3 - Preferences
								$timeout(function() {
									$("#customerPostalAddress_postalAddress_addressLine1").addClass('error_focus').focus();
									$("#customerPostalAddress_postalAddress_postalCd").addClass('error_focus').focus();
								}, 500);
							}, 300);
						}
					},
					cancel: {
						fn: function() {
							element.indicator = oldValue;
						}
					}
				});
			}
			return false;
		}
	}
	$scope.textDataValidation = function(element, oldValue) {
		var elementValue = element.indicator;
		var textDataInvalidMsg = 'Please Provide Your Text Phone Number to Complete Your Authorization For Receiving Information Via Text';
		var textChannelPhone = $rootScope.editCustomerDetails.phone[3].phoneNumber;
		if(textChannelPhone == '') {
			if(elementValue == 'IN' || elementValue == 'LIMITED' ) {
				$scope.initialisePopupVariables();
				$rootScope.commPermissionsConfirmationFlag	= true;
				DealerviewPopup({
					id: 'vehicleOwnershipDialog',
					templateUrl:'views/confirmationPopup.html',
					title : textDataInvalidMsg,
					backdropCancel : false,
					modalClass : "popup_container",
					css: { width: "570px" },
					success: {
						fn: function() {
							$timeout(function() {
								$rootScope.$broadcast('showDetailsMenuTab', 1); // 1 - Address, 2 - Permission, 3 - Preferences
								$timeout(function() { $("#textChannelPhone_phoneNo").addClass('error_focus').focus(); }, 500);
							}, 300);
						}
					},
					cancel: {
						fn: function() {
							element.indicator = oldValue;
						}
					}
				});
				return false;
			}
		}
	}
	$scope.onChangeToyotaSurveyState = function(elementValue) {
		angular.forEach($rootScope.editCustomerDetails.permissions.survey, function(value, key) {
			value.toyota.indicator = elementValue;
		});
	}
	$scope.onChangeLexusSurveyState = function(elementValue) {
		angular.forEach($rootScope.editCustomerDetails.permissions.survey, function(value, key) {
			value.lexus.indicator = elementValue;
		});
	}
	$scope.onChangeScionSurveyState = function(elementValue) {
		angular.forEach($rootScope.editCustomerDetails.permissions.survey, function(value, key) {
			value.scion.indicator = elementValue;
		});
	}
	// End : Communication Permission functions
	
	// Begin : Houssehold functions
	var selectedHouseHoldCustomerArray = [];
	$scope.selectedHouseHoldCustomer = function(hhCustId) {
		if ($('#hh_customer_'+hhCustId).is(':checked')) {
			selectedHouseHoldCustomerArray.push(hhCustId);
		} else {
			var index = selectedHouseHoldCustomerArray.indexOf(hhCustId);
			if(index !== -1) {
				selectedHouseHoldCustomerArray.splice(index,1);
			}
		}
		$('#selectedCustomerHouseHold').val(selectedHouseHoldCustomerArray);
	}
	// End : Houssehold functions
	
	// Begin : Common Methods
	$scope.validatePhoneNumber = function(elementId, elemName, errElement) {
		var element 	= $('#'+elementId);
		var elementVal	= $.trim($('#'+elementId).val());
		if(elementVal == '' || elementVal == null) return true;
		if(ValidationService.checkRegexp(elementId, phoneExp, elemName, errElement)) {
			elementVal			= $scope.removeSpecialChar(elementVal);
			var tripleNineCheck	= elementVal.substring(0,3);
			var doubleNumCheck	= elementVal.substring(1,3);
			//May not area code, start with 0 or 1 or 999 or X11
			if(elementVal.charAt(0) == '0' || elementVal.charAt(0) == '1' || tripleNineCheck == '999' || doubleNumCheck == '11') {
				ValidationService.displayError(elemName + " contains invalid characters.", errElement, element);
				return false;
			}
			//var phoneTripleNineCheck = elementVal.substring(3,6);
			//May not start phNum, with 0 or 1 or 999
			if(elementVal.charAt(3) == '0') {
				ValidationService.displayError(elemName + " contains invalid characters.", errElement, element);
				return false;
			}
			//all X's checking i.e., 2s through 9s
			if(elementVal.length > 1) {
				var fistChar = elementVal.charAt(0);
				var flagCheck = false;
				for(i=0; i< elementVal.length; i++) {
					if(elementVal.charAt(i) != fistChar) {
						flagCheck = true;
						break;
					}
				}
				if(!flagCheck) { // false
					ValidationService.displayError(elemName + " contains invalid characters.", errElement, element);
					return false;
				}
			}
			if(elementVal.length < 10) {
				ValidationService.displayError(elemName + " must be 10 characters.", errElement, element);
				return false;
			}
		} else {
			return true;
		}
	}
	$scope.removeSpecialChar = function(phoneNumner) {
		var validNumber = "0123456789";
		var finalPhoneStr = "";
		for(i=0; i < phoneNumner.length; i++) {
			var _char = phoneNumner.charAt(i);
			if(validNumber.indexOf(_char)!=-1) {
				finalPhoneStr = finalPhoneStr+_char;
			}
		}
		return finalPhoneStr;
	}
	$scope.serializeObject = function(formName) {
		var o = {};
		var formData = $("#"+formName).serializeArray();
		$.each(formData, function() {
			var temp_id = this.name;
			// if(!$('#'+temp_id).hasClass('exclude')) { // remove unwanted post data
			if(!$("input[name="+temp_id+"], select[name="+temp_id+"]").hasClass('exclude')) { // remove unwanted post data
				if (o[this.name] !== undefined) {
					if (!o[this.name].push) {
						o[this.name] = [o[this.name]];
					}
					o[this.name].push(this.value || '');
				} else {
					o[this.name] = this.value || '';
				}
			}
		});
		return o;
	};
	// End : Common Methods
	
	$scope.consolidateSocialMedia = function() {
		var sm_data	= '';
		if($("#socialMediaDeletedData").val() != '') {
			$scope.removedSocialMedia = $("#socialMediaDeletedData").val().split(";");
		} else {
			$scope.removedSocialMedia = [];
		}
		console.log($rootScope.editCustomerDetails.socialMediaDetails);
		angular.forEach($rootScope.editCustomerDetails.socialMediaDetails, function(value, key) {
			if(value.socialMediaUserName != '' && value.socialMediaUserName != null) {
				if(value.socialMediaId != '' && value.socialMediaId != null) {
					sm_data = sm_data + value.socialMediaId + "()";
				} else {
					sm_data = sm_data + "NEW" + "()";
				}
				if(value.socialMediaSiteName != '' && value.socialMediaSiteName != null) { // yet to done
					sm_data = sm_data + value.socialMediaSiteName + "()";
				}
				if(value.socialMediaUserName != '' && value.socialMediaUserName != null) {
					sm_data = sm_data + value.socialMediaUserName + "()";
				}
				if(value.socialMediaURL != '' && value.socialMediaURL != null) {
					sm_data = sm_data + value.socialMediaURL + "()";
				} else {
					sm_data = sm_data + "EMPTY" + "()";
				}
				if(value.customerSocialMediaEmailId != '' && value.customerSocialMediaEmailId != null) {
					sm_data = sm_data + value.customerSocialMediaEmailId + "()";
				} else {
					sm_data = sm_data + "NEW" + "()";
				}
				if((value.socialMediaSiteId != '' && value.socialMediaSiteId != null) && value.socialMediaSiteId != '0') { // Dropdown value
					sm_data = sm_data + value.socialMediaSiteId + "()";
				} else {
					sm_data = sm_data + "NEW" + "()";
				}
				if(value.socialMediaSiteStatus != '' && value.socialMediaSiteStatus != null) { // To de done
					sm_data = sm_data + value.socialMediaSiteStatus + "()";
				} else {
					sm_data = sm_data + "INACTIVE" + "()";
				}
				if(value.socialMediaSiteName == 'OTHERS' || value.socialMediaId != '') {
					if(value.socialMediaSiteName == 'OTHERS')
						sm_data = sm_data + $('#OthersTxtHidden_'+(key+1)).val() + "()";
					else
						sm_data = sm_data + value.socialMediaSiteName + "()";
				}
				sm_data = sm_data + "**";
			} else {
				if(value.socialMediaId != '' && value.socialMediaId != null) {
					var tempId = value.socialMediaId.toString();
					if($scope.removedSocialMedia.indexOf(tempId) < 0) {
						var delIds = $("#socialMediaDeletedData").val();
						delIds = delIds + value.socialMediaId + ";";
						$("#socialMediaDeletedData").val(delIds);
					}
				}
			}
		});
		sm_data = sm_data.slice(0,-2);
		console.log(sm_data);
		$("#socialMediaConsolidatedData").val(sm_data);
		console.log("Deleted Ids : "+$("#socialMediaDeletedData").val());
	}
	$scope.compareDate = function(ownerEffDtValue, effDateValue, strDelimiter) {
		//Declare local variables
		var firstDate,secondDate,dd,mm,yy;
		//Splist the first date to its components
		firstDate = ownerEffDtValue.split(strDelimiter);
		mm = firstDate[0];
		dd = firstDate[1];
		yy = firstDate[2];
		firstDate = new Date(yy,mm-1,dd)
		//Splist the second date to its components
		secondDate = effDateValue.split(strDelimiter)
		mm = secondDate[0]
		dd = secondDate[1]
		yy = secondDate[2]
		secondDate = new Date(yy,mm-1,dd)
		//Compare the miliseconds in the dates
		if (parseInt(firstDate.valueOf()) <= parseInt(secondDate.valueOf()))
			return true;
		else
			return false;
	}
	/*
	Note: Validation functions available in app.js under 'ValidationService' factory.
	1. functionName : checkBlank('element Id', 'Element Name', 'ErrorMsg Element Id')
	2. functionName : checkRegexp('element Id', 'RegExp', 'Element Name', 'ErrorMsg Element Id')
	3. functionName : checkLengthof('element Id', 'Element Name', 'Min length', 'Max length', 'ErrorMsg Element Id')
	*/
	var isCustomerInfoChangeFlag = false;
	$scope.editCustomerFormValidation = function() {
		console.log("-------editCustomerFormValidation----------");
		$('.loader_outer, .loader_inner').show();
		$('.err_msg, #email_req, #phone_req').hide();
		$scope.addressFlag = $scope.phoneFlag = $scope.emailFlag = true;
		$rootScope.isAddressValidationFlag = false;
		$scope.consolidateSocialMedia();
		field_focus = '';
		$scope.validationMsg = '';
		$("#errorFlag").val(0);
		$('.error_focus').removeClass('error_focus');
		// Region - It should be validated only for 'Updating Vehicle Ownership' (Add)
		if($rootScope.customerAddFlag) {
			if($rootScope.roleType == 'US_TDPR') {
				if(!ValidationService.checkBlank('distributor', 'Region', 'distributor_msg')) {
					$scope.validationMsg = "Required Field(s) are Missing or Invalid.";
				}
			}
		}
		var customerType = $rootScope.editCustomerDetails.customerType;
		if(customerType == 'BUSINESS') {
			if(ValidationService.checkBlank('customer_organizationNm', 'Organization Name', 'customer_organizationNm_msg')) {
				if(ValidationService.checkRegexp('customer_organizationNm', orgNameExp, 'Organization Name', 'customer_organizationNm_msg')) {
					ValidationService.checkLengthof('customer_organizationNm', 'Organization Name', 2, 0, 'customer_organizationNm_msg');
				}
			} else {
				$scope.validationMsg = "Required Field(s) are Missing or Invalid.";
			}
		} else {
			// First name, Middle Initial & Last name
			if(ValidationService.checkBlank('customer_firstNm', 'First Name', 'customer_firstNm_msg')) {
				if(!ValidationService.checkRegexp('customer_firstNm', nameRegEx, 'First Name', 'customer_firstNm_msg')){
					$scope.validationMsg = "Required Field(s) are Missing or Invalid.";
				}
			} else {
				$scope.validationMsg = "Required Field(s) are Missing or Invalid.";
			}
			ValidationService.checkRegexp('customer_middleInitial', alphabets, 'Middle Initial', 'customer_middleInitial_msg');
			if(ValidationService.checkBlank('customer_lastNm', 'Last Name', 'customer_lastNm_msg')) {
				if(!ValidationService.checkRegexp('customer_lastNm', nameRegEx, 'Last Name', 'customer_lastNm_msg')){
					$scope.validationMsg = "Required Field(s) are Missing or Invalid.";
				}
			} else {
				$scope.validationMsg = "Required Field(s) are Missing or Invalid.";
			}
			// DeceasedInd - It should be validated only for 'Edit Profile'
			if($rootScope.customerEditFlag == true && $rootScope.isAddressValidationFlag == false) {
				if($rootScope.editCustomerDetails.DeceasedInd == 'Y' && $rootScope.Newcustomer.DeceasedInd != 'Y') {
					if($scope.deceasedIndicatorConfirmation == false) {
						$scope.isDeceasedIndChanged();
						$('.loader_outer, .loader_inner').hide();
						return false;
					}
				}
			}
		}
		// Role - It should be validated only for 'Updating Vehicle Ownership'
		if($rootScope.customerAddFlag) {
			ValidationService.checkBlank('addCustomerProductAssociation_customerProductRole', 'Customer Role', 'addCustomerProductAssociation_customerProductRole_msg');
			// Effective Date
			if(ValidationService.checkBlank('effectiveDate', 'Effective Date', 'effectiveDate_msg')) {
				var role				= $.trim($('#addCustomerProductAssociation_customerProductRole').val());
				var effectiveDate		= $.trim($('#effectiveDate').val());
				var ownerEffectiveDate	= $.trim($('#ownerEffectiveDate').val());
				if(role == 'DRIVER') {
					// Owner Effective Date
					if(ownerEffectiveDate == '' || ownerEffectiveDate == null) {
						//ValidationService.displayError('No owner exists.', 'effectiveDate_msg', 'effectiveDate');
						ValidationService.displayError('No owner exists.', 'addCustomerProductAssociation_customerProductRole_msg', 'addCustomerProductAssociation_customerProductRole');
					} else {
						if(!$scope.compareDate(ownerEffectiveDate, effectiveDate,'/')) { // False
							ValidationService.displayError("Driver's Start Date may not be before Owner's Start Date.", 'effectiveDate_msg', 'effectiveDate');
						}
					}
				}
			}
		}
		ValidationService.checkRegexp('customer_preferredNm', nameRegEx, 'Preferred Name', 'customer_preferredNm_msg');
		// Address
		if($.trim($('#customerPostalAddress_postalAddress_addressLine1').val()) == '' && $.trim($('#customerPostalAddress_postalAddress_city').val()) == '' && $.trim($('#customerPostalAddress_postalAddress_stateProvinceCd').val()) == '' && $.trim($('#customerPostalAddress_postalAddress_postalCd').val()) == '') {
			$scope.addressFlag = false;
		} else {
			if($rootScope.editCustomerDetails.address.addressLine1 != undefined && $rootScope.editCustomerDetails.address.addressLine1 != '') {
				ValidationService.checkLengthof('customerPostalAddress_postalAddress_addressLine1', 'Address Line 1', 2, 0, 'customerPostalAddress_postalAddress_city_msg');
			}
			if($rootScope.editCustomerDetails.address.city != undefined && $rootScope.editCustomerDetails.address.city != '') {
				ValidationService.checkLengthof('customerPostalAddress_postalAddress_city', 'City', 2, 0, 'customerPostalAddress_postalAddress_city_msg');
			}
		}
		// Phone & Fax
		if($.trim($('#primaryPhone_phoneNo').val()) == '' && $.trim($('#alternatePhone_phoneNo').val()) == '' && $.trim($('#textChannelPhone_phoneNo').val()) == '') {
			$scope.phoneFlag = false;
		} else {
			$scope.validatePhoneNumber('primaryPhone_phoneNo', 'Primary Phone Number', 'primary_phoneNo_msg');
			$scope.validatePhoneNumber('alternatePhone_phoneNo', 'Alternate Phone Number', 'alternate_phoneNo_msg');
			$scope.validatePhoneNumber('textChannelPhone_phoneNo', 'Text Phone Number', 'text_channel_phone_msg');
		}
		$scope.validatePhoneNumber('faxPhone_phoneNo', phoneExp, 'Fax Number', 'faxPhone_phoneNo_msg');
		// Email
		if($.trim($('#customerEmailAddress_emailAddress_emailAddress').val()) != '') {
			if(!ValidationService.checkRegexp('customerEmailAddress_emailAddress_emailAddress', emailExp, 'Email address', 'email_address_msg')) {
				if($scope.validationMsg == '')
					$scope.validationMsg = "Email ID is Invalid.";
			}
		} else {
			$scope.emailFlag = false;
		}
		// Socail media validation
		angular.forEach($rootScope.editCustomerDetails.socialMediaDetails, function(value, key) {
			if( ((value.socialMediaSiteId == '' || value.socialMediaSiteId == 'OTHERS') && (value.socialMediaUserName != '' || value.socialMediaURL != '')) || (value.socialMediaSiteId != '' && value.socialMediaUserName == '') ) {
				ValidationService.displayError('Social Media information is incomplete. Please enter the missing information','social_media_msg_'+(key+1), 'social_media_site_'+(key+1)+'_label');
				if((value.socialMediaSiteId == '' || value.socialMediaSiteId == 'OTHERS')) {
					$("#social_media_site_"+(key+1)+"_label").parents('div.dropdown-wrapper:first').addClass('error_focus');
				}
				if(value.socialMediaUserName == '') {
					$("#username_"+(key+1)).addClass('error_focus');
				}
			}
		});
		if(!$scope.addressFlag && !$scope.phoneFlag && !$scope.emailFlag) {
			$('#email_req, #phone_req').show();
			$("#customerPostalAddress_postalAddress_addressLine1, #customerPostalAddress_postalAddress_city, #customerPostalAddress_postalAddress_stateProvinceCd_label, #customerPostalAddress_postalAddress_postalCd, #primaryPhone_phoneNo, #customerEmailAddress_emailAddress_emailAddress").addClass('error_focus');
			$('.loader_outer, .loader_inner').hide();
			var scrollPos = $('#customer_additional_info').offset().top - $('#customer-update').offset().top - 10;
			$('#editProfileView').scrollTop(scrollPos);
			return false;
		}
		if($("#errorFlag").val() == 0) { // Form validation - Success
			$('.loader_outer, .loader_inner').show();
			// Adding New Customer
			if($rootScope.customerAddFlag) {
				$scope.submitEditCustomerForm();
			} else { // Editing Existing Customer
				// Custom Preferences Validation
				var prefFlag = $scope.consolidatePreferenceData('Edit');
				if(prefFlag){
					$scope.setTextChannelPhState('UPD');
					// Custom Info Validation
					var submitFlag = $scope.isCustomerInfoChanged();
					if(submitFlag) {
						$('.loader_outer, .loader_inner').hide();
						if($rootScope.Newcustomer.customerType != $rootScope.editCustomerDetails.customerType) {
							// Custom Type Validation
							$scope.isCustomerTypeChanged();
						} else {
							$scope.submitEditCustomerForm();
						}
					} else {
						ValidationService.checkandSetFieldFocus();
						$('.loader_outer, .loader_inner').hide();
						return false;
					}
				} else {
					$('.loader_outer, .loader_inner').hide();
					return false;
				}
			}
		} else {
			// To select address tab in Default
			$rootScope.$broadcast('showDetailsMenuTab', 1);
			ValidationService.checkandSetFieldFocus();
			$('.loader_outer, .loader_inner').hide();
			//$timeout(function() { $("#editProfileView").scrollTop(0); }, 500);
			return false;
		}
	}
	$scope.isCustomerInfoChanged = function() { 
		/*
		$rootScope.Newcustomer - Contain Original or Existing data
		$rootScope.editCustomerDetails - Contain Modified or New data
		*/
		if($rootScope.Newcustomer.customerType == 'BUSINESS' && $rootScope.editCustomerDetails.customerType == 'BUSINESS') {
			var haschanged = false;
			if($rootScope.Newcustomer.address == null) { // $rootScope.editCustomerDetails.address.addressLine1 - means not empty and not null
				if(($rootScope.Newcustomer.organizationName != $rootScope.editCustomerDetails.organizationName.toUpperCase()) && $rootScope.editCustomerDetails.address.addressLine1) {
					haschanged = true;
				}
			} else if (($rootScope.Newcustomer.organizationName != $rootScope.editCustomerDetails.organizationName.toUpperCase()) && ($rootScope.Newcustomer.address.addressLine1 != $rootScope.editCustomerDetails.address.addressLine1.toUpperCase())) {
				haschanged = true;
			}
			if(haschanged) {
				$scope.validationMsg = "You can only update one of the following two fields per submission: Organization Name, Address Line 1.<br>";
				if($rootScope.Newcustomer.vehicles.length > 0) {
					$scope.validationMsg += "<strong>Associated VIN(s)</strong> (View maximum up to 10)<br><br>";
					$scope.validationMsg += '<table class="vinIdentity nowrap_table">';
					angular.forEach($rootScope.Newcustomer.vehicles, function(value, key) {
						if(key < 10) {
							$scope.validationMsg += "<tr><td>"+value.modelYear+" "+value.brand+" "+value.model+"</td><td>"+value.vin+"</td></tr>";
						}
					});
					$scope.validationMsg += "</table><br>";
				}
				$scope.validationMsg += "<strong>NOTE:</strong> If you are attempting to change this vehicle's ownership, then use \"Update Vehicle Ownership\" tab to update owner or driver.";
				$("#customer_organizationNm, #customerPostalAddress_postalAddress_addressLine1").addClass('error_focus');
				$("#editProfileView").scrollTop(0);
				return false;
			}
		}
		if($rootScope.Newcustomer.customerType == 'PERSON' && $rootScope.editCustomerDetails.customerType == 'PERSON') {
			var haschanged = false;
			if($rootScope.Newcustomer.address == null) {
				if(($rootScope.Newcustomer.customerFirstName != $rootScope.editCustomerDetails.customerFirstName.toUpperCase()) && ($rootScope.Newcustomer.customerLastName != $rootScope.editCustomerDetails.customerLastName.toUpperCase()) && $rootScope.editCustomerDetails.address.addressLine1) {
					haschanged = true;
				}
			} else if (($rootScope.Newcustomer.customerFirstName != $rootScope.editCustomerDetails.customerFirstName.toUpperCase()) && ($rootScope.Newcustomer.customerLastName != $rootScope.editCustomerDetails.customerLastName.toUpperCase()) && ($rootScope.Newcustomer.address.addressLine1 != $rootScope.editCustomerDetails.address.addressLine1.toUpperCase())) {
				haschanged = true;
			}
			if(haschanged) {
				$scope.validationMsg = "You can only update two of following three fields per submission: First Name, Last Name, Address Line 1.<br>";
				if($rootScope.Newcustomer.vehicles.length > 0) {
					$scope.validationMsg += "<strong>Associated VIN(s)</strong> (View maximum up to 10)<br><br>";
					$scope.validationMsg += '<table class="vinIdentity nowrap_table">';
					angular.forEach($rootScope.Newcustomer.vehicles, function(value, key) {
						if(key < 10) {
							$scope.validationMsg += "<tr><td>"+value.modelYear+" "+value.brand+" "+value.model+"</td><td>"+value.vin+"</td></tr>";
						}
					});
					$scope.validationMsg += "</table><br>";
				}
				$scope.validationMsg += "<strong>NOTE:</strong> If you are attempting to change this vehicle's ownership, then use \"Update Vehicle Ownership\" tab to update owner or driver.";
				$("#customer_firstNm, #customer_lastNm, #customerPostalAddress_postalAddress_addressLine1").addClass('error_focus');
				$("#editProfileView").scrollTop(0);
				return false;
			}
		}
		if($rootScope.Newcustomer.customerType != $rootScope.editCustomerDetails.customerType) {
			var haschanged = false;
			if($rootScope.Newcustomer.address == null && $rootScope.editCustomerDetails.address.addressLine1) {
				haschanged = true;
			} else if($rootScope.Newcustomer.address.addressLine1.trim() != $rootScope.editCustomerDetails.address.addressLine1.trim().toUpperCase()) {
				haschanged = true;
			}
			if(haschanged) {
				if($rootScope.editCustomerDetails.customerType == 'BUSINESS'){
					$scope.validationMsg = "You can only update two of following three fields per submission: First Name, Last Name, Address Line 1.<br>";
					if($rootScope.Newcustomer.vehicles.length > 0) {
						$scope.validationMsg += "<strong>Associated VIN(s)</strong> (View maximum up to 10)<br><br>";
						$scope.validationMsg += '<table class="vinIdentity nowrap_table">';
						angular.forEach($rootScope.Newcustomer.vehicles, function(value, key) {
							if(key < 10) {
								$scope.validationMsg += "<tr><td>"+value.modelYear+" "+value.brand+" "+value.model+"</td><td>"+value.vin+"</td></tr>";
							}
						});
						$scope.validationMsg += "</table><br>";
					}
					$scope.validationMsg += "<strong>NOTE:</strong> If you are attempting to change this vehicle's ownership, then use \"Update Vehicle Ownership\" tab to update owner or driver.";
					$("#customer_firstNm, #customer_lastNm, #customerPostalAddress_postalAddress_addressLine1").addClass('error_focus');
				} else {
					$scope.validationMsg = "You can only update one of the following two fields per submission: Organization Name, Address Line 1.<br>";
					if($rootScope.Newcustomer.vehicles.length > 0) {
						$scope.validationMsg += "<strong>Associated VIN(s)</strong> (View maximum up to 10)<br><br>";
						$scope.validationMsg += '<table class="vinIdentity nowrap_table">';
						angular.forEach($rootScope.Newcustomer.vehicles, function(value, key) {
							if(key < 10) {
								$scope.validationMsg += "<tr><td>"+value.modelYear+" "+value.brand+" "+value.model+"</td><td>"+value.vin+"</td></tr>";
							}
						});
						$scope.validationMsg += "</table><br>";
					}
					$scope.validationMsg += "<strong>NOTE:</strong> If you are attempting to change this vehicle's ownership, then use \"Update Vehicle Ownership\" tab to update owner or driver.";
					$("#customer_organizationNm, #customerPostalAddress_postalAddress_addressLine1").addClass('error_focus');
				}
				$("#editProfileView").scrollTop(0);
				return false;
			}
			//return confirm(warningMessage);
		}
		return true;
			
	}
	$scope.isDeceasedIndChanged = function() {
		console.log("-------isDeceasedIndChanged-----------");
		$scope.initialisePopupVariables();
		$rootScope.deceasedIndConfirmationFlag = true;
		DealerviewPopup({
			id: 'vehicleOwnershipDialog',
			templateUrl:'views/confirmationPopup.html',
			title : '',
			backdrop : true,
			backdropCancel : false,
			modalClass : "popup_container",
			css: { width: "675px" },
			success: {
				fn: function() {
					$scope.deceasedIndicatorConfirmation = true;
					$scope.editCustomerFormValidation();
				}
			},
			cancel: {
				fn: function() { 
					$scope.deceasedIndicatorConfirmation = false;
				}
			}
		});
	}
	$scope.isCustomerTypeChanged = function() {
		$scope.initialisePopupVariables();
		$rootScope.custTypeChangeConfirmationFlag = true;
		DealerviewPopup({
			id: 'vehicleOwnershipDialog',
			templateUrl:'views/confirmationPopup.html',
			title : '',
			backdrop : true,
			backdropCancel : false,
			modalClass : "popup_container",
			css: { maxHeight: "550px", width: "675px" },
			success: {
				fn: function() {
					$scope.submitEditCustomerForm();
				}
			},
			cancel: {
				fn: function() { return false; }
			}
		});
	}
	$scope.submitEditCustomerForm = function() {
		$('.loader_outer, .loader_inner').show();
		$scope.errorLists = '';
		canceller = $q.defer();
		var data = $scope.serializeObject('updateCustomerForm');
		console.log(data);
		var custId = data.customer_customerId;
		// $('.loader_outer, .loader_inner').hide(); return false; // remove later
		if($rootScope.customerAddFlag) {
			var urlCustomer	= 'addProfile.do';
		} else {
			var urlCustomer = 'editProfile.do';
		}
		$http({ method: "POST", url: urlCustomer, data: data, timeout: canceller.promise }).then(function(response) {
			$('.loader_outer, .loader_inner').hide();
			var result = response.data;
			var result = {"warning":["Required Field Is Missing or Invalid", "Customer Postal Address set is null", "Address Line 1 contains invalid characters", "Zip Code contains invalid characters.  Please correct the zip code.", "We are unable to match the address entered against postal records. Please Verify that the address is correct."],"status":"FAILURE","customerId":null,"parentReload":null,"splitCustomer":null};
			console.log(result);
			if((result.warning != '' && result.warning != null) || result.status == "FAILURE") {
				$('#editProfileView').scrollTop(0);
				if($rootScope.customerAddFlag) {
					$('#splitCustomer').val(result.splitCustomer);
				}
				var errorMessage = (result.warning != '' && result.warning != null)? result.warning.toString() : '';
				// $scope.errorLists - Error message to be display in Customer Update Screen
				if(result.warning != '' && result.warning != null)  {
					var index = result.warning.indexOf("We are unable to match the address entered against postal records. Please Verify that the address is correct.");
					if(index !== -1) {
						result.warning.splice(index,1);
					}
				}
				$scope.errorLists = result.warning;
				//$scope.addressChanged(errorMessage);
				CustomerValidationService.addressChanged(errorMessage, 2, custId);
			} else {
				if($rootScope.customerAddFlag) {
					$('#splitCustomer').val("false");
					$('#addCustomerWarningCounter').val(0);
				} else {
					$('#customer_editCustomerWarningCounter').val(0);
				}
				$('#customer_addNotConfirm').val('');
				$('#customer_fdncAccepted').val('');
				$('#customer_overridenFlag').val('');
				$('#customer_canspamAccepted').val('');
				$rootScope.editProfileView	= false;
				if($rootScope.vinView == true) { // Orphan  VIN View
					// Change vinview(i.e. Orphan) to false, after adding a customer for orphan Vin
					$rootScope.vinView = false;
				}
				/*
				 * Begin		:	Update merge purge details
				 * Decription	:	If edited customerId is available in "Merge Purge" records then any changes made in the customer details should be updated to merge purge details.
				 */
				if($localStorage.mergedCustomers != undefined && $rootScope.customerEditFlag == true) {
					var index = $localStorage.mergedCustomers.indexOf($rootScope.editCustomerDetails.customerId);
					if(index !== -1) {
						// Updated data
						$localStorage.mergePurge[index] = $rootScope.editCustomerDetails;
					}
				}
				// End: Update merge purge details
				/*
				 * Begin		:	Update Recent Search details
				 * Decription	:	If edited customerId is available in "Recent Search History" records then any changes made in the customer details should be updated to recent search details.
				 */
				if($localStorage.recentlySearchedIds != undefined && $rootScope.customerEditFlag == true) {
					var index = $localStorage.recentlySearchedIds.indexOf($rootScope.editCustomerDetails.customerId);
					if(index !== -1) {
						// Updated data
						var tempCustomerData	= { "customerId":$rootScope.editCustomerDetails.customerId, "salutation":$rootScope.editCustomerDetails.salutation, "customerFirstName":$rootScope.editCustomerDetails.customerFirstName, "customerMiddleName":$rootScope.editCustomerDetails.customerMiddleName, "customerLastName":$rootScope.editCustomerDetails.customerLastName, "nameSuffix":$rootScope.editCustomerDetails.nameSuffix, "organizationName":$rootScope.editCustomerDetails.organizationName, "customerType":$rootScope.editCustomerDetails.customerType, "distributor":$rootScope.editCustomerDetails.distributor, "address":$rootScope.editCustomerDetails.address, "email":$rootScope.editCustomerDetails.email, "phone":$rootScope.editCustomerDetails.phone };
						$localStorage.recentSearchHistory[index].customerHistory = tempCustomerData;
					}
				}
				// End: Update Recent Search details
				$timeout(function(){
					$rootScope.$broadcast('customerid', result.customerId);
					$rootScope.$broadcast('showMainMenuTab', 1);
					// Update Vehicle Tab
					$rootScope.$broadcast('VehicleClicked', $rootScope.vin, $rootScope.modelyear, $rootScope.modelname, $rootScope.brand);
				},500);
			}
		}).catch(function(data, status){
			$('.loader_outer, .loader_inner').hide();
		});
	}
	/*
	var addr1, zipcode, custPostalAddr, requiredFields, invalidAddress; // global
	$scope.addressChanged = function(errorMessage) {
		var email		= false;
		addr1			= false;
		zipcode			= false;
		custPostalAddr	= false;
		requiredFields	= false;
		invalidAddress	= false;
		if (errorMessage.indexOf("Required Field Is Missing or Invalid") != -1) {
			//alert("Required Field Is Missing or Invalid. Please Provide Valid Address, Email or Phone.");
			$rootScope.customAlertPopup("Required Field Is Missing or Invalid. Please Provide Valid Address, Email or Phone.");
			requiredFields = true;
		}
		if (errorMessage.indexOf("Customer Postal Address set is null") != -1 && requiredFields == false) {
			//alert("Address information is missing. Please enter the missing information.");
			$rootScope.customAlertPopup("Address information is missing. Please enter the missing information.");
			custPostalAddr = true;
		}
		if (errorMessage.indexOf("Address Line 1 contains invalid characters") != -1) {
			//alert("Address Line 1 contains invalid characters.  Please correct Address Line 1.");
			$rootScope.customAlertPopup("Address Line 1 contains invalid characters.  Please correct Address Line 1.");
			addr1 = true;
		}
		if (errorMessage.indexOf("Zip Code contains invalid characters") != -1) {
            //alert("Zip Code contains invalid characters.  Please correct the zip code.");
            $rootScope.customAlertPopup("Zip Code contains invalid characters.  Please correct the zip code.");
            zipcode = true;
        }
		// Begin : validate only when adding a new customer
		var splitCustomer = ($('#splitCustomer').length > 0)? $('#splitCustomer').val() : '';
		if($rootScope.customerAddFlag && splitCustomer == "true") {
			var msg ="Warning: You have entered a name that will result in the creation of two separate customer records. If this is correct select OK to complete submission. Otherwise select Cancel to stay on the current page and edit the customer name.";
			invalidAddress = confirm(msg);
		}
		// Ends
		if ((errorMessage.indexOf("unable to match the address entered") != -1) && addr1 == false && zipcode == false && requiredFields == false && custPostalAddr == false) {
			invalidAddress = true;
			$scope.addressConfirmPopup(errorMessage);
        } else {
			$scope.setUserSelection(errorMessage);
		}
	}
	$scope.addressConfirmPopup = function(errorMessage) {
		$rootScope.confirmAddress = $rootScope.editCustomerDetails.address;
		DealerviewPopup({
			id: 'addressConfirmDialog',
			templateUrl:'views/addressConfirmPopup.html',
			title : '',
			backdrop : true,
			backdropCancel : false,
			modalClass : "popup_container",
			success: {
				label: 'Success',
				fn: function() {
					$scope.setUserSelection(errorMessage);
					return true;
				}
			},
			cancel: {
				label: 'Success',
				fn: function() {
					isCustomerInfoChangeFlag = false;
					return false;
				}
			},
			css: {"border-radius" : "0" }
		});
		$timeout(function() { $("#address_update").focus(); }, 500);
	}
	$scope.setUserSelection = function(errorMessage) {
		var emailDomainFlag = false;
		var invalidEmail	= false;
		var addrConfirmFlag	= $('input:radio[name=address_verification]:checked').val(); // 1 - verified, 0 - Not verified
		console.log('------addrConfirmFlag--------'+addrConfirmFlag);
		addrConfirmFlag		= (addrConfirmFlag > 0)? true : false; // True - verified, False - Not verified
		console.log('------addrConfirmFlag--------'+addrConfirmFlag);
		$timeout(function() {
			if($rootScope.customerEditFlag) {
				if((errorMessage.indexOf("Phone number entered is invalid") !=-1)){
					var msg ="Please re-enter phone number.";
					if(!confirm(msg)) { // false
						$("#primaryPhone_phoneNo").focus();
						return false;
					}
				}
			}
			if(errorMessage.indexOf("email address provided is not")!=-1 && addr1 == false && zipcode == false && requiredFields == false && custPostalAddr == false) {
				invalidEmail	= true;
				var emailID		= $rootScope.editCustomerDetails.email[0].emailAddress;
				var domainName	= emailID.split("@");
				var msg ="Domain name '"+domainName[1]+"' of the email address provided is not recognized.\n\nTo proceed with email as is click OK,  otherwise click CANCEL and provide a new email address.";
				emailDomainFlag = confirm(msg);
				if(emailDomainFlag == false){
					$("#customerEmailAddress_emailAddress_emailAddress").focus();
				}
			}
			if($rootScope.customerEditFlag) {
				if (errorMessage.indexOf("Phone Number is in fdnc") != -1) {
					var msg = "Customer has registered for FDNC, Do you still want to select this channel"; 
					if(confirm(msg)) {
						$("#customer_fdncAccepted").val("YES");
					} else {
						$("#customer_fdncAccepted").val("NO");
					}
					$("#customer_editCustomerWarningCounter").val(1);
					if (invalidAddress == false && invalidEmail == false && errorMessage.indexOf("Email address is in can spam") == -1) {
						$scope.submitEditCustomerForm();
					}
				}
				if (errorMessage.indexOf("Email address is in can spam") != -1) { 
					var msg = "Customer has registered for Can Spam, Do you still want to select this channel"; 
					if (confirm(msg)) {
						$("#customer_canspamAccepted").val("YES");
					} else {
						$("#customer_canspamAccepted").val("NO");
					}
					$("#customer_editCustomerWarningCounter").val(1);
					if (invalidAddress == false && invalidEmail == false) {
						$scope.submitEditCustomerForm();
					}
				}
			}
			console.log('---invalidAddress----: '+invalidAddress+'----invalidEmail----'+invalidEmail);
			if(invalidAddress == true && invalidEmail == true) {
				if (addrConfirmFlag == true && emailDomainFlag == true) {
					if($rootScope.customerEditFlag)
						$("#customer_editCustomerWarningCounter").val(1);
					else
						$("#addCustomerWarningCounter").val(1);
					$("#customer_overridenFlag").val("C");
					$rootScope.isAddressValidationFlag = true;
					$scope.submitEditCustomerForm();
				} else if (addrConfirmFlag == false && emailDomainFlag == true) {
					if($rootScope.customerEditFlag)
						$("#customer_editCustomerWarningCounter").val(1);
					else
						$("#addCustomerWarningCounter").val(1);
					$("#customer_addNotConfirm").val("C");
					$rootScope.isAddressValidationFlag = true;
					$scope.submitEditCustomerForm();
				}
			}
			if(invalidAddress == true && invalidEmail == false) {
				var splitCustomer = ($('#splitCustomer').length > 0)? $('#splitCustomer').val() : '';
				if (($rootScope.customerEditFlag && addrConfirmFlag == true) || ($rootScope.customerAddFlag && (addrConfirmFlag == true || splitCustomer == "true"))) {
					if($rootScope.customerEditFlag)
						$("#customer_editCustomerWarningCounter").val(1);
					else
						$("#addCustomerWarningCounter").val(1);
					$("#customer_overridenFlag").val("C");
					$rootScope.isAddressValidationFlag = true;
					$scope.submitEditCustomerForm();
				} else if (addrConfirmFlag == false) {
					if($rootScope.customerEditFlag)
						$("#customer_editCustomerWarningCounter").val(1);
					else
						$("#addCustomerWarningCounter").val(1);
					$("#customer_addNotConfirm").val("C");
					$rootScope.isAddressValidationFlag = true;
					$scope.submitEditCustomerForm();
				}
			}
			console.log('---customer_overridenFlag----: '+$("#customer_overridenFlag").val()+'----customer_addNotConfirm----'+$("#customer_addNotConfirm").val()+"-----emailDomainFlag-----"+emailDomainFlag);
			if (invalidAddress == false && invalidEmail == true) {
				if (emailDomainFlag == true) {
					if($rootScope.customerEditFlag)
						$("#customer_editCustomerWarningCounter").val(1);
					else
						$("#addCustomerWarningCounter").val(1);
					$rootScope.isAddressValidationFlag = true;
					$scope.submitEditCustomerForm();
				} else {
					isCustomerInfoChangeFlag = false;
				}
			}
		},500);
	}
	*/
	/************************** Begin : Remove Owner Module **************************/
	$scope.roleChange = function() {
		angular.element('.notsold').val('');
	}
	$scope.soldDateChange = function(index, region) {
		var effectiveDt		= $("#purchase_date_"+index).text();
		var expirationDt	= $("#sold_date_"+index).val();
		var role			= $("#role_"+index).val();
		if($scope.compareDate(effectiveDt, expirationDt, '/')) { // True
			if(role == 'OWNER') {
				angular.element('.notsold.'+region).val(expirationDt);
			}
		} else {
			$("sold_date_"+index).val('');
			//alert("The End Date specified occurs before the Start Date. Please\n correct the End Date so that it occurs after the Start Date.");
			$rootScope.customAlertPopup("The End Date specified occurs before the Start Date.<br>Please correct the End Date so that it occurs after the Start Date.");
			angular.element('.notsold').val('');
		}
	}
	$scope.validateRemoveOwnerhipForm = function() {
		var ownerCounter = activeCustomerCounter= neverAssocAndUndispose = 0;
		var usOwnerCounter = tdprOwnerCounter = 0;
		angular.forEach($scope.removeCustomerData.customerEditList, function(currObj, key) {
			var soldDateElement		=	$("#sold_date_"+(key+1));
			var neverAssoElement	=	$("#never_associate_"+(key+1));
			var undisposeElement	=	$("#undispose_"+(key+1));
			if(currObj.productRole == 'OWNER' && currObj.distributor == 'US' && !$(soldDateElement).is(':disabled')) { // Owner & Not disabled
				usOwnerCounter++;
			}
			if(currObj.productRole == 'OWNER' && currObj.distributor == 'TDPR' && !$(soldDateElement).is(':disabled')) { // Owner & Not disabled
				tdprOwnerCounter++;
			}
			if(!$(soldDateElement).is(':disabled')) { // Not disabled
				activeCustomerCounter++;
			}
			if($(neverAssoElement).is(':checked') && $(undisposeElement).is(':checked')) {
				neverAssocAndUndispose++;
			}
		});	
		if(neverAssocAndUndispose > 0) {
			//alert("You cannot Remove Association and Undispose a Customer at the same time");
			$rootScope.customAlertPopup("You cannot Remove Association and Undispose a Customer at the same time");
			return false;
		}
		if(usOwnerCounter > 1 || tdprOwnerCounter > 1) {
			//alert("Two or more customers are designated as the Owner of\n the vehicle.  Please correct customer roles so that only one \n Owner exists.");
			$rootScope.customAlertPopup("Two or more customers are designated as the Owner of\n the vehicle.  Please correct customer roles so that only one \n Owner exists.");
			return false;
		}
		if(usOwnerCounter == 0  && tdprOwnerCounter == 0 && activeCustomerCounter != 0) {
			//alert("No customer is designated as the Owner of the vehicle.\n Please correct customer roles so that an Owner exists");
			$rootScope.customAlertPopup("No customer is designated as the Owner of the vehicle.\n Please correct customer roles so that an Owner exists");
			return false;
		}
		var neverAssocFlag = $scope.neverAssociateWarning();
		if(neverAssocFlag == false) {
			return false;
		}
		var diposeFlag = $scope.disposeWarning();
		if(diposeFlag == false) {
			return false;
		}
		var unDiposeFlag = $scope.unDisposeWarning();
		if(unDiposeFlag == false ) {
			return false;
		}
		$scope.submitRemoveOwnerForm();
	}
	$scope.neverAssociateWarning = function() {
		var neverAssociatiationPresent	= false;
		var neverAssociateElementArray	= [];
		var neverAssociateCounter		= 0;
		var messageString				= "";
		var counter = $scope.removeCustomerData.customerEditList.length;
		for(i=1; i <= counter; i++) {
			var neverAssociateElement = $("#never_associate_"+i);
			if(neverAssociateElement.lenght > 0) {
				if(!$(neverAssociateElement).is(':disabled')) { // Not disabled
					if($(neverAssociateElement).is(':checked')) { // checked
						neverAssociateElementArray[neverAssociateCounter] = neverAssociateElement;
						var customerName	= $("#customer_name_"+i).val();
						messageString		= messageString+" "+customerName+"\n";
						neverAssociatiationPresent = true;
						neverAssociateCounter++;
					}
				}
			}
		}
		if(neverAssociatiationPresent == true) {
			var customerOrcusomers	= (neverAssociateCounter > 1)? "customers" : "customer";
			var messageHeaderString	= "You have chosen to remove the "+customerOrcusomers+" below from the\nownership history of the selected vehicle.\n\n";
			messageString = messageHeaderString+messageString+"\nSelect OK to remove any history between the vehicle and the\n"+customerOrcusomers+" above, or Cancel to return to the current page\nand continue editing.";
			if(confirm(messageString) == true) {
				return true;
			} else {
				for (j=0; j < neverAssociateElementArray.length; j++) {
					angular.element(neverAssociateElementArray[j]).prop('checked', false);
				}
				return false;
			}
		} else {
			return true;
		}
	}
	$scope.disposeWarning = function() {
		var disposeVehiclePresent		= false;
		var disposeVehicleElementArray	= [];
		var disposeVehicleCounter 		= 0;
		var messageString = "";
		var counter = $scope.removeCustomerData.customerEditList.length;
		for(i=1; i <= counter; i++) {
			var disposeElement = $("#sold_date_"+i);
			if(disposeElement.lenght > 0) {
				if(!$(disposeElement).is(':disabled')) { // Not disabled
					if($(disposeElement).val() != '') {
						disposeVehicleElementArray[disposeVehicleCounter] = disposeElement;
						var customerName	= $("#customer_name_"+i).val();
						messageString		= messageString+" "+customerName+"\n";
						disposeVehiclePresent = true;
						disposeVehicleCounter++;
					}
				}
			}
		}
		if(disposeVehiclePresent == true) {
			var customerOrcusomers	= (disposeVehicleCounter > 1)? "customers" : "customer";
			var partyOrparties		= (disposeVehicleCounter > 1)? "parties" : "party";
			var isOrAre				= (disposeVehicleCounter > 1)? "Are any of these " : "is this ";
			var messageHeaderString	= "You have chosen to dispose the "+partyOrparties+" listed below.\n\n";
			messageString 			= messageHeaderString+messageString+"\n\n Select OK to dispose "+customerOrcusomers+" or Cancel to return to the current page to continue editing.";
			if(confirm(messageString) == true) {
				return true;
			} else {
				for(j=0; j < disposeVehicleElementArray.length; j++) {
					angular.element(disposeVehicleElementArray[j]).val("");
				}
				for(k=1; k <= counter; k++) {
					var oldRole = $("#old_role_"+k).val();
					var newRole = $("#role_"+k).val();
					if(oldRole != newRole) {
						$("#role_"+k).val(oldRole);
					}
				}				
				return false;
			}
		} else {
			return true;
		}
	}
	$scope.unDisposeWarning = function() {
		var undisposePresent 		= false;
		var undisposeElementArray	= [];
		var undisposeCounter		= 0;
		var messageString	= "";
		var ownerDisposed 	= false;
		var counter = $scope.removeCustomerData.customerEditList.length;
		for(i=1; i <= counter; i++) {
			var undisposeElement = $("#undispose_"+i);
			if(undisposeElement.lenght > 0) {
				if(!$(undisposeElement).is(':disabled')) { // Not disabled
					if($(undisposeElement).is(':checked')) { // checked
						undisposeElementArray[undisposeCounter] = undisposeElement;
						var customerName	= $("#customer_name_"+i).val();
						messageString		= messageString+" "+customerName+"\n";
						undisposePresent	= true;
						undisposeCounter++;
					} else {
						var roleElement = $("#role_"+i);
						if($(roleElement).is(':disabled') && $(roleElement).val() == "OWNER") {
							ownerDisposed = true;
						}
					}
				}
			}
		}
		if(ownerDisposed == true && undisposePresent == true) {
			var messageHeaderString = "Are you sure you want to undispose the Driver(s) with Owner\nDisposed?  This will cause the disposed Owner to be\ndemoted to Driver.\n\nPress OK to complete submission, or Cancel to stay on the\n current page and continue editing.";
			if(confirm(messageHeaderString) == true) {
				return true;
			} else {
				for (j=0; j<undisposeElementArray.length; j++) {
					angular.element(undisposeElementArray[j]).prop('checked', false);
				}
				return false;
			}
		} else {
			if(undisposePresent == true) {
				var customerOrcusomers = (undisposeCounter > 1)? "customers" : "customer";
				var messageHeaderString ="You have chosen to undispose the "+customerOrcusomers+" below from the\nownership history of the selected vehicle.\n\n";
				messageString = messageHeaderString+messageString+"\nSelect OK to undispose the\n"+customerOrcusomers+"  above, or Cancel to return to the current page\nand continue editing.";
				if(confirm(messageString) == true) {
					return true;
				} else {
					for (j=0; j<undisposeElementArray.length; j++) {
						angular.element(undisposeElementArray[j]).prop('checked', false);
					}
					return false;
				}
			} else {
				return true;
			}
		}
	}
	$scope.submitRemoveOwnerForm = function() {
		$('.loader_outer, .loader_inner').show();
		canceller = $q.defer();
		$scope.postdata = {};
		$scope.postdata.distributor = $rootScope.roleType;
		$scope.postdata.ownerList = [];
		angular.forEach($scope.removeCustomerData.customerEditList, function(obj, index) {
			index = index + 1;
			$scope.postdata.ownerList.push ({
											"distributor"						: obj.distributor,
											"cpa_customerProductAssociationId"	: obj.customerProductAssocId,
											"cpa_customer_customerId"			: obj.customerId,
											"cpa_serializedProduct_id"			: $scope.removeCustomerData.serializedProductId,
											"eventId"							: obj.eventId,
											"cpa_expirationDt"					: $("#sold_date_"+index).val(),
											"oldRole"							: $("#old_role_"+index).val(),
											"cpa_customerProductRole"			: $("#role_"+index).val(),
											"cpa_serializedProduct_vin"			: $rootScope.selectedVin,
											"undispose"							: ($("#undispose_"+index).is(':checked'))? true: false,
											"alreadyDisabled"					: ($("#sold_date_"+index).is(':disabled'))? true: false,
											"neverAssociated"					: ($("#never_associate_"+index).is(':checked'))? true: false
										});
		});
		angular.forEach($scope.removeCustomerData.vinList, function(vinInfo, index) {
			if(vinInfo.vin == $rootScope.selectedVin) {
				$rootScope.modelyear	= vinInfo.modelYear;
				$rootScope.modelname	= vinInfo.model;
				$rootScope.brand		= vinInfo.make;
			}
		});
		$http({ method: "POST", url: 'updateOwnership.do', data: $scope.postdata, timeout: canceller.promise }).then(function(response) {
			$('.loader_outer, .loader_inner').hide();
			var result = response.data;
			if(result.status == "SUCCESS") {
				$rootScope.editProfileView	= false;
				if($rootScope.vinView == true) { // Orphan  VIN View
					$rootScope.vinView = false;
				}
				$timeout(function(){
					$rootScope.$broadcast('VehicleClicked', $rootScope.selectedVin, $rootScope.modelyear, $rootScope.modelname, $rootScope.brand);
					$rootScope.$broadcast('customerid', $rootScope.customerId);
					$rootScope.$broadcast('showMainMenuTab', 1);
					$rootScope.$broadcast('showDetailsMenuTab', 1); // 1 - Vehicle Detail, 2 - All vehicles
				},500);
			}
		}).catch(function(data, status){
			$('.loader_outer, .loader_inner').hide();
		});
	}
	/************************** End : Remove Owner Module ****************************/
}]);
// Begin : Custom Factory Services
TMSApp.factory('NewCustomerInfoService',['$http','$q',function($http,$q){
	return {
		getNewCustomerDetails: function(id, distributor, vin){
			var deferred = $q.defer()
			var NewCustomer;
			if(vin != undefined && vin != '') {
				var url = 'getcustomerInfo.do?customerId='+id+'&vin='+vin+'&distributor='+distributor;
			} else {
				var url = 'getcustomerInfo.do?customerId='+id+'&distributor='+distributor;
			}
			$http.get(url).then(function(response){
				NewCustomer = response.data;
				deferred.resolve(NewCustomer);
			});
			return deferred.promise;
		}
	}
}]);

TMSApp.factory('VehicleOwnerService',['$http','$q',function($http,$q){
	return {
		getVehicleownerDetails: function(Vin){
			var deferred = $q.defer()
			var vehicleOwner;
			var url = 'getVehicleOwnerHist.do?vin='+Vin;
			$http.get(url).then(function(response){
				vehicleOwner = response.data;
				deferred.resolve(vehicleOwner);
			})
			return deferred.promise;
		}
	}
}]);

TMSApp.factory('SalesInfoService',['$http','$q',function($http,$q){
	return {
		getSalesInfoDetails: function(AssociateId){
			var deferred = $q.defer()
			var SalesInfo;
			var url = 'getSalesInfo.do?custProdAssocId='+AssociateId;
			$http.get(url).then(function(response){
				SalesInfo = response.data;
				deferred.resolve(SalesInfo);
			})
			return deferred.promise;
		}
	}
}]);

TMSApp.factory('AllVehicleService',['$http','$q',function($http,$q){
	return {
		getAllVehiclesCount: function(custId,type) {
			var deferred = $q.defer()
			var allVehCount;
			var url = 'getAllvehicleDetailsCount.do?customerId='+custId+'&custType='+type;
			$http.get(url).then(function(response){
				allVehCount = response.data;
				deferred.resolve(allVehCount);
			})
			return deferred.promise;
		},
		getAllvehicleDetails: function(custId,currPage,type){
			var deferred = $q.defer()
			var AllVehicles;
			var url = 'getAllvehicleDetails.do?customerId='+custId+'&currentPage='+currPage+'&custType='+type;
			$http.get(url).then(function(response){
				AllVehicles = response.data;
				deferred.resolve(AllVehicles);
			})
			return deferred.promise;
		}
	}
}]);

// Begin: Vehicle Details
TMSApp.factory('VehicleDetailService',['$http','$q',function($http,$q){
	return {
		getVehicleDetails: function(id,vin){
			var deferred = $q.defer()
			var VehicleDetail;
			var url = 'getVehicleInfo.do?customerId='+id+'&vin='+vin;
			$http.get(url).then(function(response){
				VehicleDetail = response.data;
				deferred.resolve(VehicleDetail);
			})
			return deferred.promise;
		},
		getBasicVehicleInfoDetails: function(vin){
			var deferred = $q.defer()
			var BasicVehicleDetail;
			var url = 'getBasicVehicleInfo.do?vin='+vin;
			$http.get(url).then(function(response){
				BasicVehicleDetail = response.data;
				deferred.resolve(BasicVehicleDetail);
			})
			return deferred.promise;
		},
		getVINInfoDetails: function(id,vin){
			var deferred = $q.defer()
			var VinInfoDetail;
			var url = 'getVINInfo.do?customerId='+id+'&vin='+vin;
			$http.get(url).then(function(response){
				VinInfoDetail = response.data;
				deferred.resolve(VinInfoDetail);
			})
			return deferred.promise;
		},
		getMSRPInfoDetails: function(vin){
			var deferred = $q.defer()
			var MSRPInfoDetail;
			var url = 'getMSRPInfo.do?vin='+vin;
			$http.get(url).then(function(response){
				MSRPInfoDetail = response.data;
				deferred.resolve(MSRPInfoDetail);
			})
			return deferred.promise;
		},
		getProductionInfoDetails: function(vin){
			var deferred = $q.defer()
			var ProductionInfoDetail;
			var url = 'getProductionInfo.do?vin='+vin;
			$http.get(url).then(function(response){
				ProductionInfoDetail = response.data;
				deferred.resolve(ProductionInfoDetail);
			})
			return deferred.promise;
		},
		getRetailSaleInfoDetails: function(vin){
			var deferred = $q.defer()
			var RetailSaleInfoDetail;
			var url = 'getRetailSaleInfo.do?vin='+vin;
			$http.get(url).then(function(response){
				RetailSaleInfoDetail = response.data;
				deferred.resolve(RetailSaleInfoDetail);
			})
			return deferred.promise;
		},
		updatePreferredDealerCode: function(vin, cust_id, dealerCd) {
			var deferred = $q.defer()
			var result;
			var url = 'updPrefDlr.do?vin='+vin+'&customerId='+cust_id+'&dealerCode='+dealerCd;
			$http.get(url).then(function(response){
				result = response.data;
				deferred.resolve(result);
			})
			return deferred.promise;
		},
		getOwnerNotificationSummary: function(vin){
			var vin = 'JT2AC52L4T0131185';
			var deferred = $q.defer()
			var OwnerNotificationSummary;
			var url = 'getOwnerNotification.do?vin='+vin;
			$http.get(url).then(function(response){
				OwnerNotificationSummary = response.data;
				deferred.resolve(OwnerNotificationSummary);
			})
			return deferred.promise;
		},
		getRoadSideAssistanceSummary: function(vin){
			var vin = '4T1BF1FK7CU510005';
			var deferred = $q.defer()
			var RoadSideAssistanceSummary;
			var url = 'getRoadSideAssistance.do?vin='+vin;
			$http.get(url).then(function(response){
				RoadSideAssistanceSummary = response.data;
				deferred.resolve(RoadSideAssistanceSummary);
			})
			return deferred.promise;
		},
		getToyotaCareUrl: function(vin){
			var vin = '4T1BF1FK7CU510005';
			var deferred = $q.defer()
			var ToyotaCareUrl;
			var url = 'getToyotacareMaintUrl.do?vin='+vin;
			$http.get(url).then(function(response){
				ToyotaCareUrl = response.data;
				deferred.resolve(ToyotaCareUrl);
			})
			return deferred.promise;
		},
		getToyotaCareSummary: function(vin){
			var vin = '4T1BF1FK7CU510005';
			var deferred = $q.defer()
			var ToyotaCareSummary;
			var url = 'getToyotacareScionBoost.do?vin='+vin;
			$http.get(url).then(function(response){
				ToyotaCareSummary = response.data;
				deferred.resolve(ToyotaCareSummary);
			})
			return deferred.promise;
		},
		getMiraiSwapSummary: function(vin){
			var vin = 'JTDBVRBD2GA000178';
			var deferred = $q.defer()
			var MiraiSwapSummary;
			var url = 'getMiraiDetails.do?vin='+vin;
			$http.get(url).then(function(response){
				MiraiSwapSummary = response.data;
				deferred.resolve(MiraiSwapSummary);
			})
			return deferred.promise;
		}
	}
}]);
// End : Vehicle Details

// Begin: Telematics Details
TMSApp.factory('TelematicService',['$http','$q',function($http,$q){
	return {
		getTelematicsProductDetails: function(vin){
			//var vin = '2T2BK1BA8FC258016';	// JTHBW1GG7G2100898
			var deferred = $q.defer()
			var TelematicsDetails;
			var url = 'getTelematicsProductDetails.do?vin='+vin;
			$http.get(url).then(function(response){
				TelematicsDetails = response.data;
				deferred.resolve(TelematicsDetails);
			})
			return deferred.promise;
		},
		getTelematicProductEnrollmentSummary: function(vin){
			//var vin = '2T2BK1BA8FC258016';
			var deferred = $q.defer()
			var TelematicsEnroll;
			var url = 'getTelematicsProductEnrollment.do?vin='+vin;
			$http.get(url).then(function(response){
				TelematicsEnroll = response.data;
				deferred.resolve(TelematicsEnroll);
			})
			return deferred.promise;
		},
		getTelematicOwnershipSummary: function(vin){
			//var vin = '2T2BK1BA8FC258016';
			var deferred = $q.defer()
			var OwnershipDetail;
			var url = 'getTelematicsOwnerHist.do?vin='+vin;
			$http.get(url).then(function(response){
				OwnershipDetail = response.data;
				deferred.resolve(OwnershipDetail);
			})
			return deferred.promise;
		},
		getVHRSummary: function(vin,custId,primCustId){
			var deferred = $q.defer()
			var VHRDetails;
			//var url = 'getVHRHistoryList.do?vin=JTHBW1GG7G2100898&customerId=115176755&primCustomerId=11229815';
			var url = 'getVHRHistoryList.do?vin='+vin+'&customerId='+custId+'&primCustomerId='+primCustId;
			$http.get(url).then(function(response){
				VHRDetails = response.data;
				deferred.resolve(VHRDetails);
			})
			return deferred.promise;
		},
		getVHRGeneratedByDetails: function(type,vin,id){
			var deferred = $q.defer()
			var GeneratedByDetail;
			if(type == 'Customer')
				var url = 'getVHRCustomer.do?vin='+vin+'&customerId='+id;
			else
				var url = 'getVHRDealer.do?vin='+vin+'&dealerId='+id;
			$http.get(url).then(function(response){
				GeneratedByDetail = response.data;
				deferred.resolve(GeneratedByDetail);
			})
			return deferred.promise;
		},
		sendVHREmail: function(custId,vin,userId){
			var deferred = $q.defer()
			var EmailDetail;
			var url = 'sendVHREmail.do?vin='+vin+'&customerId='+custId+'&userId='+userId;
			$http.get(url).then(function(response){
				EmailDetail = response.data;
				deferred.resolve(EmailDetail);
			});
			return deferred.promise;
		}
	}
}]);
// End : Telematics Details

// Begin: TFS Summary
TMSApp.factory('TfsProductService',['$http','$q',function($http,$q){
	return {
		getTfsProductSummary: function(vin){
			var vin = 'JTDBR32E570100713';
			var deferred = $q.defer()
			var TfsDetail;
			var url = 'getTFSSummary.do?vin='+vin;
			$http.get(url).then(function(response){
				TfsDetail = response.data;
				deferred.resolve(TfsDetail);
			})
			return deferred.promise;
		}
	}
}]);
// End : TFS Summary

// Begin : Service History
TMSApp.factory('HistoryService',['$http','$q',function($http,$q){
	return {
		getServiceHistorySummary: function(Vin,count){
			//var Vin = 'JTHBF1D2XF5048141'; //JTHBA30G040007331
			var deferred = $q.defer()
			var servicedetails;
			var url = 'getServiceHistorySummary.do?vin='+Vin+'&vehicleArchiveCount='+count;
			$http.get(url).then(function(response){
				servicedetails = response.data;
				deferred.resolve(servicedetails);
			})
			return deferred.promise;
		},
		getClaimsHistorySummary: function(Vin){
			//var Vin = '2T2BK1BA9DC155300';
			var deferred = $q.defer()
			var claimsdetails;
			var url = 'getWarrantySummary.do?vin='+Vin;
			$http.get(url).then(function(response){
				claimsdetails = response.data;
				deferred.resolve(claimsdetails);
			})
			return deferred.promise;
		},
		getDealerInfoDetails: function(dealerCd){
			var deferred = $q.defer()
			var dealerDetails;
			var url = 'getDelearDetails.do?dealerCd='+dealerCd;
			$http.get(url).then(function(response){
				dealerDetails = response.data;
				deferred.resolve(dealerDetails);
			})
			return deferred.promise;
		}
	}
}]);
// End : Service History

// Begin: Household service
TMSApp.factory('HouseholdService',['$http','$q',function($http,$q){
	return {
		getHouseholdCustomersCount: function(custId) {
			var deferred = $q.defer()
			var hhCustCount;
			var url = 'getHouseHoldCustomerCount.do?customerID='+custId;
			$http.get(url).then(function(response){
				hhCustCount = response.data;
				deferred.resolve(hhCustCount);
			})
			return deferred.promise;
		},
		getHouseholdVehicleCount: function(custId,type) {
			var deferred = $q.defer()
			var hhVehCount;
			var url = 'getHouseHoldVehiclesCount.do?customerId='+custId+'&custType='+type;
			$http.get(url).then(function(response){
				hhVehCount = response.data;
				deferred.resolve(hhVehCount);
			})
			return deferred.promise;
		},
		getHouseholdTfsCount: function(custId,type) {
			var deferred = $q.defer()
			var hhTfsCount;
			var url = 'getHouseHoldTFSProductsCount.do?customerId='+custId+'&type='+type;
			$http.get(url).then(function(response){
				hhTfsCount = response.data;
				deferred.resolve(hhTfsCount);
			})
			return deferred.promise;
		},
		getHouseholdTelematicsCount: function(custId) {
			var deferred = $q.defer()
			var hhTelCount;
			var url = 'getHouseholdTelematicsCount.do?customerId='+custId;
			$http.get(url).then(function(response){
				hhTelCount = response.data;
				deferred.resolve(hhTelCount);
			})
			return deferred.promise;
		},
		getHouseholdCustomers: function(custId,currPage){
			var deferred = $q.defer()
			var householdcustomers;
			var url = 'getHouseHoldCustomer.do?customerID='+custId+'&currentPage='+currPage;
			$http.get(url).then(function(response){
				householdcustomers = response.data;
				deferred.resolve(householdcustomers);
			})
			return deferred.promise;
		},
		getHouseholdVehicles: function(custId,currPage,type){
			var deferred = $q.defer()
			var householdvehicles;
			var url = 'getHouseHoldVehicles.do?customerId='+custId+'&currentPage='+currPage+'&custType='+type;
			$http.get(url).then(function(response){
				householdvehicles = response.data;
				deferred.resolve(householdvehicles);
			})
			return deferred.promise;
		},
		getHouseholdTfsProducts: function(custId,currPage,type){
			var deferred = $q.defer()
			var householdtfsproducts;
			var url = 'getHouseHoldTFSProducts.do?customerId='+custId+'&currentPage='+currPage+'&type='+type;
			$http.get(url).then(function(response){
				householdtfsproducts = response.data;
				deferred.resolve(householdtfsproducts);
			})
			return deferred.promise;
		},
		getHouseholdTelematics: function(custId,currPage,hhId){
			var deferred = $q.defer()
			var householdtelematics;
			var url = 'getHouseholdTelematicsProducts.do?customerId='+custId+'&currentPage='+currPage+'&houseHoldId='+hhId;
			$http.get(url).then(function(response){
				householdtelematics = response.data;
				deferred.resolve(householdtelematics);
			})
			return deferred.promise;
		}
		
	}
}]);
// End: Household service

// Begin : Customer Update Services
TMSApp.factory('CustomerUpdateService',['$http','$q',function($http,$q){
	return {
		getDropdownValues: function(custId) {
			var deferred = $q.defer()
			var ddlResults;
			var url = 'sendEditcustomerInfo.do?customerId='+custId;
			$http.get(url).then(function(response){
				ddlResults = response.data;
				deferred.resolve(ddlResults);
			})
			return deferred.promise;
		},
		getSelectPrefernce: function(custId) {
			var deferred = $q.defer()
			var ddlResults;
			var url = 'getSelectPrefernce.do?customerId='+custId;
			$http.get(url).then(function(response){
				ddlResults = response.data;
				deferred.resolve(ddlResults);
			})
			return deferred.promise;
		},
		getCustomerPrefernce: function(custId) {
			var deferred = $q.defer()
			var ddlResults;
			var url = 'getCustomerPrefernce.do?customerId='+custId;
			$http.get(url).then(function(response){
				ddlResults = response.data;
				deferred.resolve(ddlResults);
			})
			return deferred.promise;
		},
		saveSelectPrefernce: function(custId, prefStr) {
			var deferred = $q.defer()
			var ddlResults;
			var url = 'saveSelectPrefernce.do?customerId='+custId+'&jsonData='+prefStr;
			$http.get(url).then(function(response){
				ddlResults = response.data;
				deferred.resolve(ddlResults);
			})
			return deferred.promise;
		},
		getRemoveCustomer: function(custId, vin, role) {
			var deferred = $q.defer()
			var ddlResults;
			var url = 'removeCustomer.do?customerId='+custId+'&vin='+vin+'&role='+role;
			//var url = 'removeCustomer.do?customerId=127591364&vin=JTDDR32T020132338';
			//var url = 'removeCustomer.do?customerId=14831622&vin=1NXAE02E8TZ458960';
			$http.get(url).then(function(response){
				ddlResults = response.data;
				deferred.resolve(ddlResults);
			})
			return deferred.promise;
		}
	}
}]);
// End : Customer Update Services
TMSApp.factory('CustomerValidationService', function($rootScope, $timeout, $localStorage, DealerviewPopup){
	// Variable
	var email, addr1, zipcode, custPostalAddr, requiredFields, invalidAddress; // global
	// Methods
	var validate = {};
	validate.serializeObject = function(formName) {
		var o = {};
		var formData = $("#"+formName).serializeArray();
		$.each(formData, function() {
			var temp_id = this.name;
			if(!$("input[name="+temp_id+"], select[name="+temp_id+"]").hasClass('exclude')) { // remove unwanted post data
				if (o[this.name] !== undefined) {
					if (!o[this.name].push) {
						o[this.name] = [o[this.name]];
					}
					o[this.name].push(this.value || '');
				} else {
					o[this.name] = this.value || '';
				}
			}
		});
		return o;
	};
	validate.addressChanged = function(errorMessage, type, custId) { // type : 1 - Merge Purge Edit, 2 - Customer Edit Profile
		console.log(errorMessage);
		var mergeEditFlag = (type == 1)? true : false;
		var alertMsg = '';
		email = addr1 = zipcode = custPostalAddr = requiredFields = invalidAddress = false;
		if (errorMessage.indexOf("Required Field Is Missing or Invalid") != -1) {
			requiredFields = true;
			$rootScope.customAlertPopup("Required Field Is Missing or Invalid. Please Provide Valid Address, Email or Phone.");
			//alertMsg = 'Required Field Is Missing or Invalid. Please Provide Valid Address, Email or Phone.';
		}
		if (errorMessage.indexOf("Customer Postal Address set is null") != -1 && requiredFields == false) {
			custPostalAddr = true;
			$rootScope.customAlertPopup("Address information is missing. Please enter the missing information.");
			/* if(alertMsg != '') { alertMsg += '<br><br>'; }
			alertMsg += 'Address information is missing. Please enter the missing information.'; */
		}
		if (errorMessage.indexOf("Address Line 1 contains invalid characters") != -1) {
			addr1 = true;
			$rootScope.customAlertPopup("Address Line 1 contains invalid characters. Please correct Address Line 1.");
			/* if(alertMsg != '') { alertMsg += '<br><br>'; }
			alertMsg += 'Address Line 1 contains invalid characters. Please correct Address Line 1.'; */
		}
		if (errorMessage.indexOf("Zip Code contains invalid characters") != -1) {
            zipcode = true;
			$rootScope.customAlertPopup("Zip Code contains invalid characters. Please correct the zip code.");
			/* if(alertMsg != '') { alertMsg += '<br><br>'; }
			alertMsg += 'Zip Code contains invalid characters. Please correct the zip code.'; */
        }
		/*
		if(alertMsg != '') {
			$rootScope.customAlertPopup(alertMsg);
			var checkConfirmation = setInterval(function() {
				if($rootScope.isConfirmed == true) {
					clearInterval(checkConfirmation);
					verifyAddress();
				}
			}, 100);
		} else {
			verifyAddress();
		}
		*/
		// var verifyAddress = function() {
		// Begin : validate only when adding a new customer - Edit Profile
		if(mergeEditFlag == false) {
			var splitCustomer = ($('#splitCustomer').length > 0)? $('#splitCustomer').val() : '';
			if($rootScope.customerAddFlag && splitCustomer == "true") {
				var msg ="Warning: You have entered a name that will result in the creation of two separate customer records. If this is correct select OK to complete submission. Otherwise select Cancel to stay on the current page and edit the customer name.";
				invalidAddress = confirm(msg);
			}
		}
		// Ends
		if ((errorMessage.indexOf("unable to match the address entered") != -1) && addr1 == false && zipcode == false && requiredFields == false && custPostalAddr == false) {
			invalidAddress = true;
			validate.addressConfirmPopup(errorMessage, type, custId);
		} else {
			validate.setUserSelection(errorMessage, type, custId);
		}
		// }
	}
	validate.addressConfirmPopup = function(errorMessage, type, custId) {
		if(type == 1) {
			var index					= $localStorage.mergedCustomers.indexOf(custId);
			$rootScope.confirmAddress	= $rootScope.mergeCustomerDetails[index].address;
		} else {
			$rootScope.confirmAddress	= $rootScope.editCustomerDetails.address;
		}
		DealerviewPopup({
			id: 'addressConfirmDialog',
			templateUrl:'views/addressConfirmPopup.html',
			title : '',
			backdrop : true,
			backdropCancel : false,
			modalClass : "popup_container",
			css: {"border-radius" : "0" },
			success: {
				label: 'Success',
				fn: function() {
					validate.setUserSelection(errorMessage, type, custId);
					return true;
				}
			},
			cancel: {
				label: 'Success',
				fn: function() {
					return false;
				}
			}
		});
		$timeout(function() { $("#address_update").focus(); }, 500);
	}
	validate.setUserSelection = function(errorMessage, type, custId) { // type : 1 - Merge Purge Edit, 2 - Customer Edit Profile
		console.log(errorMessage+'------'+type+'------'+custId);
		if(type == 1) {
			var index			= $localStorage.mergedCustomers.indexOf(custId);
			var customerData	= $rootScope.mergeCustomerDetails[index];
			var mergeEditFlag	= true;
		} else {
			var customerData	= $rootScope.editCustomerDetails;
			var mergeEditFlag	= false;
		}
		var emailDomainFlag = false;
		var invalidEmail	= false;
		var addrConfirmFlag	= $('input:radio[name=address_verification]:checked').val(); // 1 - verified, 0 - Not verified
		console.log('------addrConfirmFlag--------'+addrConfirmFlag);
		addrConfirmFlag		= (addrConfirmFlag > 0)? true : false; // True - verified, False - Not verified
		console.log('------addrConfirmFlag--------'+addrConfirmFlag);
		$timeout(function() {
			if($rootScope.customerEditFlag || mergeEditFlag) {
				if((errorMessage.indexOf("Phone number entered is invalid") !=-1)){
					var msg ="Please re-enter phone number.";
					if(!confirm(msg)) { // false
						if(mergeEditFlag)
							$("#mp-phone-"+custId).focus();
						else
							$("#primaryPhone_phoneNo").focus();
						return false;
					}
				}
			}
			if(errorMessage.indexOf("email address provided is not")!=-1 && addr1 == false && zipcode == false && requiredFields == false && custPostalAddr == false) {
				invalidEmail	= true;
				var emailID		= customerData.email[0].emailAddress;
				var domainName	= emailID.split("@");
				var msg ="Domain name '"+domainName[1]+"' of the email address provided is not recognized.\n\nTo proceed with email as is click OK,  otherwise click CANCEL and provide a new email address.";
				emailDomainFlag = confirm(msg);
				if(emailDomainFlag == false){
					if(mergeEditFlag)
						$("#mp-email-"+custId).focus();
					else
						$("#customerEmailAddress_emailAddress_emailAddress").focus();
				}
			}
			if($rootScope.customerEditFlag || mergeEditFlag) {
				if (errorMessage.indexOf("Phone Number is in fdnc") != -1) {
					var msg = "Customer has registered for FDNC, Do you still want to select this channel";
					/* fdncAccepted */
					if(confirm(msg)) {
						if(mergeEditFlag) { $("#mp_fdncAccepted_"+custId).val("YES"); } else { $("#customer_fdncAccepted").val("YES"); }
					} else {
						if(mergeEditFlag) { $("#mp_fdncAccepted_"+custId).val("NO"); } else { $("#customer_fdncAccepted").val("NO"); }
					}
					/* editCustomerWarningCounter */
					if(mergeEditFlag) { $("#mp_editCustomerWarningCounter_"+custId).val(1); } else { $("#customer_editCustomerWarningCounter").val(1); }
					/* Re-submit */
					if (invalidAddress == false && invalidEmail == false && errorMessage.indexOf("Email address is in can spam") == -1) {
						if(mergeEditFlag) {
							angular.element($('[ng-controller="FamilyCtrl"]')).scope().submitMergePurgeCustomerForm(custId);
						} else {
							angular.element($('[ng-controller="EditProfileController"]')).scope().submitEditCustomerForm();
						}
					}
				}
				if (errorMessage.indexOf("Email address is in can spam") != -1) { 
					var msg = "Customer has registered for Can Spam, Do you still want to select this channel"; 
					/* canspamAccepted */
					if (confirm(msg)) {
						if(mergeEditFlag) { $("#mp_canspamAccepted_"+custId).val("YES"); } else { $("#customer_canspamAccepted").val("YES"); }
					} else {
						if(mergeEditFlag) { $("#mp_canspamAccepted_"+custId).val("NO"); } else { $("#customer_canspamAccepted").val("NO"); }
					}
					/* editCustomerWarningCounter */
					if(mergeEditFlag) { $("#mp_editCustomerWarningCounter_"+custId).val(1); } else { $("#customer_editCustomerWarningCounter").val(1); }
					/* Re-submit */
					if (invalidAddress == false && invalidEmail == false) {
						if(mergeEditFlag) {
							angular.element($('[ng-controller="FamilyCtrl"]')).scope().submitMergePurgeCustomerForm(custId);
						} else {
							angular.element($('[ng-controller="EditProfileController"]')).scope().submitEditCustomerForm();
						}
					}
				}
			}
			console.log('---invalidAddress----: '+invalidAddress+'----invalidEmail----'+invalidEmail);
			if(invalidAddress == true && invalidEmail == true) {
				if (addrConfirmFlag == true && emailDomainFlag == true) {
					if(mergeEditFlag) {
						$("#mp_editCustomerWarningCounter_"+custId).val(1);	
						$("#mp_overridenFlag_"+custId).val("C");	
					} else if($rootScope.customerEditFlag) {
						$("#customer_editCustomerWarningCounter").val(1);
						$("#customer_overridenFlag").val("C");
					} else {
						$("#addCustomerWarningCounter").val(1);
						$("#customer_overridenFlag").val("C");
					}
					if(mergeEditFlag) {
						angular.element($('[ng-controller="FamilyCtrl"]')).scope().submitMergePurgeCustomerForm(custId);
					} else {
						$rootScope.isAddressValidationFlag = true;
						angular.element($('[ng-controller="EditProfileController"]')).scope().submitEditCustomerForm();
					}
				} else if (addrConfirmFlag == false && emailDomainFlag == true) {
					if(mergeEditFlag) {
						$("#mp_editCustomerWarningCounter_"+custId).val(1);	
						$("#mp_addNotConfirm_"+custId).val("C");	
					} else if($rootScope.customerEditFlag) {
						$("#customer_editCustomerWarningCounter").val(1);
						$("#customer_addNotConfirm").val("C");
					} else {
						$("#addCustomerWarningCounter").val(1);
						$("#customer_addNotConfirm").val("C");
					}
					if(mergeEditFlag) {
						angular.element($('[ng-controller="FamilyCtrl"]')).scope().submitMergePurgeCustomerForm(custId);
					} else {
						$rootScope.isAddressValidationFlag = true;
						angular.element($('[ng-controller="EditProfileController"]')).scope().submitEditCustomerForm();
					}
				}
			}
			if(invalidAddress == true && invalidEmail == false) {
				var splitCustomer = ($('#splitCustomer').length > 0)? $('#splitCustomer').val() : '';
				if ((($rootScope.customerEditFlag || mergeEditFlag) && addrConfirmFlag == true) || ($rootScope.customerAddFlag && (addrConfirmFlag == true || splitCustomer == "true"))) {
					if(mergeEditFlag) {
						$("#mp_editCustomerWarningCounter_"+custId).val(1);	
						$("#mp_overridenFlag_"+custId).val("C");	
					} else if($rootScope.customerEditFlag) {
						$("#customer_editCustomerWarningCounter").val(1);
						$("#customer_overridenFlag").val("C");
					} else {
						$("#addCustomerWarningCounter").val(1);
						$("#customer_overridenFlag").val("C");
					}
					if(mergeEditFlag) {
						angular.element($('[ng-controller="FamilyCtrl"]')).scope().submitMergePurgeCustomerForm(custId);
					} else {
						$rootScope.isAddressValidationFlag = true;
						angular.element($('[ng-controller="EditProfileController"]')).scope().submitEditCustomerForm();
					}
				} else if (addrConfirmFlag == false) {
					if(mergeEditFlag) {
						$("#mp_editCustomerWarningCounter_"+custId).val(1);	
						$("#mp_addNotConfirm_"+custId).val("C");	
					} else if($rootScope.customerEditFlag) {
						$("#customer_editCustomerWarningCounter").val(1);
						$("#customer_addNotConfirm").val("C");
					} else {
						$("#addCustomerWarningCounter").val(1);
						$("#customer_addNotConfirm").val("C");
					}
					if(mergeEditFlag) {
						angular.element($('[ng-controller="FamilyCtrl"]')).scope().submitMergePurgeCustomerForm(custId);
					} else {
						$rootScope.isAddressValidationFlag = true;
						angular.element($('[ng-controller="EditProfileController"]')).scope().submitEditCustomerForm();
					}
				}
			}
			console.log('---customer_overridenFlag----: '+$("#customer_overridenFlag").val()+'----customer_addNotConfirm----'+$("#customer_addNotConfirm").val()+"-----emailDomainFlag-----"+emailDomainFlag);
			if (invalidAddress == false && invalidEmail == true) {
				if (emailDomainFlag == true) {
					if(mergeEditFlag) {
						$("#mp_editCustomerWarningCounter_"+custId).val(1);	
					} else if($rootScope.customerEditFlag) {
						$("#customer_editCustomerWarningCounter").val(1);
					} else {
						$("#addCustomerWarningCounter").val(1);
					}
					if(mergeEditFlag) {
						angular.element($('[ng-controller="FamilyCtrl"]')).scope().submitMergePurgeCustomerForm(custId);
					} else {
						$rootScope.isAddressValidationFlag = true;
						angular.element($('[ng-controller="EditProfileController"]')).scope().submitEditCustomerForm();
					}
				}
			}
		},500);
	}
	return validate;
});
// End : Custom Factory Services
// Begin: Filters
TMSApp.filter('telephone', function () {
	return function (tel) {
		if (!tel) { return ''; }
		var value = tel.toString().trim().replace(/(^\+|[\(\)\s])/g, '');
		//console.log(value);
		if (value.match(/[^0-9]/)) {
			return tel;
		}		
		var country, city, number;
		switch (value.length) {
			case 10: // +1PPP####### -> C (PPP) ###-####
				country = 1;
				city = value.slice(0, 3);
				number = value.slice(3);
				break;
			case 11: // +CPPP####### -> CCC (PP) ###-####
				country = value[0];
				city = value.slice(1, 4);
				number = value.slice(4);
				break;
			case 12: // +CCCPP####### -> CCC (PP) ###-####
				country = value.slice(0, 3);
				city = value.slice(3, 5);
				number = value.slice(5);
				break;
			default:
			return tel;
		}
		if (country == 1) {
			country = "";
		}
		number = number.slice(0, 3) + '-' + number.slice(3);
		return (country + " (" + city + ") " + number).trim();
	};
});
TMSApp.directive('inputTelephoneDirective', function() {
  return {
    require: 'ngModel',
    link: function(scope, element, attrs, ngModelController) {
      ngModelController.$parsers.push(function(data) {
        //convert data from view format to model format
        return data; //converted
      });

      ngModelController.$formatters.push(function(data) {
        //convert data from model format to view format
			if (!data) { return ''; }
			var value = data.toString().trim().replace(/(^\+|[\(\)\s])/g, '');
			//console.log(value);
			if (value.match(/[^0-9]/)) {
				return data;
			}		
			var country, city, number;
			switch (value.length) {
				case 10: // +1PPP####### -> C (PPP) ###-####
					country = 1;
					city = value.slice(0, 3);
					number = value.slice(3);
					break;
				case 11: // +CPPP####### -> CCC (PP) ###-####
					country = value[0];
					city = value.slice(1, 4);
					number = value.slice(4);
					break;
				case 12: // +CCCPP####### -> CCC (PP) ###-####
					country = value.slice(0, 3);
					city = value.slice(3, 5);
					number = value.slice(5);
					break;
				default:
				return data;
			}
			if (country == 1) {
				country = "";
			}
			number = number.slice(0, 3) + '-' + number.slice(3);
			return (country + " (" + city + ") " + number).trim();
			//return data; //converted
      });
    }
  }
});
// End: Filters

// Begin: Custom Functions
function triggerDealerPopup(obj){
	var dealCd = $(obj).data('dealcd');
	var scope = angular.element(obj).scope();
	scope.$apply(function () {
		scope.DealerInfoPopup(dealCd);
	});
}
function triggerUpdateTelematicOwnershipHistory(obj) {
	var custId = $(obj).data('custid');
	console.log(custId);
	angular.element($('[ng-controller="VehicleDetailsController"]')).scope().updateTelematicOwnershipHistory(custId);
}
function openAssociatedVins() {
	$("#associated_vin").toggle();
}
function setPrintContainer() {
	if($('.print_btn').length){
		setTimeout(function() {
			var win_ht			= $(window).height();
			var offset			= ($('.print_btn').offset().top + $('.print_btn').outerHeight(true));
			var print_fit_ht	= win_ht - offset;
			var content_ht		= $('#printPdfForm').outerHeight(true);
			var container_ht	= (content_ht > print_fit_ht)? (print_fit_ht - 10) : content_ht;
			$('.print_container').css('height', container_ht+'px');
		},300);
	}
}
function setMergePurgeContainer() {
	setTimeout(function() {
		if($('.merge-purge-container').length) {
			var div_ht = $(window).height() - ($("#searchinc360").offset().top + $("#searchinc360").outerHeight(true));
			$(".merge-purge-container").css('height',div_ht+'px');
		}
	},500);
}
function setRecentSearchContainer() {
	setTimeout(function() {
		if($('.recent-search-container').length) {
			var div_ht = $(window).height() - ($("#searchinc360").offset().top) - 2;
			$(".recent-search-container").css('height',div_ht+'px');
		}
	},5);
}
// End: Custom Functions
/******************* Googlemap Controller.js ***********************/
TMSApp.controller('mapCtrl',['$scope','$rootScope','mapDialog',function($scope,$rootScope,createDialog){
	console.log("-------mapCtrl-----------");
	function showMap($scope,$rootScope) {
		$scope.displayMap=true;
        var address12 = $rootScope.address12
        if($rootScope.address12 != null)
        $scope.options = {
            map: {
                center: new google.maps.LatLng(address12[0], address12[1]),
                zoom: 15,
                mapTypeId: google.maps.MapTypeId.TERRAIN
            }
        };
        $scope.address12=$rootScope.address12
        $scope.arrayAddress = []
        $scope.arrayAddress.push($scope.address12)
	
	}
    $scope.openMap=function(AddressLatLong, type){
		if(type == 'Customer') {
			var map_ht = 365;
			$rootScope.address12 = AddressLatLong; // contains lat & long
		} else {
			var map_ht = 303;
			$rootScope.gmapDetails	= AddressLatLong; // Contains Address object
			$rootScope.address12	= [$rootScope.gmapDetails.latitude, $rootScope.gmapDetails.longitude];
		}
		var map_top		= $("#map_icon").offset().top;
		var map_left	= $("#map_icon").offset().left + 15;
        createDialog({
            id: 'mapDialog',
            templateUrl:'views/gmap.html',
            controller: showMap,
            title: 'Family members',
            backdrop: true,
			css: { top: map_top+"px", left: map_left+"px", height: map_ht+"px"},
            success: {label: 'Success', fn: function() {console.log('Inline modal closed');}}
        });
    }
}]);
function triggerGMapDealerPopup(obj) {
	var dealCd = $(obj).data('dealcd');
	angular.element($('[ng-controller="VehicleDetailsController"]')).scope().DealerInfoPopup(dealCd);
}
/******************* Service - DealerviewPopup.js ***********************/
angular.module('TMSApp.DealerviewPopup', []).factory('DealerviewPopup', ["$document", "$window", "$compile", "$rootScope", "$controller", "$timeout", function ($document, $window, $compile, $rootScope, $controller, $timeout) {
	//alert('dsf');
	var defaults = {
		id: null,
		template: null,
		templateUrl: null,
		title: 'Default Title',
		backdrop: true,
		success: {label: 'OK', fn: null},
		cancel: {label: 'Close', fn: null},
		controller: null, //just like route controller declaration
		backdropClass: "ownerpopup-backdrop",
		backdropCancel: true,
		footerTemplate: null,
		modalClass: "ownerpopup",
		css: {
			top: '100px',
			left: '30%',
			margin: '0 auto'
		}
	};
	var body = $document.find('body');
	
	return function Dialog(templateUrl/*optional*/, options, passedInLocals) {
		// Handle arguments if optional template isn't provided.
		if(angular.isObject(templateUrl)){
			passedInLocals = options;
			options = templateUrl;
		} else {
			options.templateUrl = templateUrl;
		}
		options = angular.extend({}, defaults, options); //options defined in constructor

		var key;
		var idAttr = options.id ? ' id="' + options.id + '" ' : '';
		
		var modalBody = (function(){
			if(options.template){
				if(angular.isString(options.template)){
					// Simple string template
					return '<div class="modal-body">' + options.template + '</div>';
				} else {
					// jQuery/JQlite wrapped object
					return '<div class="modal-body">' + options.template.html() + '</div>';
				}
			} else {
				// Template url
				return '<div class="modal-body" ng-include="\'' + options.templateUrl + '\'"></div>'
			}
		})();
		//We don't have the scope we're gonna use yet, so just get a compile function for modal
		var modalEl = angular.element(
                '<div class="' + options.modalClass + ' fade"' + idAttr + ' style="display: block;">' +
                    '  <div class="modal-dialog">' +
                    '    <div class="modal-content">' + modalBody +
                    '    </div>' +
                    '  </div>' +
                    '</div>');

		for(key in options.css) {
			modalEl.css(key, options.css[key]);
		}
		var divHTML = "<div ";
		if(options.backdropCancel){
			divHTML+='ng-click="$modalCancel()"';
		}
		divHTML+=">";
		var backdropEl = angular.element(divHTML);
		backdropEl.addClass(options.backdropClass);
		backdropEl.addClass('fade in');

		var handleEscPressed = function (event) {
			if (event.keyCode === 27) {
				scope.$modalCancel();
			}
		};
		var setPopupPositioning = function (timer) {
			$timeout(function () {
				var modalElementOnload = setInterval(function(){
					if($(modalEl).is(':visible')) {
						var modalElWd	= modalEl.width();
						var modalElHt	= modalEl.outerHeight(true);
						var winW		= $(window).width();
						var winH		= $(window).height();
						var leftPos	= (winW - modalElWd)/2;
						var topPos	= (winH - modalElHt)/2;
						modalEl.css({"top" : topPos+"px", "left" : leftPos+"px"});
						console.log("------modalElHt-----------"+modalElHt);
						if(modalElHt > 100) {
							clearInterval(modalElementOnload);
						}
					} else {
						clearInterval(modalElementOnload);
					}
				}, 100);
			}, timer);
		};

		var closeFn = function () {
			body.unbind('keydown', handleEscPressed);
			modalEl.remove();
			if (options.backdrop) {
				backdropEl.remove();
			}
		};

		body.bind('keydown', handleEscPressed);
		angular.element($window).bind('resize', function(){
			setPopupPositioning(100);
		});

		var ctrl, locals,
		scope = options.scope || $rootScope.$new();

		scope.$title = options.title;
		scope.$modalClose = closeFn;
		scope.$modalCancel = function () {
			var callFn = options.cancel.fn || closeFn;
			callFn.call(this);
			scope.$modalClose();
		};
		scope.$modalSuccess = function () {
			var callFn = options.success.fn || closeFn;
			callFn.call(this);
			scope.$modalClose();
		};
		scope.$modalSuccessLabel = options.success.label;
		scope.$modalCancelLabel = options.cancel.label;
      
		if (options.controller) {
			locals = angular.extend({$scope: scope}, passedInLocals);
			ctrl = $controller(options.controller, locals);
			// Yes, ngControllerController is not a typo
			modalEl.contents().data('$ngControllerController', ctrl);
		}

		$compile(modalEl)(scope);
		$compile(backdropEl)(scope);
		body.append(modalEl);
		if (options.backdrop) body.append(backdropEl);
		$timeout(function () {
			modalEl.addClass('in');
			setPopupPositioning(700);
		}, 500);
	};
}]);

/******************* loadDynamicTemplate.js ***********************/
angular.module('TMSApp.LoadDynamicTemplate', []).factory('LoadDynamicTemplate', ["$document", "$compile", "$rootScope", "$controller", "$timeout", function ($document, $compile, $rootScope, $controller, $timeout) {
	var defaults = {
		id: null,
		classname: null,
		event:null,
		template: null,
		templateUrl: null,
		controller: null,
		parentElementClass:null,
		expandElementClass:null,
		css:null
	};
	return function Load(options) {
		options = angular.extend({}, defaults, options); //options defined in constructor
		var modalBody = (function(){
			if(options.template){
				if(angular.isString(options.template)){
					// Simple string template
					return '<div id="dummy_id" class="modal-body">' + options.template + '</div>';
				} else {
					// jQuery/JQlite wrapped object
					return '<div id="dummy_id" class="modal-body">' + options.template.html() + '</div>';
				}
			} else {
				// Template url
				return '<div id="dummy_id" class="modal-body" ng-include="\'' + options.templateUrl + '\'"></div>'
			}
		})();
		var modalEl = angular.element(modalBody);
		var obj = $(options.event.target).parents('div.'+options.parentElementClass).find('.'+options.expandElementClass);
		for(key in options.css) {
			modalEl.css(key, options.css[key]);
		}
		var scope = options.scope || $rootScope.$new();
		$compile(modalEl)(scope);
		obj.append(modalEl);
		//setTimeout(function(){
		var load = setInterval(function(){
			if($('#dummy_id').length) {
				$('#dummy_id').removeAttr('id');
				clearInterval(load);
				console.log('--inline_loader------minus----');
				//$(options.event.target).parents('div.collapse').find('tr td:last span').removeClass('inline_loader').addClass('minus');
				$(options.event.target).parents('div.collapse').find('tr span.symbol').removeClass('inline_loader').addClass('minus');
				$(options.event.target).parents('div.collapse').addClass('opened');
				var htmlcontent = obj.html().replace(/(ng-\w+-\w+="(.|\n)*?"|ng-\w+="(.|\n)*?"|ng-(\w+-\w+)|ng-(\w+))/g, '').replace(/<!--(.*?)-->/gm, "");
				obj.html('').html(htmlcontent);
				scope.setInnerScrollPos(options.event,options.viewportClass,options.parentElementClass);
			}
		}, 500);
		//},500);
		scope.setInnerScrollPos = function(event,viewport,currentElem) {
			var scrollPos		= $("#"+viewport).scrollTop();
			var parentTopPos	= $("#"+viewport).offset().top;
			var elementPos		= $(event.target).parents('div.'+currentElem).offset().top;
			$("#"+viewport).animate({"scrollTop": (scrollPos+elementPos-parentTopPos-20)+"px"}, 300);
		}
	}
}]);
/******************* createDialog.js ***********************/
angular.module('TMSApp.services', []).factory('createDialog', ["$document", "$window", "$compile", "$rootScope", "$controller", "$timeout",
  function ($document, $window, $compile, $rootScope, $controller, $timeout) {
    //alert('dsf');
    var defaults = {
      id: null,
      template: null,
      templateUrl: null,
      title: 'Default Title',
      backdrop: true,
      success: {label: 'OK', fn: null},
      cancel: {label: 'Close', fn: null},
      controller: null, //just like route controller declaration
      backdropClass: "modal-backdrop",
      backdropCancel: true,
      footerTemplate: null,
      modalClass: "modal",
      css: {
        top: '100px',
        left: '30%',
        margin: '0 auto'
      }
    };
    var body = $document.find('body');

    return function Dialog(templateUrl/*optional*/, options, passedInLocals) {

      // Handle arguments if optional template isn't provided.
      if(angular.isObject(templateUrl)){
        passedInLocals = options;
        options = templateUrl;
      } else {
        options.templateUrl = templateUrl;
      }

      options = angular.extend({}, defaults, options); //options defined in constructor

      var key;
      var idAttr = options.id ? ' id="' + options.id + '" ' : '';

      var modalBody = (function(){
        if(options.template){
          if(angular.isString(options.template)){
            // Simple string template
            return '<div class="modal-body">' + options.template + '</div>';
          } else {
            // jQuery/JQlite wrapped object
            return '<div class="modal-body">' + options.template.html() + '</div>';
          }
        } else {
          // Template url
          return '<div class="modal-body" ng-include="\'' + options.templateUrl + '\'"></div>'
        }
      })();
      //We don't have the scope we're gonna use yet, so just get a compile function for modal
      var modalEl = angular.element(
                '<div class="' + options.modalClass + ' fade"' + idAttr + ' style="display: block;">' +
                    '  <div class="modal-dialog">' +
                    '    <div class="modal-content">' +
                    '      <div class="modal-header">' +
                    '        <h2 style="padding-top:7px">{{$title}}<span style="float:right;margin-right:10px;margin-top: 4px;cursor:pointer;color:white;font-size:13px" ng-click="$modalCancel()" >X</span></h2>' +
                    '      </div>' +
                    modalBody +
                    '    </div>' +
                    '  </div>' +
                    '</div>');

      for(key in options.css) {
        modalEl.css(key, options.css[key]);
      }
      var divHTML = "<div ";
      if(options.backdropCancel){
        divHTML+='ng-click="$modalCancel()"';
      }
      divHTML+=">";
      var backdropEl = angular.element(divHTML);
      backdropEl.addClass(options.backdropClass);
      backdropEl.addClass('fade in');

      var handleEscPressed = function (event) {
        if (event.keyCode === 27) {
          scope.$modalCancel();
        }
      };

      var closeFn = function () {
        body.unbind('keydown', handleEscPressed);
        modalEl.remove();
        if (options.backdrop) {
          backdropEl.remove();
        }
      };
	  
	  var setPopupPositioning = function (timer) {
		   $timeout(function () {
			  var modalElWd	= modalEl.width();
			  var modalElHt	= modalEl.outerHeight(true);
			  var winW		= $(window).width();
			  var winH		= $(window).height();
			  var leftPos	= (winW - modalElWd)/2;
			  var topPos	= (winH - modalElHt)/2;
			  modalEl.css({"top" : topPos+"px", "left" : leftPos+"px"});
		  }, timer);
      };

      body.bind('keydown', handleEscPressed);
	  angular.element($window).bind('resize', function(){
		  setPopupPositioning(100);
	  });

      var ctrl, locals,
        scope = options.scope || $rootScope.$new();

      scope.$title = options.title;
      scope.$modalClose = closeFn;
      scope.$modalCancel = function () {
        var callFn = options.cancel.fn || closeFn;
        callFn.call(this);
        scope.$modalClose();
      };
      scope.$modalSuccess = function () {
        var callFn = options.success.fn || closeFn;
        callFn.call(this);
        scope.$modalClose();
      };
      scope.$modalSuccessLabel = options.success.label;
      scope.$modalCancelLabel = options.cancel.label;
      
      if (options.controller) {
        locals = angular.extend({$scope: scope}, passedInLocals);
        ctrl = $controller(options.controller, locals);
        // Yes, ngControllerController is not a typo
        modalEl.contents().data('$ngControllerController', ctrl);
      }

      $compile(modalEl)(scope);
      $compile(backdropEl)(scope);
      body.append(modalEl);
      if (options.backdrop) body.append(backdropEl);

      $timeout(function () {
        modalEl.addClass('in');
		setPopupPositioning(700);
      }, 500);
    };
  }]);