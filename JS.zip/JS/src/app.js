import {TestService} from 'sampleService'

TestService.method1();