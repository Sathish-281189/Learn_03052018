var TestService = (function() {
	function TestService() {
		console.log("----TestService-------");
	}
	TestService.prototype.method1 = function() {
		console.log("------method1--------");
	}
	TestService.prototype.method2 = function() {
		console.log("------method2--------");
	}
}());
export {TestService};